import { FUME } from 'FUME.js';
import { LibCommonB001 } from 'LibCommonB001.js';
import { LibBusinessB001 } from 'LibBusinessB001.js';
import { LibDateB001 } from 'LibDateB001.js';

export var  LibCommonB002 = (function () {
    // STARTFUNCTION versionLibCommonB002
    /**
   *
   * @param {*} No inputs
   * @summary	Dummy function
   * @returns {String} Dummy
   */
    function versionLibCommonB002() {
    // javascript-obfuscator:disablese
        const version = '20200706084633';
        // javascript-obfuscator:enable
        return version;
    }
    // ENDFUNCTION versionLibCommonB002

    // STARTFUNCTION getFieldValuesfromSRVStructB
    /**
   *
   * @param {Object} functionObj function object
   * @param {Object} inpSrvFields function object
   * @param {Object} outputFields function object
   * @returns {boolean} true/false
   * @summary	 Function to get value from SRV structure.
   * @example
   * 		getFieldValuesfromSRVStructB(functionObj,inpSrvFields,outputFields);
   */
    function getFieldValuesfromSRVStructB(
        functionObj,
        inpSrvFields,
        outputFields
    ) {
        FUME.print('Begin Function getFieldValuesfromSRVStructB');
        LibCommonB001.setErrorFieldsB(functionObj);

        if (Array.isArray(inpSrvFields) !== Array.isArray(outputFields)) {
            const errMessage =
        'Mismatch between data type of Input fields and Output fields.';
            LibCommonB001.setErrorFieldsB(functionObj, true, '', 'MSG', errMessage, '');
            return false;
        }

        let urhkOp;

        if (Array.isArray(inpSrvFields) && Array.isArray(outputFields)) {
            for (let i = 0; i < inpSrvFields.length; i++) {
                urhkOp = FUME.USRHK('SRV_GetVal', inpSrvFields[i]);
                functionObj[outputFields[i]] = FUME.getrepValue(
                    'BANCS',
                    'OUTPARAM',
                    'srvValue'
                );
                FUME.print(functionObj[outputFields[i]]);
            }
        } else {
            urhkOp = FUME.USRHK('SRV_GetVal', inpSrvFields);
            functionObj[outputFields] = FUME.getrepValue(
                'BANCS',
                'OUTPARAM',
                'srvValue'
            );
            FUME.print(functionObj[outputFields]);
        }
        FUME.print('End Function getFieldValuesfromSRVStructB');
        return true;
    }
    // ENDFUNCTION getFieldValuesfromSRVStructB

    // STARTFUNCTION getCallingMenuOptionB
    /**
   *
   * @param {String} errorCode Error Code
   * @returns {String} menuOption
   * @summary	 To fetch the menu from which the SRV is called.
   * @example
   * 		getCallingMenuOptionB(errorCode);
   */
    function getCallingMenuOptionB(errorCode) {
        FUME.print('Begin Function getCallingMenuOptionB');
        let errorMsg;
        let menuOption = '';

        errorMsg = '';
        if (FUME.isFieldExists(FUME.getrepValue('BANCS', 'STDIN', 'menuOption'))) {
            menuOption = FUME.getrepValue('BANCS', 'STDIN', 'menuOption');
            if (menuOption.trim() === '') {
                if (FUME.isFieldExists(FUME.getrepValue('BANCS', 'STDIN', 'menuId'))) {
                    menuOption = FUME.getrepValue('BANCS', 'STDIN', 'menuId');
                }
            }
        } else if (
            FUME.isFieldExists(FUME.getrepValue('BANCS', 'STDIN', 'menuId'))
        ) {
            menuOption = FUME.getrepValue('BANCS', 'STDIN', 'menuId');
        } else if (errorCode !== '') {
            let errormsg = LibCommonB001.cmmsgerrdescB(errorCode);
            FUME.print(errorMsg);
            FUME.USRHK('SRV_SetErr', errorMsg);
        }
        FUME.print('End Function getCallingMenuOptionB');
        return menuOption;
    }
    // ENDFUNCTION getCallingMenuOptionB

    // STARTFUNCTION getInputSolSetIdFromAgrumentsB
    /**
   *
   * @param {Number} argNumber Argument Number
   * @returns {String} solId
   * @summary	 To fetch the Sol SetId from the Input Arguments
   * @example
   * 		getInputSolSetIdFromAgrumentsB(argNumber);
   */
    function getInputSolSetIdFromAgrumentsB(argNumber) {
        FUME.print('Begin Function getInputSolSetIdFromAgrumentsB');
        let solId;
        let urhkOp;
        if (argNumber !== 0) {
            urhkOp = FUME.USRHK('MTTS_PopulateInputDetails', '');
            if (
                FUME.isFieldExists(
                    FUME.getrepValue(
                        'MTT',
                        'InputDetails',
                        `Argument${argNumber.toString()}`
                    )
                )
            ) {
                solId = FUME.getrepValue(
                    'MTT',
                    'InputDetails',
                    `Argument${argNumber.toString()}`
                );
                FUME.print(solId);
                if (solId === '') {
                    solId = 'ALL';
                } else if (solId === '<CS>') {
                    solId = FUME.getrepValue('BANCS', 'STDIN', 'mySolId');
                }
            }
        } else {
            solId = 'ALL';
        }
        FUME.print('End Function getInputSolSetIdFromAgrumentsB');
        return solId;
    }
    // ENDFUNCTION getInputSolSetIdFromAgrumentsB

    // STARTFUNCTION mandatoryCheckB
    /**
   *
   * @param {Object} functionObj Argument Number
   * @param {Array} inpStrArr Array of fields
   * @returns {String} errMsg
   * @summary	 To check the mandatory fields
   * @example
   * 		mandatoryCheckB(functionObj,inpStrArr);
   */
    function mandatoryCheckB(functionObj, inpStrArr) {
        FUME.print('Begin Function mandatoryCheckB');
        let errMsg = '';

        if (Array.isArray(inpStrArr)) {
            for (let i = 0; i < inpStrArr.length; i++) {
                if (functionObj[inpStrArr[i]]) {
                    if (functionObj[inpStrArr[i]].trim() === '') {
                        errMsg = `Field Must Be Entered:${
                            functionObj[inpStrArr[i]]
                        }   ${errMsg}`;
                    }
                } else {
                    errMsg = `Field Must Be Entered:${
                        functionObj[inpStrArr[i]]
                    }   ${errMsg}`;
                }
            }
        } else if (functionObj[inpStrArr]) {
            if (functionObj[inpStrArr].trim() === '') {
                errMsg = `Field Must Be Entered:${functionObj[inpStrArr]}   ${errMsg}`;
            }
        } else {
            errMsg = `Field Must Be Entered:${functionObj[inpStrArr]}   ${errMsg}`;
        }
        FUME.print('End Function mandatoryCheckB');
        return errMsg;
    }
    // ENDFUNCTION mandatoryCheckB

    // STARTFUNCTION storeBancsInparamFields
    /**
   *
   * @param {Object} functionObj Argument Number
   * @returns {boolean} true
   * @summary	 To store Query variables from BANCS Rep To Function Object
   * @example
   * 		storeBancsInparamFields(functionObj);
   */
    function storeBancsInparamFields(functionObj) {
        FUME.print('Begin Function storeBancsInparamFields');
        if (
            FUME.isFieldExists(
                FUME.getrepValue('BANCS', 'INPARAM', 'keyFieldsColumnDataType')
            )
        ) {
            if (
                FUME.getrepValue(
                    'BANCS',
                    'INPARAM',
                    'keyFieldsColumnDataType'
                ).trim() !== ''
            ) {
                functionObj.keyFieldsColumnDataType = FUME.getrepValue(
                    'BANCS',
                    'INPARAM',
                    'keyFieldsColumnDataType'
                );
            }
        }

        if (
            FUME.isFieldExists(
                FUME.getrepValue('BANCS', 'INPARAM', 'keyFieldsColumnFormat')
            )
        ) {
            if (
                FUME.getrepValue('BANCS', 'INPARAM', 'keyFieldsColumnFormat').trim() !==
        ''
            ) {
                functionObj.keyFieldsColumnFormat = FUME.getrepValue(
                    'BANCS',
                    'INPARAM',
                    'keyFieldsColumnFormat'
                );
            }
        }

        if (
            FUME.isFieldExists(
                FUME.getrepValue('BANCS', 'INPARAM', 'whereClauseOperator')
            )
        ) {
            if (
                FUME.getrepValue('BANCS', 'INPARAM', 'whereClauseOperator').trim() !==
        ''
            ) {
                functionObj.whereClauseOperator = FUME.getrepValue(
                    'BANCS',
                    'INPARAM',
                    'whereClauseOperator'
                );
            }
        }

        if (
            FUME.isFieldExists(
                FUME.getrepValue('BANCS', 'INPARAM', 'whereFieldsColumnDataType')
            )
        ) {
            if (
                FUME.getrepValue(
                    'BANCS',
                    'INPARAM',
                    'whereFieldsColumnDataType'
                ).trim() !== ''
            ) {
                functionObj.whereFieldsColumnDataType = FUME.getrepValue(
                    'BANCS',
                    'INPARAM',
                    'whereFieldsColumnDataType'
                );
            }
        }

        if (
            FUME.isFieldExists(
                FUME.getrepValue('BANCS', 'INPARAM', 'whereFieldsColumnFormat')
            )
        ) {
            if (
                FUME.getrepValue(
                    'BANCS',
                    'INPARAM',
                    'whereFieldsColumnFormat'
                ).trim() !== ''
            ) {
                functionObj.whereFieldsColumnFormat = FUME.getrepValue(
                    'BANCS',
                    'INPARAM',
                    'whereFieldsColumnFormat'
                );
            }
        }

        if (
            FUME.isFieldExists(
                FUME.getrepValue('BANCS', 'INPARAM', 'additionalQueryString')
            )
        ) {
            if (
                FUME.getrepValue('BANCS', 'INPARAM', 'additionalQueryString').trim() !==
        ''
            ) {
                functionObj.additionalQueryString = FUME.getrepValue(
                    'BANCS',
                    'INPARAM',
                    'additionalQueryString'
                );
            }
        }

        if (
            FUME.isFieldExists(
                FUME.getrepValue('BANCS', 'INPARAM', 'selectFieldsDelimiter')
            )
        ) {
            if (
                FUME.getrepValue('BANCS', 'INPARAM', 'selectFieldsDelimiter').trim() !==
        ''
            ) {
                functionObj.selectFieldsDelimiter = FUME.getrepValue(
                    'BANCS',
                    'INPARAM',
                    'selectFieldsDelimiter'
                );
            }
        }
        FUME.print('End Function storeBancsInparamFields');
        return true;
    }
    // ENDFUNCTION storeBancsInparamFields

    // STARTFUNCTION restoreBancsInparamFields
    /**
   *
   * @param {Object} functionObj Argument Number
   * @returns {boolean} true
   * @summary	 To store Query variables from BANCS Rep To Function Object
   * @example
   * 		restoreBancsInparamFields(functionObj);
   */
    function restoreBancsInparamFields(functionObj) {
        FUME.print('Begin Function restoreBancsInparamFields');
        if (functionObj.keyFieldsColumnDataType) {
            if (functionObj.keyFieldsColumnDataType.trim() !== '') {
                FUME.setrepValue(
                    'BANCS',
                    'INPARAM',
                    'keyFieldsColumnDataType',
                    functionObj.keyFieldsColumnDataType
                );
            }
        }

        if (functionObj.keyFieldsColumnFormat) {
            if (functionObj.keyFieldsColumnFormat.trim() !== '') {
                FUME.setrepValue(
                    'BANCS',
                    'INPARAM',
                    'keyFieldsColumnFormat',
                    functionObj.keyFieldsColumnFormat
                );
            }
        }

        if (functionObj.whereClauseOperator) {
            if (functionObj.whereClauseOperator.trim() !== '') {
                FUME.setrepValue(
                    'BANCS',
                    'INPARAM',
                    'whereClauseOperator',
                    functionObj.whereClauseOperator
                );
            }
        }

        if (functionObj.whereFieldsColumnDataType) {
            if (functionObj.whereFieldsColumnDataType.trim() !== '') {
                FUME.setrepValue(
                    'BANCS',
                    'INPARAM',
                    'whereFieldsColumnDataType',
                    functionObj.whereFieldsColumnDataType
                );
            }
        }

        if (functionObj.additionalQueryString) {
            if (functionObj.additionalQueryString.trim() !== '') {
                FUME.setrepValue(
                    'BANCS',
                    'INPARAM',
                    'additionalQueryString',
                    functionObj.additionalQueryString
                );
            }
        }

        if (functionObj.selectFieldsDelimiter) {
            if (functionObj.selectFieldsDelimiter.trim() !== '') {
                FUME.setrepValue(
                    'BANCS',
                    'INPARAM',
                    'selectFieldsDelimiter',
                    functionObj.selectFieldsDelimiter
                );
            }
        }

        FUME.print('End Function restoreBancsInparamFields');
        return true;
    }
    // ENDFUNCTION restoreBancsInparamFields

    // STARTFUNCTION verifyRecordsWithMODB
    /**
   *
   * @param {Object} functionObj Argument Number
   * @returns {boolean} true
   * @summary	 To verify a record that has mod table.
   * @example
   * 		verifyRecordsWithMODB(functionObj);
   */
    function verifyRecordsWithMODB(functionObj) {
        FUME.print('Start Function verifyRecordsWithMODB');
        let modTableRecordCount;

        let modTable = functionObj.modTable;
        let mainTable = functionObj.mainTable;
        let keyFieldsArr = functionObj.keyFieldsArr;
        let bindVarsArr = functionObj.bindVarsArr;

        let origKeyFieldsArr = keyFieldsArr;
        let origBindVarsArr = bindVarsArr;

        keyFieldsArr.push('ROWNUM');
        bindVarsArr.push('1');

        let localObj = {};
        localObj.outputFields = ['origRcreUserId', 'origRcreTime'];
        localObj.columnNames = [
            'RCRE_USER_ID',
            "TO_CHAR(RCRE_TIME,'DD-MM-YYYY HH24:MI:SS')"
        ];
        localObj.tableName = mainTable;
        localObj.whereFields = keyFieldsArr;
        localObj.whereValues = bindVarsArr;
        localObj.origRcreUserId = '';
        localObj.origRcreTime = '';
        if (LibCommonB001.selectFromTableB(localObj)) {
            FUME.print(localObj.origRcreUserId);
            FUME.print(localObj.origRcreTime);
            modTableRecordCount = 0;
            localObj.tableName = modTable;
            localObj.keyFields = origKeyFieldsArr;
            localObj.keyValues = origBindVarsArr;
            modTableRecordCount = LibCommonB001.checkRecordCntB(
                localObj.tableName,
                localObj.keyFields,
                localObj.keyValues
            );
            FUME.print(`modTableRecordCount :- ${modTableRecordCount}`);
            if (parseFloat(modTableRecordCount) > 0) {
                //	fv_nm = "whereFields|whereValues|whereClauseOperator|whereFieldsColumnDataType|whereFieldsColumnFormat|additionalQueryString|clearFields|sqlQuery|bindVal"
                localObj.tableName = mainTable;
                localObj.whereFields = localObj.keyFields;
                localObj.whereValues = localObj.keyValues;
                localObj.whereClauseOperator = functionObj.whereClauseOperator || undefined;
                localObj.whereFieldsColumnDataType = functionObj.whereFieldsColumnDataType || undefined;
                localObj.whereFieldsColumnFormat = functionObj.whereFieldsColumnFormat || undefined;
                localObj.additionalQueryString = functionObj.additionalQueryString || undefined;
                localObj.clearFields = functionObj.clearFields || undefined;
                localObj.sqlQuery = functionObj.sqlQuery || undefined;
                localObj.bindVal = functionObj.bindVal || undefined;
                LibCommonB001.deleteFromTableB(localObj);
            }
        }

        LibCommonB001.moveDataFromModToMainB(functionObj);
        localObj.tableName = modTable;
        LibCommonB001.deleteFromTableB(localObj);

        if (localObj.origRcreUserId.trim() !== '') {
            let localObj1 = {};
            localObj1.columnNames = ['RCRE_USER_ID', 'RCRE_TIME'];
            localObj1.columnValues = [localObj.origRcreUserId, localObj.origRcreTime];
            localObj1.tableName = mainTable;
            localObj1.whereFields = origKeyFieldsArr;
            localObj1.whereValues = origBindVarsArr;
            localObj1.columnDataType = ['STRING', 'DATE'];
            localObj1.columnFormat = ['', 'DD-MM-YYYY HH24:MI:SS'];
            LibCommonB001.updateTableB(localObj1);
        }
        FUME.print('End Function verifyRecordsWithMODB');
        return true;
    }
    // ENDFUNCTION verifyRecordsWithMODB

    // STARTFUNCTION chkMandatorySRVInputsB
    /**
   *
   * @param {Object} functionObj Function Object
   * @param {Array} inpStr Array of Inputs
   * @returns {boolean} true
   * @summary	 To validate if all Mandatory fields have been entered.
   * @example
   * 		chkMandatorySRVInputsB(functionObj,inpStr);
   */
    function chkMandatorySRVInputsB(functionObj, inpStr) {
        FUME.print('Start Function chkMandatorySRVInputsB');
        LibCommonB001.LibCommonB001.setErrorFieldsB(functionObj);
        let errMsg;
        let trueOrFalse = true;
        let mandFldsArr = [];
        let errCnt = 1;
        if (typeof (inpStr) === 'string') {
            mandFldsArr = inpStr.split('|');
        } else {
            mandFldsArr = inpStr;
        }

        for (let i = 0; i < mandFldsArr.length; i++) {
            if (functionObj[mandFldsArr[i]]) {
                if ((typeof (functionObj[mandFldsArr[i]]) === 'string') && (functionObj[mandFldsArr[i]].trim() === '')) {
                    trueOrFalse = false;
                    errMsg = 'Field must be entered:' + mandFldsArr[i];
                    LibCommonB001.LibCommonB001.setErrorFieldsB(functionObj, true, errCnt++, '', errMsg, '');
                }
                if ((Array.isArray(functionObj[mandFldsArr[i]])) && (!functionObj[mandFldsArr[i]].length)) {
                    trueOrFalse = false;
                    errMsg = 'Field must be entered:' + mandFldsArr[i];
                    LibCommonB001.LibCommonB001.setErrorFieldsB(functionObj, true, errCnt++, '', errMsg, '');
                }
            } else {
                trueOrFalse = false;
                errMsg = 'Field must be entered:' + mandFldsArr[i];
                LibCommonB001.LibCommonB001.setErrorFieldsB(functionObj, true, errCnt++, '', errMsg, '');
            }
        }
        FUME.print('End Function chkMandatorySRVInputsB');
        return trueOrFalse;
    }
    // ENDFUNCTION chkMandatorySRVInputsB

    // STARTFUNCTION chkNonMandatorySRVInputsB
    /**
   *
   * @param {Object} functionObj Function Object
   * @param {Array} inpStr Array of Inputs
   * @returns {boolean} true
   * @summary	 To initialize all Non Mandatory fields.
   * @example
   * 		chkNonMandatorySRVInputsB(functionObj,inpStr);
   */
    function chkNonMandatorySRVInputsB(functionObj, inpStr) {
        FUME.print('Start Function chkNonMandatorySRVInputsB');
        let trueOrFalse = true;
        let mandFldsArr = [];

        if (typeof inpStr === 'string') {
            mandFldsArr = inpStr.split('|');
        } else {
            mandFldsArr = inpStr;
        }

        for (let i = 0; i < mandFldsArr.length; i++) {
            if (!functionObj[mandFldsArr[i]]) {
                functionObj[mandFldsArr[i]] = '';
            }
        }
        FUME.print('End Function chkNonMandatorySRVInputsB');
        return trueOrFalse;
    }
    // ENDFUNCTION chkNonMandatorySRVInputsB

    // STARTFUNCTION genSpbxBasedLstFileB
    /**
   *
   *
   * @param {String} procedureName procedure name
   * @param {String} inpToProcedure inputs
   * @param {String} LstFileName list file name
   * @returns {boolean} true/false
   * @summary	To call spbx4001 and create lst file.
   * @example
   * 		genSpbxBasedLstFileB(procedureName,inpToProcedure,LstFileName)
   */
    function genSpbxBasedLstFileB(procedureName, inpToProcedure, LstFileName) {
        FUME.print('Start Function genSpbxBasedLstFileB');
        let retVal;
        let cmdString;

        FUME.print(procedureName);
        FUME.print(inpToProcedure);
        FUME.print(LstFileName);

        retVal = 0;
        cmdString = `exebatch spbx4001 ${procedureName} '${inpToProcedure}' > ${LstFileName}`;
        FUME.print(cmdString);
        retVal = FUME.system(cmdString);
        FUME.print(retVal);
        FUME.print('End Function genSpbxBasedLstFileB');
        if (retVal === 0) {
            return true;
        }
        return false;
    }
    // ENDFUNCTION genSpbxBasedLstFileB

    // STARTFUNCTION spbxReportGenerationB
    /**
   *
   *
   * @param {String} procName procedure name
   * @param {String} inputToProcedure inputd
   * @param {String} lstFileName names of lst file
   * @param {String} mrtOrJasperName template name
   * @param {String} rptFileName report file name
   * @param {String} reportTitle report title
   * @param {String} reportFormat report format
   * @returns {boolean} true/false
   * @summary	To generate report using spbx
   * @example
   * 		spbxReportGenerationB(procName, inputToProcedure, lstFileName, mrtOrJasperName, rptFileName, reportTitle, reportFormat)
   */
    function spbxReportGenerationB(
        procName,
        inputToProcedure,
        lstFileName,
        mrtOrJasperName,
        rptFileName,
        reportTitle,
        reportFormat
    ) {
        FUME.print('Begin Function spbxReportGenerationB');
        FUME.print(procName);
        FUME.print(inputToProcedure);
        FUME.print(lstFileName);
        FUME.print(mrtOrJasperName);
        FUME.print(rptFileName);
        FUME.print(reportTitle);
        FUME.print(reportFormat);

        if (!genSpbxBasedLstFileB(procName, inputToProcedure, lstFileName)) {
            FUME.print('LIST GENERATION FAILED');
            return false;
        }

        FUME.print(rptFileName);
        FUME.print(mrtOrJasperName);
        FUME.print(lstFileName);
        if (
            !LibCommonB001.genReportAndPushToHPRB(
                mrtOrJasperName,
                lstFileName,
                rptFileName,
                reportTitle,
                reportFormat
            )
        ) {
            FUME.print('RPT GENERATION FAILED');
            return false;
        }
        FUME.print('End Function spbxReportGenerationB');
        return true;
    }
    // ENDFUNCTION spbxReportGenerationB

    // STARTFUNCTION checkValueInListB
    /**
   *
   *
   * @param {array} valueList ValueArray
   * @param {string} value value
   * @param {string} delimiter delimited field optional
   * @returns {boolean} true/false
   * @summary	To check if value exists in array or string
   * @example
   * 		checkValueInListB(valueList, value, delimiter)
   */
    function checkValueInListB(valueList, value, delimiter = '|') {
        FUME.print('Begin Function checkValueInListB');
        let mandFldsArr = [];

        if (typeof valueList === 'string') {
            mandFldsArr = valueList.split(delimiter);
        } else {
            mandFldsArr = valueList;
        }

        FUME.print('End Function checkValueInListB');
        return mandFldsArr.includes(value);
    }
    // ENDFUNCTION checkValueInListB
    // STARTFUNCTION checkDuplicateRecB
    /**
   *
   * @param {Object} functionObj function object
   * @returns {boolean} true/false
   * @summary To check duplication objects in an array of Json Objects.
   * @example
   *       checkDuplicateRecB(functionObj);
   */
    function checkDuplicateRecB(functionObj) {
        FUME.print('Begin Function checkDuplicateRecB');
        LibCommonB001.setErrorFieldsB(functionObj);
        let mandFlds = ['arrayFieldName'];

        if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        mandFlds = ['inpErrMsgCode', 'columnIds'];
        LibCommonB002.chkNonMandatorySRVInputsB(functionObj, mandFlds);
        let arrayFieldName = functionObj.arrayFieldName;
        let columnIdsArr = [];
        if (typeof functionObj.columnIds === 'string') {
            columnIdsArr = functionObj.columnIds.split('|');
        } else {
            columnIdsArr = functionObj.columnIds;
        }

        let checkArray = [];
        let checkObj;

        if (columnIdsArr.length === 0) {
            checkArray = functionObj[arrayFieldName];
        } else {
            for (let i = 0; i < functionObj[arrayFieldName].length; i++) {
                checkObj = {};
                for (let j = 0; j < columnIdsArr.length; j++) {
                    checkObj[columnIdsArr[j]] =
            functionObj[arrayFieldName][i][columnIdsArr[j]];
                }
                checkArray.push(checkObj);
            }
        }
        let valueArr = checkArray.map(function (item) {
            return JSON.stringify(item);
        });
        var dupArr = [];

        let isDuplicate = valueArr.some(function (item, idx) {
            if (valueArr.indexOf(item) !== idx) dupArr.push(item);
            return valueArr.indexOf(item) !== idx;
        });

        if (!isDuplicate) {
            functionObj.duplicateFields = JSON.parse(dupArr[0]);
        }
        FUME.print('End Function checkDuplicateRecB' + isDuplicate);
        return isDuplicate;
    }
    // ENDFUNCTION checkDuplicateRecB

    // STARTFUNCTION handleRecordVerificationB
    /**
   *
   *
   * @param {Object} functionObj function object
   * @returns {boolean} true/false
   * @summary Internal function to handle verification of a record.
   * @example
   *        handleRecordVerificationB(functionObj);
   */
    function handleRecordVerificationB(functionObj) {
        FUME.print('Start Function handleRecordVerificationB');

        let modTableRecordCount;

        let modTable = functionObj.modTable;
        let mainTable = functionObj.mainTable;
        let keyFieldsArr = functionObj.keyFieldsArr;
        let bindVarsArr = functionObj.bindVarsArr;

        let origKeyFieldsArr = keyFieldsArr;
        let origBindVarsArr = bindVarsArr;

        keyFieldsArr.push('ROWNUM');
        bindVarsArr.push('1');

        let localObj = {};
        localObj.outputFields = ['origRcreUserId', 'origRcreTime'];
        localObj.columnNames = [
            'RCRE_USER_ID',
            "TO_CHAR(RCRE_TIME,'DD-MM-YYYY HH24:MI:SS')"
        ];
        localObj.tableName = mainTable;
        localObj.whereFields = keyFieldsArr;
        localObj.whereValues = bindVarsArr;
        localObj.origRcreUserId = '';
        localObj.origRcreTime = '';
        if (LibCommonB001.selectFromTableB(localObj)) {
            FUME.print(localObj.origRcreUserId);
            FUME.print(localObj.origRcreTime);
            modTableRecordCount = 0;
            localObj.tableName = modTable;
            localObj.keyFields = origKeyFieldsArr;
            localObj.keyValues = origBindVarsArr;
            modTableRecordCount = LibCommonB001.checkRecordCntB(
                localObj.tableName,
                localObj.keyFields,
                localObj.keyValues
            );
            FUME.print(`modTableRecordCount :- ${modTableRecordCount}`);
            if (parseFloat(modTableRecordCount) > 0) {
                //	fv_nm = "whereFields|whereValues|whereClauseOperator|whereFieldsColumnDataType|whereFieldsColumnFormat|additionalQueryString|clearFields|sqlQuery|bindVal"
                localObj.tableName = mainTable;
                localObj.whereFields = localObj.keyFields;
                localObj.whereValues = localObj.keyValues;
                localObj.whereClauseOperator =
          functionObj.whereClauseOperator || undefined;
                localObj.whereFieldsColumnDataType =
          functionObj.whereFieldsColumnDataType || undefined;
                localObj.whereFieldsColumnFormat =
          functionObj.whereFieldsColumnFormat || undefined;
                localObj.additionalQueryString =
          functionObj.additionalQueryString || undefined;
                localObj.clearFields = functionObj.clearFields || undefined;
                localObj.sqlQuery = functionObj.sqlQuery || undefined;
                localObj.bindVal = functionObj.bindVal || undefined;
                LibCommonB001.deleteFromTableB(localObj);
            }
        }
        handleTableDataMovementB(functionObj);
        localObj.tableName = modTable;
        LibCommonB001.deleteFromTableB(localObj);
        if (localObj.origRcreUserId.trim() !== '') {
            let localObj1 = {};
            localObj1.columnNames = ['RCRE_USER_ID', 'RCRE_TIME'];
            localObj1.columnValues = [localObj.origRcreUserId, localObj.origRcreTime];
            localObj1.tableName = mainTable;
            localObj1.whereFields = origKeyFieldsArr;
            localObj1.whereValues = origBindVarsArr;
            localObj1.columnDataType = ['STRING', 'DATE'];
            localObj1.columnFormat = ['', 'DD-MM-YYYY HH24:MI:SS'];
            LibCommonB001.updateTableB(localObj1);
        }
        FUME.print('End Function handleRecordVerificationB');
        return true;
    }
    // ENDFUNCTION handleRecordVerificationB

    /**
   *
   *
   * @param {Object} functionObj function object
   * @returns {boolean} true/false
   * @summary Internal function to handle data movement between Main and Mod Tables
   * @example
   *        handleTableDataMovementB(functionObj)
   */
    function handleTableDataMovementB(functionObj) {
        FUME.print('Start Function handleTableDataMovementB');
        let modTable = functionObj.modTable;
        let mainTable = functionObj.mainTable;
        let keyFieldsArr = functionObj.keyFieldsArr;
        let bindVarsArr = functionObj.bindVarsArr;

        FUME.print('Inside handleTableDataMovementB');
        // #Temp variables for updating the lchg time
        let query = '';
        query = `INSERT INTO ${mainTable}(SELECT * FROM ${modTable} WHERE 1=1`;
        if (functionObj.insertFieldsList) {
            if (functionObj.insertFieldsList.trim() !== '') {
                query = `INSERT INTO ${mainTable} (${functionObj.insertFieldsList}) (SELECT ${functionObj.insertFieldsList} FROM ${modTable} WHERE 1=1`;
                functionObj.insertFieldsList = undefined;
            }
        }
        let localObj = {};
        localObj.tableName = mainTable;
        localObj.whereFields = functionObj.keyFieldsArr;
        localObj.whereValues = functionObj.bindVarsArr;
        localObj.whereClauseOperator = functionObj.whereClauseOperator || undefined;
        localObj.whereFieldsColumnDataType =
      functionObj.whereFieldsColumnDataType || undefined;
        localObj.whereFieldsColumnFormat =
      functionObj.whereFieldsColumnFormat || undefined;
        localObj.additionalQueryString =
      functionObj.additionalQueryString || undefined;
        localObj.clearFields = functionObj.clearFields || undefined;
        localObj.sqlQuery = functionObj.sqlQuery || undefined;
        localObj.bindVal = functionObj.bindVal || undefined;

        let whereClauseObj = LibCommonB001.formWhereClauseQuery(localObj);
        FUME.print('Where Clause Query');
        FUME.print(whereClauseObj);
        query = query + whereClauseObj.query;
        query = query + ' )';

        let bindValArr = whereClauseObj.bindval.split('|');
        for (let i = 0; i < bindValArr.length; i++) {
            if (functionObj.dataTrimFlgCDB && functionObj.dataTrimFlgCDB !== 'Y') {
                bindValArr[i] = bindValArr[i].trim();
            }
        }

        LibCommonB001.execDbSql(query, bindValArr.join('|'));
        restoreBancsInparamFields(functionObj);
        let time = LibDateB001.getSysDateTimeWithFormatB('DD-MM-YYYY hh24:mi:ss');
        restoreBancsInparamFields(functionObj);

        let localObj1 = {};
        localObj1.columnNames = ['LCHG_USER_ID', 'LCHG_TIME'];
        localObj1.columnValues = [
            FUME.getrepValue('BANCS', 'STDIN', 'userId'),
            time
        ];
        localObj1.tableName = mainTable;
        localObj1.whereFields = keyFieldsArr;
        localObj1.whereValues = bindVarsArr;
        localObj1.columnDataType = ['STRING', 'DATE'];
        localObj1.columnFormat = ['', 'DD-MM-YYYY HH24:MI:SS'];
        LibCommonB001.updateTableB(localObj1);
        FUME.print('End Function handleTableDataMovementB');
        return true;
    }
    // ENDFUNCTION handleTableDataMovementB

    // STARTFUNCTION sqlQueryBasedReportGenerationB
    /**
     *
     *
     * @param {*} sqlQuery sql query
     * @param {*} outputlst output lst
     * @param {*} mrtOrJasperName template name
     * @param {*} rptFileName rpt name
     * @param {*} reportTitle title
     * @param {*} reportFormat format
     * @returns {boolean} true/false
     * @summary To generate report based on sql query
     * @example
     *         sqlQueryBasedReportGenerationB(sqlQuery,outputlst,mrtOrJasperName,rptFileName,reportTitle,reportFormat)
     */
    function sqlQueryBasedReportGenerationB(
        sqlQuery,
        outputlst,
        mrtOrJasperName,
        rptFileName,
        reportTitle,
        reportFormat
    ) {
        FUME.print('Begin Function sqlQueryBasedReportGenerationB');
        FUME.print(sqlQuery);
        FUME.print(outputlst);
        FUME.print(mrtOrJasperName);
        FUME.print(rptFileName);
        FUME.print(reportTitle);
        FUME.print(reportFormat);
        genSqlQueryBasedLstFileB(sqlQuery, outputlst);
        LibCommonB001.genReportAndPushToHPRB(
            mrtOrJasperName,
            outputlst,
            rptFileName,
            reportTitle,
            reportFormat
        );
        FUME.print('End Function sqlQueryBasedReportGenerationB');
        return true;
    }
    // ENDFUNCTION sqlQueryBasedReportGenerationB

    // STARTFUNCTION genReportExecB
    /**
     *
     *
     * @param {*} functionObj function object
     * @returns {boolean} true/false
     * @summary Internal function for generation of report
     * @example
     *        genReportExecB(functionObj);
     */
    function genReportExecB(functionObj) {
        FUME.print('Begin Function genReportExecB');
        let cmdOp;
        let cmdStr;
        LibCommonB001.setErrorFieldsB(functionObj);
        let mandFlds = ['executionMode'];
        if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        mandFlds =
      ['listFileMethod', 'genReportMethod', 'pushToHPRMethod', 'sqlQuery', 'procName', 'procInputs', 'templateFileName', 'lstFileName', 'reportFileName', 'reportFileFormat', 'hprReportTitle', 'formatStringFrbx', 'dataOrCritTypeInp', 'dataOrCritFileNameFrbx', 'reposFileNameFrbx', 'delCritListFileFrbx', 'addRepToPrintQueueFrbx', 'reportTo', 'copyRipFileToUserPath', 'reposFilePathFrbx', 'genReportPostProc'];
        LibCommonB002.chkNonMandatorySRVInputsB(functionObj, mandFlds);

        if (
            functionObj.executionMode === 'LIST_FILE_ONLY' ||
      functionObj.executionMode === 'GENRPT_FILE' ||
      functionObj.executionMode === 'GENRPT_FILE_AND_PUSH_TO_HPR'
        ) {
            let mandFlds = ['listFileMethod'];
            if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }
        }

        if (!functionObj.lstFileName.includes('.')) {
            functionObj.lstFileName = LibCommonB001.getUniqueFileNameB(
                functionObj.lstFileName,
                'LST'
            );
        }

        functionObj.reportFilePath = '';
        let finrptdir = ' ';
        finrptdir = LibCommonB001.getEnvVariableB('FIN_REPORTS_DIR');

        if (finrptdir.trim() !== '') {
            functionObj.reportFilePath = `${finrptdir}/${FUME.getrepValue(
                'BANCS',
                'STDIN',
                'userId'
            )}/`;
        }

        if (
            FUME.isFieldExists(
                FUME.getrepValue('BANCS', 'STDIN', 'batchExecutingForDate')
            )
        ) {
            if (
                FUME.getrepValue('BANCS', 'STDIN', 'batchExecutingForDate').trim() !==
        ''
            ) {
                functionObj.reportFilePath = '';
            }
        }

        functionObj.reportFileNameWithExtn = functionObj.reportFileName;
        if (!functionObj.reportFileName.includes('.')) {
            functionObj.reportFileNameWithExtn = LibCommonB001.getUniqueFileNameB(
                functionObj.reportFileName,
                functionObj.reportFileFormat
            );
        }
        functionObj.reportFileNameWithOutExtn = functionObj.reportFileNameWithExtn.split(
            '.'
        )[0];

        if (
            functionObj.executionMode === 'GENRPT_FILE' ||
      functionObj.executionMode === 'GENRPT_FILE_AND_PUSH_TO_HPR'
        ) {
            let mandFlds = ['genReportMethod'];
            if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }
        }

        FUME.print('Set Default Values');
        functionObj.listFileMethod =
      functionObj.listFileMethod.trim() || 'SQL_QUERY';
        functionObj.genReportMethod =
      functionObj.genReportMethod.trim() || 'mrbx4004';
        functionObj.pushToHPRMethod = functionObj.pushToHPRMethod.trim() || 'URHK';
        functionObj.reportTo = functionObj.reportTo.trim() || 'MANAGER';
        functionObj.delCritListFileFrbx =
      functionObj.delCritListFileFrbx.trim() || 'N';

        //----------------------------------------------------------------
        // COPY RIP FILE TO USER PATH AND ENV_VAR PATH
        //----------------------------------------------------------------
        FUME.print('copy rip file');
        if (functionObj.reposFileNameFrbx.trim() === '') {
            functionObj.reposFileNameFrbx =
        functionObj.templateFileName.split('.')[0] + '.rip';
        }

        if (functionObj.copyRipFileToUserPath.trim() !== 'N') {
            if (functionObj.reposFileNameFrbx.trim() !== '') {
                if (functionObj.reposFilePathFrbx.trim() !== '') {
                    let cpCmd = `cp -f ${functionObj.reposFilePathFrbx}/${functionObj.reposFileNameFrbx} ${functionObj.reposFileNameFrbx}`;
                    FUME.print(cpCmd);
                    let cmdOp = FUME.system(cpCmd);
                    FUME.print(cmdOp);
                    functionObj.reposFilePathToCopy = ' ';
                    functionObj.reposFilePathToCopy = LibCommonB001.getEnvVariableB(
                        'RIP_FILE_PATH'
                    );
                    if (functionObj.reposFilePathToCopy.trim() !== '') {
                        cpCmd = `cp -f ${functionObj.reposFilePathFrbx}/${functionObj.reposFileNameFrbx} ${functionObj.reposFilePathToCopy}`;
                        FUME.print(cpCmd);
                        cmdOp = FUME.system(cpCmd);
                        FUME.print(cmdOp);
                    }
                } else if (functionObj.templateFileName.trim() !== '') {
                    functionObj.templatePath = '';
                    functionObj.templatePath = LibCommonB001.getFullPathB(
                        functionObj.templateFileName
                    );
                    FUME.print(functionObj.templatePath);
                    if (functionObj.templatePath.trim() !== '') {
                        let sysCp = functionObj.templatePath + '../repos/';
                        let cpCmd = `cp -f ${sysCp}/${functionObj.reposFileNameFrbx} ${functionObj.reposFileNameFrbx}`;
                        FUME.print(cpCmd);
                        cmdOp = FUME.system(cpCmd);
                        FUME.print(cmdOp);
                        functionObj.reposFilePathToCopy = ' ';
                        functionObj.reposFilePathToCopy = LibCommonB001.getEnvVariableB(
                            'REPORT_RIP_FILE_PATH'
                        );
                        if (functionObj.reposFilePathToCopy.trim() !== '') {
                            cpCmd = `cp -f ${sysCp}/${functionObj.reposFileNameFrbx} ${functionObj.reposFilePathToCopy}`;
                            FUME.print(cpCmd);
                            cmdOp = FUME.system(cpCmd);
                            FUME.print(cmdOp);
                        }
                    }
                }
            }
        }

        FUME.print('LST Generation');
        //----------------------------------------------------------------
        // HANDLER FOR EACH EXECUTION MODE
        //----------------------------------------------------------------
        if (
            functionObj.executionMode === 'LIST_FILE_ONLY' ||
      functionObj.executionMode === 'GENRPT_FILE' ||
      functionObj.executionMode === 'GENRPT_FILE_AND_PUSH_TO_HPR'
        ) {
            if (functionObj.listFileMethod === 'SQL_QUERY') {
                mandFlds = ['sqlQuery', 'lstFileName'];
                if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
                    // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                    return false;
                }
                genSqlQueryBasedLstFileB(functionObj.sqlQuery, functionObj.lstFileName);
            }

            if (functionObj.listFileMethod === 'SPBX') {
                mandFlds = ['procName', 'lstFileName'];
                if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
                    // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                    return false;
                }
                functionObj.procInputs = `'${functionObj.procInputs}'`;
                if (
                    !genSpbxBasedLstFileB(
                        functionObj.procName,
                        functionObj.procInputs,
                        functionObj.lstFileName
                    )
                ) {
                    FUME.print('LIST GENERATION FAILED');
                    return false;
                }
            }

            if (functionObj.listFileMethod === 'LIST_FILE_AVAILABLE') {
                mandFlds = ['lstFileName'];
                if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
                    // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                    return false;
                }
            }
        }

        FUME.print('Report Generation');
        if (
            functionObj.executionMode === 'GENRPT_FILE' ||
      functionObj.executionMode === 'GENRPT_FILE_AND_PUSH_TO_HPR'
        ) {
            let mandFlds = [
                'templateFileName',
                'lstFileName',
                'reportFileNameWithOutExtn'
            ];
            if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }

            functionObj.templateFileNameExtn = LibCommonB001.getNthFieldFromStringB(
                functionObj.templateFileName,
                '.',
                2
            );

            if (functionObj.genReportMethod.toUpperCase() === 'FRBX0001') {
                //* Usage   :    frbx0001 <JobId> -t <templateFileName> -o <reportFileName>
                //*              [-f <formatString>] [-c <criteriaFileName>/-d <dataFileName>]
                //*              [-r reposFileName] [-z reportFormat(PDF/RTF/XLS/CSV/TXT/HTM)]
                //*              [-x (For Deleting the Criteria List File)]
                //*              [-q (For Adding the Generated Report to Print Queue)]
                //*              [-w <reportTo> (Only if -q is passed) ]
                let cmdStr = `exebatch frbx0001 $B2K_SESSION_ID -t ${functionObj.templateFileName} -o ${functionObj.reportFileNameWithOutExtn}`;
                if (functionObj.formatStringFrbx !== '') {
                    cmdStr = cmdStr + ' -f ' + functionObj.formatStringFrbx;
                }

                if (functionObj.dataOrCritTypeInp.trim() === '') {
                    functionObj.dataOrCritTypeInp = 'd';
                    functionObj.dataOrCritFileNameFrbx = functionObj.lstFileName;
                }
                if (functionObj.dataOrCritTypeInp === 'd') {
                    cmdStr = cmdStr + ' -d ' + functionObj.dataOrCritFileNameFrbx;
                }
                if (functionObj.dataOrCritTypeInp === 'c') {
                    cmdStr = cmdStr + ' -c ' + functionObj.dataOrCritFileNameFrbx;
                }
                if (functionObj.reposFileNameFrbx !== '') {
                    cmdStr = cmdStr + ' -r ' + functionObj.reposFileNameFrbx;
                }

                cmdStr = cmdStr + ' -z ' + functionObj.reportFileFormat;
                if (functionObj.delCritListFileFrbx === 'Y') {
                    cmdStr = cmdStr + ' -x ';
                }
                if (functionObj.executionMode === 'GENRPT_FILE_AND_PUSH_TO_HPR') {
                    functionObj.executionMode = 'GENRPT_FILE';
                    functionObj.addRepToPrintQueueFrbx = 'Y';
                }
                if (functionObj.addRepToPrintQueueFrbx === 'Y') {
                    cmdStr = cmdStr + ' -q -w ' + functionObj.reportTo;
                }
                FUME.print(cmdStr);
                cmdOp = FUME.system(cmdStr);
                FUME.print(cmdOp);
            }

            if (functionObj.genReportMethod.toUpperCase() === 'MRBX4004') {
                cmdStr = `mrbx4004 $B2K_SESSION_ID ${functionObj.templateFileName} ${functionObj.lstFileName} ${functionObj.reportFileNameWithOutExtn}`;
                FUME.print(cmdStr);
                cmdOp = FUME.system(cmdStr);
                FUME.print(cmdOp);
            }

            if (functionObj.genReportMethod.toUpperCase() === 'GENRPT4004') {
                cmdStr = `${functionObj.templateFileName}|"${functionObj.lstFileName}|"${functionObj.reportFileNameWithOutExtn}`;
                FUME.print(cmdStr);
                cmdOp = FUME.USRHK('B2k_GenRpt4004', cmdStr);
                FUME.print(cmdOp);
            }

            if (functionObj.templateFileNameExtn === 'mrt') {
                if (functionObj.reportFilePath.trim() !== '') {
                    cmdStr = `cp ${functionObj.reportFileNameWithOutExtn}.rpt ${functionObj.reportFileNameWithExtn}`;
                    FUME.print(cmdStr);
                    cmdOp = FUME.system(cmdStr);
                    FUME.print(cmdOp);
                    cmdStr = `cp ${functionObj.reportFilePath}/${functionObj.reportFileNameWithOutExtn}.rpt ${functionObj.reportFileNameWithExtn}`;
                    FUME.print(cmdStr);
                    cmdOp = FUME.system(cmdStr);
                    FUME.print(cmdOp);
                    cmdStr = `cp ${functionObj.reportFilePath}/${functionObj.reportFileNameWithOutExtn}.rpt ${functionObj.reportFilePath}/${functionObj.reportFileNameWithExtn}`;
                    FUME.print(cmdStr);
                    cmdOp = FUME.system(cmdStr);
                    FUME.print(cmdOp);
                } else {
                    cmdStr = `cp ${functionObj.reportFileNameWithOutExtn}.rpt ${functionObj.reportFileNameWithExtn}`;
                    FUME.print(cmdStr);
                    cmdOp = FUME.system(cmdStr);
                    FUME.print(cmdOp);
                }
            }
        }

        FUME.print('Push to HPR');
        if (
            functionObj.executionMode === 'GENRPT_FILE_AND_PUSH_TO_HPR' ||
      functionObj.executionMode === 'PUSH_TO_HPR_ONLY'
        ) {
            let mandFlds = ['reportFileName', 'hprReportTitle'];
            if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }
            if (functionObj.pushToHPRMethod.toUpperCase() === 'URHK') {
                if (functionObj.reportFilePath.trim() !== '') {
                    cmdStr = `${functionObj.reportFilePath}/"${functionObj.reportFileNameWithExtn}`;
                    FUME.print(cmdStr);
                    LibCommonB001.pushReportToHPRB(cmdStr, functionObj.hprReportTitle);
                } else {
                    LibCommonB001.pushReportToHPRB(
                        functionObj.reportFileNameWithExtn,
                        functionObj.hprReportTitle
                    );
                }
            }

            if (functionObj.pushToHPRMethod.toUpperCase() === 'BABX4040') {
                if (functionObj.reportFilePath.trim() !== '') {
                    cmdStr =
            "exebatch babx4040 ${B2K_SESSION_ID}  '" +
            functionObj.reportFilePath +
            '/' +
            functionObj.reportFileNameWithExtn +
            "' '" +
            functionObj.hprReportTitle +
            "' '" +
            functionObj.reportTo +
            "' '1' 'N'";
                } else {
                    cmdStr =
            "exebatch babx4040 ${B2K_SESSION_ID}  '" +
            functionObj.reportFileNameWithExtn +
            "' '" +
            functionObj.hprReportTitle +
            "' '" +
            functionObj.reportTo +
            "' '1' 'N'";
                }
                FUME.print(cmdStr);
                cmdOp = FUME.system(cmdStr);
                FUME.print(cmdOp);
            }
        }

        FUME.print('Post Process');
        if (functionObj.genReportPostProc.trim() !== '') {
            let postProcArr = functionObj.genReportPostProc.split('!');
            let x;
            let y;
            let z;
            for (let i = 0; i < postProcArr.length; i++) {
                x = postProcArr[i];
                y = LibCommonB001.getNthFieldFromStringB(x, '=', 1);
                z = LibCommonB001.getNthFieldFromStringB(x, '=', 2);
                functionObj.actionType = y;
                functionObj.parameterId = z;
                functionObj.multipleSelectFlg = 'N';
                functionObj.parameterValue = '';

                FUME.print(x);
                FUME.print(y);
                FUME.print(z);

                if (functionObj.genReportMethod.toUpperCase() === 'FRBX0001') {
                    functionObj.reportFileNameWithExtn = `RPT_${functionObj.reportFileNameWithOutExtn}*.*`;
                }
                if (functionObj.actionType === 'MOVE_REPORT_TO_CPARAM_PATH') {
                    let rv = LibBusinessB001.getCPARAMDataB(functionObj);
                    if (functionObj.parameterValue.trim() === '') {
                        functionObj.parameterValue = '.';
                    }
                    if (functionObj.reportFilePath.trim() !== '') {
                        cmdStr = `mv ${functionObj.reportFilePath}/${functionObj.reportFileNameWithExtn} ${functionObj.parameterValue}/`;
                        FUME.print(cmdStr);
                    } else {
                        cmdStr = `mv ${functionObj.reportFileNameWithExtn} ${functionObj.parameterValue}/`;
                        FUME.print(cmdStr);
                    }
                    cmdOp = FUME.system(cmdStr);
                    FUME.print(cmdOp);
                }

                if (functionObj.actionType === 'MOVE_REPORT_TO_ENV_VAR_PATH') {
                    functionObj.parameterValue = LibCommonB001.getEnvVariableB(
                        functionObj.parameterId
                    );
                    if (functionObj.parameterValue.trim() === '') {
                        functionObj.parameterValue = '.';
                    }
                    if (functionObj.reportFilePath.trim() !== '') {
                        cmdStr = `mv ${functionObj.reportFilePath}/${functionObj.reportFileNameWithExtn} ${functionObj.parameterValue}/`;
                        FUME.print(cmdStr);
                    } else {
                        cmdStr = `mv ${functionObj.reportFileNameWithExtn} ${functionObj.parameterValue}/`;
                        FUME.print(cmdStr);
                    }
                    cmdOp = FUME.system(cmdStr);
                    FUME.print(cmdOp);
                }

                if (functionObj.actionType === 'COPY_REPORT_TO_CPARAM_PATH') {
                    let rv = LibBusinessB001.getCPARAMDataB(functionObj);
                    if (functionObj.parameterValue.trim() === '') {
                        functionObj.parameterValue = '.';
                    }
                    if (functionObj.reportFilePath.trim() !== '') {
                        cmdStr = `cp ${functionObj.reportFilePath}/${functionObj.reportFileNameWithExtn} ${functionObj.parameterValue}/`;
                        FUME.print(cmdStr);
                    } else {
                        cmdStr = `cp ${functionObj.reportFileNameWithExtn} ${functionObj.parameterValue}/`;
                        FUME.print(cmdStr);
                    }
                    cmdOp = FUME.system(cmdStr);
                    FUME.print(cmdOp);
                }

                if (functionObj.actionType === 'COPY_REPORT_TO_ENV_VAR_PATH') {
                    functionObj.parameterValue = LibCommonB001.getEnvVariableB(
                        functionObj.parameterId
                    );
                    if (functionObj.parameterValue.trim() === '') {
                        functionObj.parameterValue = '.';
                    }
                    if (functionObj.reportFilePath.trim() !== '') {
                        cmdStr = `cp ${functionObj.reportFilePath}/${functionObj.reportFileNameWithExtn} ${functionObj.parameterValue}/`;
                        FUME.print(cmdStr);
                    } else {
                        cmdStr = `cp ${functionObj.reportFileNameWithExtn} ${functionObj.parameterValue}/`;
                        FUME.print(cmdStr);
                    }
                    cmdOp = FUME.system(cmdStr);
                    FUME.print(cmdOp);
                }
            }
        }
        FUME.print('End Function genReportExecB');
        return true;
    }
    // ENDFUNCTION genReportExecB

    // STARTFUNCTION setUrhkInpNMRB
    /**
     *
     *
     * @param {Object} functionObj full object
     * @param {*} funcMode func mode
     * @param {*} fldWithStruct SRV structure
     * @param {*} fldName field name
     * @param {string} [addVar=''] add variable
     * @returns {boolean} true/false
     * @summary Function to set Non Multirec inputs to SRV
     * @example
     *        setUrhkInpNMRB(functionObj,funcMode,fldWithStruct,fldName,addVar = '')
     *
     */
    function setUrhkInpNMRB(
        functionObj,
        funcMode,
        fldWithStruct,
        fldName,
        addVar = ''
    ) {
        let inp;
        if (functionObj[fldName]) {
            inp = fldWithStruct + '|' + functionObj[fldName];
            let loc = FUME.USRHK('SetUrhkInp', inp);
        }
        return true;
    }
    // ENDFUNCTION setUrhkInpNMRB

    // STARTFUNCTION setUrhkInpMRB
    /**
     *
     *
     * @param {*} functionObj function object
     * @param {*} funcMode function mode
     * @param {*} strucUptoLL SRV LL
     * @param {*} srlNo serial no
     * @param {*} fldId SRV fld id
     * @param {*} fldName field Name
     * @param {string} [addVar=''] add var
     * @returns {boolean} true/false
     * @summary Function to set multi-rec inputs to SRV
     * @example
     *       setUrhkInpMRB(functionObj,funcMode,strucUptoLL,srlNo,fldId,fldName,addVar = '')
     */
    function setUrhkInpMRB(
        functionObj,
        funcMode,
        strucUptoLL,
        srlNo,
        fldId,
        fldName,
        addVar = ''
    ) {
        let inp;
        let mrecInp;
        let llInp;
        if (functionObj[srlNo][fldName]) {
            // if (FUME.isFieldExists((FUME.getrepValue((repName), (className), (fldName + "_" + FORMAT$(srlNo, "%d")))))) {
            // inp = FUME.getrepValue(repName), (className), (fldName + "_" + FORMAT$(srlNo, "%d"))
            inp = functionObj[srlNo][fldName];
            mrecInp = strucUptoLL + '.<rec_' + srlNo.toString() + '>.' + fldId;
            llInp = mrecInp + '|' + inp;
            let loc = FUME.USRHK('SetUrhkInp', llInp);
            print(loc);
        }
        return true;
    }
    // ENDFUNCTION setUrhkInpMRB

    // STARTFUNCTION execSrvNoCommitB
    /**
     *
     *
     * @param {*} functionObj function obj
     * @returns {boolean} true/false
     * @summary Calling SRV in NoCommit Mode
     * @example
     *      execSrvNoCommitB(functionObj);
     */
    function execSrvNoCommitB(functionObj) {
        let srvOp;
        let serviceName;
        LibCommonB001.setErrorFieldsB(functionObj);
        let mandFlds = ['serviceName'];
        if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }
        serviceName = functionObj.serviceName;
        mandFlds = ['ignoreExceptionsFlg'];
        chkNonMandatorySRVInputsB(functionObj, mandFlds);
        let execCmd1 =
      serviceName + '|retain_all_output = Y|same_user_verify = Y|call_mode = E';
        let execCmd2 =
      serviceName + '|retain_all_output = Y|same_user_verify = Y|call_mode = N';
        srvOp = FUME.USRHK('ExecSrvNoCommit', execCmd1);
        FUME.print(srvOp);
        if (srvOp !== 0) {
            if (functionObj.ignoreExceptionsFlg === 'Y') {
                srvOp = FUME.USRHK('CopyOutToIn', '');
                srvOp = FUME.USRHK('ExecSrvNoCommit', execCmd2);
                FUME.print(srvOp);
                if (srvOp === 0) {
                    return true;
                }
            }
            let errorMsg = LibCommonB001.handleSrvErrorB('Y', 'Y', 'Y', 'Y');
            FUME.print(errorMsg);
            LibCommonB001.setErrorFieldsB(functionObj, true, '2', 'MSG', errorMsg, '');
            return false;
        }
        return true;
    }
    // ENDFUNCTION execSrvNoCommitB

    // STARTFUNCTION setFieldValueForSRVNMRB
    /**
     *
     *
     * @param {*} functionObj function object
     * @param {*} funcMode func Mode
     * @param {*} fieldStruct field structure
     * @param {*} fldName field name
     * @param {string} [addVar=''] add var
     * @returns {boolean} true/false
     * @summary To SetVal to the Product SRV
     * @example
     *    setFieldValueForSRVNMRB(functionObj,funcMode,fieldStruct,fldName,addVar = '')
     */
    function setFieldValueForSRVNMRB(
        functionObj,
        funcMode,
        fieldStruct,
        fldName,
        addVar = ''
    ) {
        if (functionObj[fldName]) {
            let inp = fieldStruct + '|' + functionObj[fldName];
            let loc = FUME.USRHK('SRV_SetVal', inp);
        }
        return true;
    }
    // ENDFUNCTION setFieldValueForSRVNMRB

    // STARTFUNCTION getMultirecCountFromSRVB
    /**
     *
     *
     * @param {*} functionObj function object
     * @returns {boolean} true/false
     * @summary Function to get the count of multirec from SRV
     * @example
     *    getMultirecCountFromSRVB(functionObj);
     */
    function getMultirecCountFromSRVB(functionObj) {
        LibCommonB001.setErrorFieldsB(functionObj);
        let mandFlds = ['inputSrvField'];
        if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        let a = FUME.USRHK('SRV_NumOfRecs', functionObj.inputSrvField);
        FUME.print(a);
        if (a === 0) {
            functionObj.outputCount = FUME.getrepValue(
                'BANCS',
                'OUTPARAM',
                'srvValue'
            );
            FUME.print(functionObj.outputCount);
            return true;
        }
        LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDGMCFS001', '', '');
        return false;
    }
    // ENDFUNCTION getMultirecCountFromSRVB

    // STARTFUNCTION appendONSCustDataWithInpStrB
    /**
     *
     *
     * @param {*} functionObj function object
     * @returns {boolean} true/false
     * @summary Function to append string to ONS.CUSTOM.custDataOut
     * @example
     *      appendONSCustDataWithInpStrB(functionObj);
     */
    function appendONSCustDataWithInpStrB(functionObj) {
        if (functionObj.appendString) {
            FUME.setrepValue(
                'ONS',
                'CUSTOM',
                'custDataOut',
                FUME.getrepValue('ONS', 'CUSTOM', 'custDataOut') +
          '|' +
          functionObj.appendString
            );
        }
        return true;
    }
    // ENDFUNCTION appendONSCustDataWithInpStrB

    // STARTFUNCTION genReportB
    /**
     *
     *
     * @param {*} functionObj function object
     * @returns {boolean} true/false
     * @summary Function to generate a report with various formats and ways
     * @example
     *      genReportB(functionObj)
     */
    function genReportB(functionObj) {
        FUME.print('Begin genReportB function ');
        functionObj.args = '';

        LibCommonB001.setErrorFieldsB(functionObj);
        if (!chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        let mandFlds =
      ['executionMode', 'listFileMethod', 'genReportMethod', 'pushToHPRMethod', 'procName', 'procInputs', 'templateFileName', 'lstFileName', 'reportFileName', 'reportFileFormat', 'hprReportTitle', 'formatStringFrbx', 'dataOrCritTypeInp', 'dataOrCritFileNameFrbx', 'reposFileNameFrbx', 'delCritListFileFrbx', 'addRepToPrintQueueFrbx', 'reportTo', 'copyRipFileToUserPath', 'reposFilePathFrbx', 'genReportPostProc', 'sqlQuery', 'backGrndExec', 'rptgenInputs'];
        chkNonMandatorySRVInputsB(functionObj, mandFlds);

        if (functionObj.backGrndExec !== 'Y') {
            let rptOut = genReportExecB(functionObj);
        } else {
            functionObj.args = functionObj.executionMode;
            functionObj.args = functionObj.args + '~' + functionObj.listFileMethod;
            functionObj.args = functionObj.args + '~' + functionObj.genReportMethod;
            functionObj.args = functionObj.args + '~' + functionObj.pushToHPRMethod;
            functionObj.args = functionObj.args + '~' + functionObj.procName;
            functionObj.args = functionObj.args + '~' + functionObj.procInputs;
            functionObj.args = functionObj.args + '~' + functionObj.templateFileName;
            functionObj.args = functionObj.args + '~' + functionObj.lstFileName;
            functionObj.args = functionObj.args + '~' + functionObj.reportFileName;
            functionObj.args = functionObj.args + '~' + functionObj.reportFileFormat;
            functionObj.args = functionObj.args + '~' + functionObj.hprReportTitle;
            functionObj.args = functionObj.args + '~' + functionObj.formatStringFrbx;
            functionObj.args = functionObj.args + '~' + functionObj.dataOrCritTypeInp;
            functionObj.args =
        functionObj.args + '~' + functionObj.dataOrCritFileNameFrbx;
            functionObj.args = functionObj.args + '~' + functionObj.reposFileNameFrbx;
            functionObj.args =
        functionObj.args + '~' + functionObj.delCritListFileFrbx;
            functionObj.args =
        functionObj.args + '~' + functionObj.addRepToPrintQueueFrbx;
            functionObj.args = functionObj.args + '~' + functionObj.reportTo;
            functionObj.args =
        functionObj.args + '~' + functionObj.copyRipFileToUserPath;
            functionObj.args = functionObj.args + '~' + functionObj.reposFilePathFrbx;
            functionObj.args = functionObj.args + '~' + functionObj.genReportPostProc;
            functionObj.args = functionObj.args + '~' + functionObj.rptgenInputs;

            // Should urhk_CallShellScript be called or exectrusteduser session
            let cmdStr =
        "exebatch babx4061 $B2K_SESSION_ID genReportB_BG.scr '" +
        functionObj.args +
        "' '" +
        functionObj.sqlQuery +
        "' &";
            FUME.print(cmdStr);
            let cmdOp = FUME.system(cmdStr);
            FUME.print(cmdOp);
        }
        FUME.print('End genReportB function ');
        return true;
    }
    // ENDFUNCTION genReportB

    // STARTFUNCTION genSqlQueryBasedLstFileB
    function genSqlQueryBasedLstFileB(sqlQuery, outputlst) {
        FUME.print('Begin genSqlQueryBasedLstFileB function ');
        let tmpFile = 'GenList_';
        let sqlFileName = LibCommonB001.getUniqueFileNameB(tmpFile, 'sql');
        FUME.print(sqlFileName);
        tmpFile = 'TMP_';
        let outTmpFile = LibCommonB001.getUniqueFileNameB(tmpFile, 'lst');
        FUME.print(outTmpFile);
        let writeFileArr = [];
        writeFileArr.push('set feedback OFF');
        writeFileArr.push('set feedback OFF');
        writeFileArr.push('set pages 0');
        writeFileArr.push('set echo OFF');
        writeFileArr.push("set colsep '|'");
        writeFileArr.push('set linesize 10000');
        writeFileArr.push('TRIM ON');
        writeFileArr.push('spool ' + outTmpFile);
        writeFileArr.push(sqlQuery);
        writeFileArr.push(';');
        writeFileArr.push('spool OFF');
        writeFileArr.push('EXIT');
        let urhkOp;
        let cmdOp;
        urhkOp = LibCommonB001.addDataToFileB(sqlFileName, writeFileArr);

        let cmdStr = 'exebatch bauu9151 ' + sqlFileName;
        FUME.print(cmdStr);
        cmdOp = FUME.system(cmdStr);
        FUME.print(cmdOp);

        cmdStr = 'cat ' + outTmpFile + '>>' + outputlst;
        FUME.print(cmdStr);
        cmdOp = FUME.system(cmdStr);
        FUME.print(cmdOp);
        cmdStr = "sed 's/ *| */|/g' " + outputlst + '>' + outTmpFile;
        cmdOp = FUME.system(cmdStr);
        FUME.print(cmdOp);
        cmdStr = 'cat ' + outTmpFile + '>' + outputlst;
        FUME.print(cmdStr);
        cmdOp = FUME.system(cmdStr);
        FUME.print(cmdOp);
        cmdStr = 'rm -f ' + sqlFileName + ' ' + outTmpFile;
        cmdOp = FUME.system(cmdStr);
        return true;
    }
    // ENDFUNCTION genSqlQueryBasedLstFileB

    // STARTFUNCTION getFieldValueFromSRVNMRB
    /**
     *
     *
     * @param {*} functionObj function object
     * @param {*} srvField srv field
     * @param {*} outPutFld output field
     * @param {string} [addVar=''] add var
     * @returns {boolean} true/false
     * @summary Function to Get Value from SRV strcuture
     * @example
     *    getFieldValueFromSRVNMRB(functionObj,srvField,outPutFld,addVar = '')
     */
    function getFieldValueFromSRVNMRB(
        functionObj,
        srvField,
        outPutFld,
        addVar = ''
    ) {
        let outSrvValue;
        outSrvValue = '';
        let urhkOp = FUME.USRHK('SRV_GetVal', srvField);
        if (FUME.isFieldExists(FUME.getrepValue('BANCS', 'OUTPARAM', 'srvValue'))) {
            outSrvValue = FUME.getrepValue('BANCS', 'OUTPARAM', 'srvValue');
        }
        functionObj[outPutFld] = outSrvValue;
        return true;
    }
    // ENDFUNCTION getFieldValueFromSRVNMRB

    // STARTFUNCTION copyCreateOptionalFieldB
    /**
     *
     *
     * @param {*} srcFieldId source field
     * @param {*} functionObj function object
     * @param {*} [dstFieldId=srcFieldId] destination field
     * @param {string} [defaultValue=''] default value
     * @example
     *     copyCreateOptionalFieldB(srcFieldId,functionObj,dstFieldId = srcFieldId,defaultValue = '')
     */
    function copyCreateOptionalFieldB(
        srcFieldId,
        functionObj,
        dstFieldId = srcFieldId,
        defaultValue = ''
    ) {
        LibCommonB001.copyOptionalFieldB(
            srcFieldId,
            functionObj,
            dstFieldId,
            defaultValue
        );
        FUME.setrepValue('BANCS', 'INPUT', dstFieldId, functionObj[dstFieldId]);
    }
    // ENDFUNCTION copyCreateOptionalFieldB
    // STARTFUNCTION com_mitB
    /**
   * @returns {boolean} true/false
   * @summary	To Commit
   * @example
   * 		com_mitB()
   */
    function com_mitB() {
        FUME.print('In Function com_mitB');
        return LibCommonB001.executeDbSqlQuery('COMMIT');
    }
    // ENDFUNCTION com_mitB

    // STARTFUNCTION roll_backB
    /**
* @returns {boolean} true/false
* @summary	To Rollback
* @example
* 		roll_backB
*/
    function roll_backB() {
        FUME.print('In Function roll_backB');
        return LibCommonB001.executeDbSqlQuery('ROLLBACK');
    }
    // ENDFUNCTION roll_backB

    // STARTFUNCTION fetchCursorDataB
    /**
*
* @param {Object} functionObj function object
* @returns {boolean} true/false
* @summary Fetches the data from the cursor
* @example
*   fetchCursorDataB(functionObj);
*/
    function fetchCursorDataB(functionObj) {
        FUME.print('Begin Function fetchCursorDataB');
        LibCommonB001.setErrorFieldsB(functionObj);
        let mandFlds;
        mandFlds = ['outputFields', 'sqlQuery'];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB002.LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        mandFlds = [
            'bindVal',
            'setOrbOutFlg',
            'mrhString',
            'createDataFile',
            'dataFileNamePattern',
            'dataFileExtn',
            'dataFileName',
            'dataFileDelimiter',
            'clearFields'
        ];
        LibCommonB002.chkNonMandatorySRVInputsB(functionObj, mandFlds);

        if (functionObj.dataFileExtn.trim() === '') {
            functionObj.dataFileExtn = 'LST';
        }

        if (functionObj.dataFileDelimiter.trim() === '') {
            functionObj.dataFileDelimiter = '|';
        }

        if (functionObj.clearFields.trim() === '') {
            functionObj.clearFields = 'Y';
        }

        if (functionObj.sqlQuery.trim() !== '') {
            let outputFieldsArr = [];
            let bindValArr = [];

            if (typeof functionObj.outputFields === 'string') {
                outputFieldsArr = functionObj.outputFields.split('|');
            } else {
                outputFieldsArr = functionObj.outputFields;
            }

            if (typeof functionObj.bindVal === 'string') {
                bindValArr = functionObj.bindVal.split('|');
            } else {
                bindValArr = functionObj.bindVal;
            }

            let finalQuery = '';
            finalQuery = `${outputFieldsArr.join()}|${functionObj.sqlQuery}`;

            let urhkOp;

            let mrhStringArr = [];
            let outputObj;

            if (
                LibCommonB001.executeDbCursorQuery(finalQuery, bindValArr.join('|'))
            ) {
                let curNum = FUME.getrepValue('BANCS', 'OUTPARAM', 'DB_CURSOR_NUMBER');
                urhkOp = FUME.USRHK('dbCursorFetch', curNum);
                while (urhkOp === 0) {
                    outputObj = {};
                    for (let i = 0; i < outputFieldsArr.length; i++) {
                        outputObj[outputFieldsArr[i]] = LibCommonB001.copyOutparamFieldB(
                            outputFieldsArr[i],
                            ''
                        );
                    }
                    mrhStringArr.push[outputObj];
                    urhkOp = FUME.USRHK('dbCursorFetch', curNum);
                }
                urhkOp = FUME.USRHK('dbCursorClose', curNum);
            }

            functionObj[functionObj.mrhString] = mrhStringArr;

            let orbOutStr;
            let orbOutVal;

            if (functionObj.setOrbOutFlg === 'Y') {
                for (let j = 0; j < mrhStringArr; j++) {
                    for (let i = 0; i < outputFieldsArr.length; i++) {
                        orbOutVal = mrhStringArr[j][outputFieldsArr[i]] || 'NULL';
                        orbOutStr = `${functionObj.mrhString}_${outputFieldsArr[i]}_${
                            j + 1
                        }|orbOutVal`;
                        FUME.print(`orbOutStr:- ${orbOutStr} `);
                        FUME.USRHK('setOrbOut', orbOutStr);
                    }
                }
            }

            if (functionObj.createDataFile === 'Y') {
                let fileName =
  functionObj.dataFileName.trim() ||
  LibCommonB001.getUniqueFileNameB(
      functionObj.dataFileNamePattern,
      functionObj.dataFileExtn
  );
                urhkOp = FUME.system('> ' + fileName);
                let writeStr;
                let writeStrArr = [];
                for (let j = 0; j < mrhStringArr; j++) {
                    writeStr = '';
                    for (let i = 0; i < outputFieldsArr.length; i++) {
                        orbOutVal = mrhStringArr[j][outputFieldsArr[i]] || 'NULL';
                        orbOutStr = `${functionObj.mrhString}_${outputFieldsArr[i]}_${
                            j + 1
                        }|orbOutVal`;
                        FUME.print(`orbOutStr:- ${orbOutStr} `);
                        FUME.USRHK('setOrbOut', orbOutStr);
                        if (i === 0) {
                            writeStr = mrhStringArr[j][outputFieldsArr[i]];
                        } else {
                            writeStr =
        writeStr +
        functionObj.dataFileDelimiter +
        mrhStringArr[j][outputFieldsArr[i]];
                        }
                    }
                    FUME.print(`writeStr :- ${writeStr}`);
                    writeStrArr.push(writeStr);
                }
                urhkOp = LibCommonB001.addDataToFileB(fileName, writeStrArr);
            }
        }

        if (functionObj.clearFields === 'Y') {
            functionObj.outputFields = undefined;
            functionObj.sqlQuery = undefined;
            functionObj.bindVal = undefined;
            functionObj.mrhString = undefined;
            functionObj.createDataFile = undefined;
            functionObj.dataFileNamePattern = undefined;
            functionObj.dataFileExtn = undefined;
            functionObj.dataFileName = undefined;
            functionObj.dataFileDelimiter = undefined;
            functionObj.dataFileDelimiter = undefined;
        }
        FUME.print('End Function fetchCursorDataB');
        return true;
    }
    // ENDFUNCTION fetchCursorDataB
    // START FUNCTIONLIST
    return {
        versionLibCommonB002,
        getFieldValuesfromSRVStructB,
        getCallingMenuOptionB,
        getInputSolSetIdFromAgrumentsB,
        mandatoryCheckB,
        storeBancsInparamFields,
        restoreBancsInparamFields,
        verifyRecordsWithMODB,
        chkMandatorySRVInputsB,
        chkNonMandatorySRVInputsB,
        genSpbxBasedLstFileB,
        spbxReportGenerationB,
        checkValueInListB,
        checkDuplicateRecB,
        handleRecordVerificationB,
        handleTableDataMovementB,
        sqlQueryBasedReportGenerationB,
        genReportExecB,
        setUrhkInpNMRB,
        setUrhkInpMRB,
        execSrvNoCommitB,
        setFieldValueForSRVNMRB,
        getMultirecCountFromSRVB,
        appendONSCustDataWithInpStrB,
        genReportB,
        genSqlQueryBasedLstFileB,
        getFieldValueFromSRVNMRB,
        copyCreateOptionalFieldB,
        com_mitB,
        roll_backB,
        fetchCursorDataB
    };
    // END FUNCTIONLIST
})();
