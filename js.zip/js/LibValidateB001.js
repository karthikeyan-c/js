import { LibCommonB001 } from 'LibCommonB001.js';
import { LibCommonB002 } from 'LibCommonB002.js';
import { FUME } from 'FUME.js';

export var LibValidateB001 = (function () {
    var globalBankId = FUME.getrepValue('BANCS', 'STDIN', 'contextBankId');
    // STARTFUNCTION LibValidateB001
    /**
     *
     *@returns {string} version of the library
     */
    function versionLibValidateB001() {
        // javascript-obfuscator:disable
        const version = '20200130095100';
        // javascript-obfuscator:enable
        return version;
    }
    // ENDFUNCTION LibValidateB001
    // STARTFUNCTION isValidRefCodeB
    /**
     *
     *
     * @param {*} dataObj object with required inputs
     * @param {*} dataObj.lrcOrRrc valid values LRDCM/RRCDM
     * @param {*} dataObj.refRecType reference type
     * @param {*} dataObj.refCode reference code
     * @returns {boolean} true/false
     */
    function isValidRefCodeB(dataObj) {
        let retVal = false;
        let urhkOp = '';
        LibCommonB001.setErrorFieldsB(dataObj);
        let mandFlds = ['lrcOrRrc', 'refRecType', 'refCode'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dataObj, mandFlds)) {
            return retVal;
        }
        const validType = ['LRCDM', 'RRCDM'];
        if (!(validType.includes(dataObj.lrcOrRrc))) {
            LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'CDIVRC0001', '', '');
            return retVal;
        }
        let maxRefRecTypeLen = (dataObj.lrcOrRrc === 'LRCDM') ? 5 : 2;
        let maxRefCodeLen = (dataObj.lrcOrRrc === 'RRCDM') ? 16 : 5;
        if (dataObj.refRecType.length > maxRefRecTypeLen) {
            LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'CDIVRC0004', '', '');
            return retVal;
        }
        if (dataObj.refCode.length > maxRefCodeLen) {
            LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'CDIVRC0005', '', '');
            return retVal;
        }

        if (dataObj.lrcOrRrc === 'RRCDM') {
            urhkOp = FUME.USHRK('B2k_valRefCode', dataObj.refRecType + '|' + dataObj.refCode);
            urhkOp = (urhkOp === 0);
            if (!urhkOp) {
                LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'CDIVRC0002', '', '');
            }
            dataObj.refDesc = FUME.getrepValue('BANCS', 'OUTPARAM', 'refDesc');
            retVal = urhkOp;
        }
        if (dataObj.lrcOrRrc === 'LRCDM') {
            let dObj = {};
            let bankId = FUME.getrepValue('BANCS', 'STDIN', 'contextBankId');
            dObj.outputFields = 'refDesc';
            dObj.columnNames = 'REF_DESC';
            dObj.tableName = 'LRCT';
            dObj.whereFields = ['REF_CODE', 'REF_REC_TYPE', 'BANK_ID', 'DEL_FLG'];
            dObj.whereValues = [dataObj.refCode, dataObj.refRecType, bankId, 'N'];
            retVal = LibCommonB001.selectFromTableB(dObj);
            if (retVal) {
                dataObj.refDesc = dObj.refDesc;
            } else {
                LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'CDIVRC0002', '', '');
            }
        }
        return retVal;
    }
    // ENDFUNCTION isValidRefCodeB
    // STARTFUNCTION isValidBankBranchCodeB
    /**
     *
     *
     * @param {*} dataObj object with required inputs
     * @param {*} dataObj.lrcOrRrc valid values LRDCM/RRCDM
     * @param {*} dataObj.refRecType reference type
     * @param {*} dataObj.refCode reference code
     * @returns {boolean} true/false
     */
    function isValidBankBranchCodeB(dataObj) {
        let urhkOp = false;
        let mandFlds = ['bankCode', 'branchCode'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dataObj, mandFlds)) {
            return urhkOp;
        }
        urhkOp = FUME.USHRK('B2k_valBankBranchCode', dataObj.bankCode + '|' + dataObj.branchCode);
        urhkOp = (urhkOp === 0);
        if (urhkOp) {
            dataObj.BranchName = LibCommonB001.copyOutparamFieldB('BranchName');
            dataObj.ShortName = LibCommonB001.copyOutparamFieldB('ShortName');
            dataObj.Addr1 = LibCommonB001.copyOutparamFieldB('Addr1');
            dataObj.Addr2 = LibCommonB001.copyOutparamFieldB('Addr2');
            dataObj.Addr3 = LibCommonB001.copyOutparamFieldB('Addr3');
            dataObj.CityCode = LibCommonB001.copyOutparamFieldB('CityCode');
            dataObj.StateCode = LibCommonB001.copyOutparamFieldB('StateCode');
            dataObj.CountryCode = LibCommonB001.copyOutparamFieldB('CountryCode');
            dataObj.TelexNumber = LibCommonB001.copyOutparamFieldB('TelexNumber');
            dataObj.PhoneNumber = LibCommonB001.copyOutparamFieldB('PhoneNumber');
            dataObj.FaxNumber = LibCommonB001.copyOutparamFieldB('FaxNumber');
            dataObj.BcbCode = LibCommonB001.copyOutparamFieldB('BcbCode');
            dataObj.FbrFlg = LibCommonB001.copyOutparamFieldB('FbrFlg');
            dataObj.DaysForValueDate = LibCommonB001.copyOutparamFieldB('DaysForValueDate');
            dataObj.MicrCenterCode = LibCommonB001.copyOutparamFieldB('MicrCenterCode');
            dataObj.MicrBankCode = LibCommonB001.copyOutparamFieldB('MicrBankCode');
            dataObj.MicrBranchCode = LibCommonB001.copyOutparamFieldB('MicrBranchCode');
        }
        return urhkOp;
    }
    // ENDFUNCTION isValidBankBranchCodeB
    // STARTFUNCTION isStringNumericB
    /**
     *
     *
     * @param {*} inputString value to check if it is a numeric string
     * @returns {boolean} true/false
     */
    function isStringNumericB(inputString) {
        let urhkOp = FUME.USRHK('B2k_isStringNumeric', inputString);
        urhkOp = urhkOp === 0;
        return urhkOp;
    }
    // ENDFUNCTION isStringNumericB
    // STARTFUNCTION isValidBankCodeB
    /**
     *
     *
     * @param {*} dataObj data object
     * @param {*} dataObj.bankCode value to check if valid bank code
     * @returns {boolean} true/false
     */
    function isValidBankCodeB(dataObj) {
        let urhkOp = false;
        let mandFlds = ['bankCode'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dataObj, mandFlds)) {
            return urhkOp;
        }
        urhkOp = FUME.USRHK('B2k_valBankCode', dataObj.bankCode);
        urhkOp = urhkOp === 0;
        if (urhkOp) {
            dataObj.BankName = LibCommonB001.copyOutparamFieldB('BankName');
        }
        return urhkOp;
    }
    // ENDFUNCTION isValidBankCodeB
    // STARTFUNCTION isValidCifOrCustB
    /**
     *
     *
     * @param {*} dataObj data object
     * @param {*} dataObj.custOrCifId CIF ID/CUST ID to be validated
     * @param {*} dataObj.cifType CIF Type Valid cifTypes are RETCUST/CORPCUST/RETNONCUST/CORPCUST"
     * @param {*} dataObj.custOrCifFlag flag to check if CIF or CUST ID entered. Valid Values  CIFID/CUSTID
     * @returns {boolean} true/false
     */
    function isValidCifOrCustB(dataObj) {
        let retVal = false;
        let bankId = dataObj.bankId || globalBankId;
        let mandFlds = ['custOrCifId', 'custOrCifFlag'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dataObj, mandFlds)) {
            return retVal;
        }

        let optFlds = ['cifType'];
        LibCommonB002.chkNonMandatorySRVInputsB(dataObj, optFlds);
        const custOrCifFlagValidValues = ['CIFID', 'CUSTID'];
        if (!(custOrCifFlagValidValues.includes(dataObj.custOrCifFlag))) {
            LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', 'Invalid Value for custOrCifFlag. Should be CIFID/CUSTID', '');
        }

        if (dataObj.cifType !== '') {
            const cifTypeValidValues = ['RETCUST', 'CORPCUST', 'RETNONCUST', 'CORPCUST'];
            if (!(cifTypeValidValues.includes(dataObj.cifType))) {
                LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', 'Invalid Value for cifType. Should be RETCUST/CORPCUST/RETNONCUST/CORPCUST', '');
            }
        }
        let errMsg = '';
        let dObj = {};
        dObj.outputFields = ['custId', 'isVerified', 'corpId'];
        dObj.columnNames = ['CUST_ID', 'ENTITY_CRE_FLG', 'CORP_ID'];
        dObj.tableName = 'CMG';
        dObj.whereValues = [dataObj.custOrCifId, bankId];
        if (dataObj.custOrCifFlag === 'CUSTID') {
            dObj.whereFields = ['CUST_ID', 'BANK_ID'];
            errMsg = 'Invalid Cust Id';
        }
        if (dataObj.custOrCifFlag === 'CIFID') {
            dObj.whereFields = ['CIF_ID', 'BANK_ID'];
            errMsg = 'Invalid Cif Id';
        }
        retVal = LibCommonB001.selectFromTableB(dObj);
        retVal = (retVal === 0);
        if (retVal) {
            dataObj.custId = dObj.custId;
            dataObj.cifId = dObj.custOrCifId;
            dataObj.isVerified = dObj.isVerified;
            dataObj.corpId = dObj.corpId;
            dataObj.retOrCorp = (dObj.corpId !== '') ? 'C' : 'R';
        } else if (dataObj.custOrCifFlag === 'CUSTID') {
            LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', errMsg, '');
        }

        if ((!retVal) && (dataObj.custOrCifFlag === 'CIFID')) {
            let dObj = {};
            dObj.outputFields = ['isVerified'];
            dObj.columnNames = ['CASE RECORDSTATUS WHEN N\'\'||\'A\' THEN \'Y\' ELSE \'N\' END'];
            dObj.tableName = 'CRMUSER.NON_CUSTOMERS';
            dObj.whereFields = ['ORGKEY', 'BANK_ID'];
            dObj.whereValues = [dataObj.custOrCifId, bankId];
            retVal = LibCommonB001.selectFromTableB(dObj);
            retVal = (retVal === 0);
            if (retVal) {
                dataObj.custId = dObj.custId;
                dataObj.cifId = dObj.custOrCifId;
                dataObj.isVerified = dObj.isVerified;
                dataObj.corpId = dObj.corpId;
                dataObj.retOrCorp = 'RN';
            } else {
                let dObj = {};
                dObj.outputFields = ['isVerified'];
                dObj.columnNames = ['CASE RECORD_STATUS WHEN N\'\'||\'A\' THEN \'Y\' ELSE \'N\' END'];
                dObj.tableName = 'CRMUSER.CORPORATE';
                dObj.whereFields = ['CORP_KEY', 'ENTITY_TYPE', 'BANK_ID'];
                dObj.whereValues = [dataObj.custOrCifId, 'Non Customer', bankId];
                retVal = LibCommonB001.selectFromTableB(dObj);
                retVal = (retVal === 0);
                if (retVal) {
                    dataObj.custId = dObj.custId;
                    dataObj.cifId = dObj.custOrCifId;
                    dataObj.isVerified = dObj.isVerified;
                    dataObj.corpId = dObj.corpId;
                    dataObj.retOrCorp = 'CN';
                } else {
                    LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', errMsg, '');
                    return retVal;
                }
            }
            if (dataObj.isVerified !== 'N') {
                if ((dataObj.cifType === 'RETCUST') && (dataObj.retOrCorp !== 'R')) {
                    LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', 'Invalid Retail CIF', '');
                    return false;
                }
                if ((dataObj.cifType === 'CORPCUST') && (dataObj.retOrCorp !== 'C')) {
                    LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', 'Invalid Corporate CIF', '');
                    return false;
                }
                if ((dataObj.cifType === 'RETNONCUST') && (dataObj.retOrCorp !== 'RN')) {
                    LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', 'Invalid Retail Non Customer CIF', '');
                    return false;
                }
                if ((dataObj.cifType === 'CORPNONCUST') && (dataObj.retOrCorp !== 'CN')) {
                    LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', 'Invalid Corporate Non Customer CIF', '');
                    return false;
                }
                if (dataObj.retOrCorp !== '') {
                    LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', errMsg, '');
                    return false;
                }
            }
        }

        return retVal;
    }
    // ENDFUNCTION isValidCifOrCustB
    // STARTFUNCTION isValidDateB
    /**
     *
     *
     * @param {*} inputDate date to be validated
     * @param {string} [dateFormat='DD-MM-YYYY'] date format to be validated against
     * @returns {boolean} true/false
     */
    function isValidDateB(inputDate, dateFormat = 'DD-MM-YYYY') {
        let retVal = false;

        return retVal;
    }
    // ENDFUNCTION isValidDateB
    // START FUNCTIONLIST
    return {
        versionLibValidateB001,
        isValidRefCodeB,
        isValidBankBranchCodeB,
        isStringNumericB,
        isValidCifOrCustB,
        // //isValidInvestmentIdB,
        isValidDateB,
        isValidBankCodeB
    };
    // END FUNCTIONLIST
})();
