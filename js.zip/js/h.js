let promise = new Promise((resolve, reject) => {
		console.log("inside promise");
		setTimeout(() => resolve("done!"), 2000)
		console.log("outside promise");
});
promise.then(console.log);
console.log("after promise");

let kk = async function(){
	console.log("inside KK function");
	return("function KK return");
}
console.log("after async function defn promise");

kk().then(console.log);
console.log("after everything");
