var sleep = require('system-sleep');
let promise = new Promise(function(resolve, reject) {
  console.log("inside promise" + new Date());
// Usage!
  sleep(5000);
  resolve("done!" + new Date());
});

promise.then(
  result => console.log(result), // shows "done!" after 1 second
  error => console.log(error) // doesn't run
);

console.log("after promise dec" + new Date());
