export const mmsg = (function () {
    function mmsgCodes() {
        return [
            {
                code: 'MSG0316955',
                desc: 'Bond Sub Category must be entered.'
            },
            {
                code: 'MSG0302300',
                desc: 'End Date cannot be later than LC expiry date'
            },
            {
                code: 'CDAM00001',
                desc: 'Invalid input at position %s'
            },
            {
                code: 'CDGMCFS001',
                desc: 'Unable to fetch multirec count for'
            },
            {
                code: 'CMSG00261',
                desc: 'Unable to fetch the parameter value.'
            },
            {
                code: 'CDIDVF0001',
                desc: 'Input Date format should be DD-MM-YYYY or DD/MM/YYYY'
            },
            {
                code: 'CDIDVF0002',
                desc: 'Date format for validation should be DD-MM-YYYY or DD/MM/YYYY'
            },
            {
                code: 'CDIDVF0003',
                desc: 'Input Date format should be '
            },
            {
                code: 'CDIVRC0001',
                desc: 'Invalid Ref Code Option, it should be either LRCDM OR RRCDM'
            },
            {
                code: 'CDIVRC0002',
                desc: 'Invalid RRCDM Code'
            },
            {
                code: 'CDIVRC0003',
                desc: 'Invalid LRCDM Code'
            },
            {
                code: 'CDIVRC0004',
                desc: 'Ref rec type size exceeded'
            },
            {
                code: 'CDIVRC0005',
                desc: 'Ref code size exceeded'
            },
            {
                code: 'CDSSL0001',
                desc: 'Length of split string cannot be zero'
            },
            {
                code: 'CDGIPR0001',
                desc: 'Invalid Account Number'
            },
            {
                code: 'CDGIPR0002',
                desc: 'Invalid Dr/Cr indicator value'
            },
            {
                code: 'CDUPL00001',
                desc: 'Lien cannot be marked on '
            },
            {
                code: 'CDTMVF0001',
                desc: 'Given From time format is not supported'
            },
            {
                code: 'CDTMVF0002',
                desc: 'Given To time format is not supported'
            },
            {
                code: 'CDECOF0001',
                desc: 'Not able to get the input file'
            },
            {
                code: 'CDECOF0002',
                desc: 'File execution failed'
            },
            {
                code: 'CCCTF00001',
                desc: 'Valid values for fileConcatInd are FORMAT_BASED and FIXED_NAME'
            },
            {
                code: 'CCCTF00002',
                desc: 'Valid values for filesType is TEXT'
            },
            {
                code: 'CDSMX00001',
                desc: 'Atleast one file required for attachment'
            },
            {
                code: 'CDSMX00003',
                desc: 'File needed for attachment not found'
            },
            {
                code: 'CDSMX00004',
                desc: 'File Path needed for attachment not found'
            },
            {
                code: 'CDSMX00002',
                desc: 'Mailx function execution failed'
            },
            {
                code: 'CDEXCP0001',
                desc: 'Exception type must be FIN_TRAN_EXCP/NON_FIN_TRAN_EXCP/CUST_EXCP'
            },
            {
                code: 'CDEXCP0002',
                desc: 'Invalid Exception Code'
            },
            {
                code: 'CDEXCP0004',
                desc: 'Unable to raise exception'
            },
            {
                code: 'CDEXCP0003',
                desc: 'Financial transaction flag must be Y/N'
            },
            {
                code: 'CDRND0001',
                desc: 'Rounding off operation failed for input number'
            },
            {
                code: 'CDIVB00001',
                desc: 'Invalid Bacid'
            },
            {
                code: 'CDUSR00001',
                desc: 'Message is not created for SMHRecord'
            },
            {
                code: 'CDBIC00001',
                desc: 'Invalid Bank/Branch/PaysysId combination'
            },
            {
                code: 'CDGMCFS001',
                desc: 'Unable to fetch multirec count.'
            },
            {
                code: 'CDUPR00001',
                desc: 'Duplicate Record Exists For Combination'
            }
        ];
    }
    return {
        mmsgCodes
    };
})();
