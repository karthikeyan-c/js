// _FINUMBRELLA_JS_START_HERE
export var FUME = (function () {
    /**
   *
   * @param {string} jsfilename
   *
   * @summary Includes functions of given file for execution
   * @example
   * 		include( "a.js");
   *
   */
    function include(jsfilename) {
        return FinDefaultJSObj.include(jsfilename);
    }

    /**
   *
   * @param {string} value
   *
   * @summary	Prints the value passed to stdout
   * 		Can be redirected within code
   * @example
   * 		var a = "HELLOWORLD";
   *		print(a);
   */
    function print(value) {
        return FinDefaultJSObj.print(value);
    }

    /**
   * @param {string} repname
   * @param {string} classname
   * @param {string} fieldname
   * @param {string|number} fieldvalue
   *
   * @summary	Set the given fieldvalue to repname.classname.fieldname
   * @example
   * 		setrepValue("BANCS","INPARAM","ACID","SB12341");
   *
   */
    function setrepValue(
        repname,
        classname,
        fieldname,
        fieldvalue,
        _finfilename = '',
        _finlinenum = 0
    ) {
        return FinDefaultJSObj.setREPValue(
            repname,
            classname,
            fieldname,
            fieldvalue
        );
    }

    /**
   * @param {string} repname
   * @param {string} classname
   * @param {string} fieldname
   * @return {string|number} fieldvalue
   *
   * @summary	Gets the value set in repname.classname.fieldname
   * @example
   * 		var userid=getrepValue("BANCS","INPUT","USERID");
   *
   */
    function getrepValue(
        repname,
        classname,
        fieldname,
        _finfilename = '',
        _finlinenum = 0
    ) {
        return FinDefaultJSObj.getREPValue(repname, classname, fieldname);
    }

    /**
   *
   * @param {string} urhkname
   * @param {string} inputvalue
   * @return {integer} numbervalue
   *
   * @summary	Does a Usrhk Call mapped to urhkname with input as inputvalue
   * @example
   * 		var ret = USRHK( "B2kPrintRepos","BANCS");
   */
    function USRHK(urhkname, inputvalue, _finfilename = '', _finlinenum = 0) {
        return FinDefaultJSObj.USRHK(urhkname, inputvalue);
    }

    /**
   *
   * @param {string} repname
   *
   * @summary	Creates a Repository with the given inputname
   * @example
   * 		createRep("CUSTREP");
   */
    function createRep(repname, _finfilename = '', _finlinenum = 0) {
        return FinDefaultJSObj.CreateREP(repname);
    }

    /**
   *
   * @param {string} repname
   *
   * @summary	Delete the repository with the given name
   * @example
   * 		deleteRep("CUSTREP");
   */
    function deleteRep(repname, _finfilename = '', _finlinenum = 0) {
        return FinDefaultJSObj.DeleteREP(repname);
    }

    /**
   *
   * @param {string} repname
   * @param {string} classname
   *
   * @summary	Create string class with classname inside the repostiory repname
   * @example
   * 		createClass("CUSTREP", "CUSTCLASS");
   */
    function createClass(repname, classname, _finfilename = '', _finlinenum = 0) {
        return FinDefaultJSObj.CreateClass(repname, classname, '5');
    }

    /**
   *
   * @param {string} repname
   * @param {string} classname
   *
   * @summary	Delete Class with classname from repository repname
   * @example
   * 		deleteClass( "CUSTREP" , "CUSTCLASS" );
   */
    function deleteClass(repname, classname, _finfilename = '', _finlinenum = 0) {
        return FinDefaultJSObj.DeleteClass(repname, classname);
    }

    /**
   *
   * @param {string} repname
   * @return {integer} 1|0
   *
   * @summary	Checks if repostiory with repname exists (1) or not (0)
   * @example
   * 		var ret = isRepExists("BANCS");
   *
   */
    function isRepExists(repname, _finfilename = '', _finlinenum = 0) {
        return FinDefaultJSObj.IsRepExists(repname);
    }

    /**
   *
   * @param {string} repname
   * @param {string} classname
   * @return {integer} 1|0
   *
   * @summary	Check if classname exists(!) or not(0) inside rep (repname)
   * @example
   * 		var ret = isClassExists( "BACNS" , "INPUT");
   *
   */

    function isClassExists(
        repname,
        classname,
        _finfilename = '',
        _finlinenum = 0
    ) {
        return FinDefaultJSObj.IsClassExists(repname, classname);
    }

    /**
   *
   * @param {string } repname
   * @param {string } classname
   * @param {string } fieldname
   * @return {integer} 1|0
   *
   * @summary	Check is repname.classname.fieldname exists (1) or not (0)
   * @example
   * 		var ret= isFieldExists( "BANCS","INPARAM","ACID");
   *
   */
    function isFieldExists(
        repname,
        classname,
        fieldname,
        _finfilename = '',
        _finlinenum = 0
    ) {
        return FinDefaultJSObj.IsFieldExists(repname, classname, fieldname);
    }

    /**
   *
   * @param {string } urtnname
   * @param {string } inputvalue
   *
   * @summary	Calls a user routine mapped with urtnname passing inputvalue as input
   * @example
   * 		URTN("Customfunc","Custominput");
   *
   */
    function URTN(urtnname, inputvalue, _finfilename = '', _finlinenum = 0) {
        return FinDefaultJSObj.URTN(urtnname, inputvalue);
    }

    /**
   * @param {string} libname
   *
   * @summary	Loads the library mentioned in libname( later used for urtn)
   * @example
   * 		LIBNAME("customso.so");
   */
    function LIBNAME(libname, _finfilename = '', _finlinenum = 0) {
        return FinDefaultJSObj.LIBNAME(libname);
    }

    /**
   *
   * @param {string} paramstring
   * @return {string} paramvalue
   *
   * @summary	Returns the environment variable set of paramstring
   * @example
   * 		var hostname=getEnv("HOSTNAME");
   */
    function getEnv(paramstring) {
        return FinDefaultJSObj.GETENV(paramstring);
    }

    /**
   *
   * @param {string} commandstring
   * @return {number} status
   *
   * @summary	Executes the given command and returns the status of it
   * @example
   * 		var istatus = system("ls");
   */
    function system(commandstring) {
        return FinDefaultJSObj.SYSTEM(commandstring);
    }

    /**
   *
   * @param {string} modname
   * @return {Object} exposedobj
   *
   * @summary	Load the given cmodule extension modname.so and returns exposedobj
   * @example
   * 		var mod = CLOAD("finfs");
   * 		mod.open(filename);
   */
    function CLOAD(modname) {
        return FinDefaultJSObj.CLOAD(modname);
    }

    return {
        include,
        print,
        setrepValue,
        getrepValue,
        createRep,
        deleteRep,
        createClass,
        deleteClass,
        isRepExists,
        isClassExists,
        isFieldExists,
        USRHK,
        getEnv,
        system,
        CLOAD,
        URTN
    // ADD Exposed functions here
    };
})();
// _FINUMBRELLA_JS_END_HERE
