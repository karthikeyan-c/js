import {LibCommonB002} from "./LibCommonB002.js";


var dble = FUME.getrepValue("BANCS","STDIN","contextBankId");
FUME.print(dble);

var sgl = FUME.getrepValue('BANCS','STDIN','contextBankId');
FUME.print(sgl);




		
