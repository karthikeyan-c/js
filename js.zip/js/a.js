async function myasync(){
	console.log("inside myasync" + new Date());
	//sleep(1000);
        return "sleep done" + new Date();
}

console.log("before myasync" + new Date());
myasync().then(console.log);
console.log("after myasync" + new Date());
