// node cc.js /DBSHK_BE/Fin1110/BE/Finacle/FC/app/CDCI_LOGS/JANEY1/SG_FD_ctdpmsgCrit_mn01.js_14468.trc
// node cc.js /DBSHK_BE/Fin1110/BE/Finacle/FC/app/CDCI_LOGS/JANEY1/

const fs = require('fs');
const path = require('path');
/**
 *
 *
 * @param {String} fileName
 * @param {String} dataToWrite
 */
function writeFile(fileName, dataToWrite) {
  const fd = fs.openSync(fileName, 'a');
  fs.appendFile(fileName, dataToWrite, err => {
    if (err) throw err;
  });
  fs.closeSync(fd);
}

/**
 *
 *
 * @param {*} dirPath
 * @returns
 */
function rmDir(dirPath) {
  try {
    var files = fs.readdirSync(dirPath);
  } catch (e) {
    return;
  }
  if (files.length > 0) {
    for (let i = 0; i < files.length; i++) {
      const filePath = `${dirPath}/${files[i]}`;
      if (fs.statSync(filePath).isFile()) {
        fs.unlinkSync(filePath);
      } else {
        rmDir(filePath);
      }
    }
  }
  // fs.rmdirSync(dirPath);
}

/**
 *
 *
 * @param {*} fileNameWithPath
 */
function trcFileToJson(fileNameWithPath) {
  const trcFile = fileNameWithPath;
  const trcFileName = path.basename(trcFile);
  // console.log('trcFile', trcFile);

  const rawdata = fs.readFileSync(trcFile, 'ascii');
  const newRawData = `[${rawdata}]`;
  const finalRawData = newRawData.replace(new RegExp('}{', 'g'), '},{');
  // console.log(rawdata);
  const trcObj = JSON.parse(finalRawData);
  // var trcObjCC = [];

  // console.log("trcObj length", trcObj.length);
  // console.log("trcFileName.split('.js')", trcFileName.split('.js'));
  const trcFileNameArr = trcFileName.split('.js');
  const jsFileNameWithoutExtn = trcFileNameArr[0];
  const pidFull = trcFileNameArr[1];
  // console.log('pidFull', pidFull);
  const pid = pidFull.split('.trc')[0];

  for (let i = 0; i < trcObj.length; i++) {
    // trcObjCC.push(trcObj[i].result);
    // Creating the code coverage file as per c8 reuirement.
    // console.log("JSON.stringify(trcObj[i].result)", JSON.stringify(trcObj[i].result.result));
    writeFile(
      `${__dirname}/coverage/tmp/${jsFileNameWithoutExtn}${pid}_${i}.json`,
      JSON.stringify(trcObj[i].result)
    );
  }
}

// let fileOrDir = process.argv[2];
// let fileNameSingle = process.argv[3];
// let dirName = process.argv[3];
const isDir =
  fs.existsSync(process.argv[2]) && fs.lstatSync(process.argv[2]).isDirectory();
const fileOrDir = isDir == true ? 'D' : 'F';
const fileNameSingle = process.argv[2];
const dirName = process.argv[2];

rmDir(`${__dirname}/coverage/tmp/`);

if (fileOrDir === 'D') {
  try {
    const files = fs.readdirSync(dirName);
    // console.log(files);
    for (let f = 0; f < files.length; f++) {
      const fileName = files[f];
      if (fileName.endsWith('.trc') && fileName.includes('.js')) {
        trcFileToJson(`${dirName}/${fileName}`);
      }
    }
  } catch (err) {
    console.log(err);
  }
} else {
  trcFileToJson(fileNameSingle);
}

// calling c8 report to generate summary report
const cp = require('child_process');

cp.exec(
  'c8 report --reporter=html --reporter=text --reporter=json-summary',
  (err, stdout, stderr) => {
    if (err) {
      // some err occurred
      console.error(err);
    } else {
      // the *entire* stdout and stderr (buffered)

      const rawResult = fs.readFileSync(
        './coverage/coverage-summary.json',
        'ascii'
      );
      // console.log(rawdata);
      const resultObj = JSON.parse(rawResult);

      console.log(resultObj);

      console.log(
        '**********************************************************************'
      );
      console.log(`\nstdout: \n\n${stdout}\n`);
      console.log(
        '**********************************************************************'
      );
      console.log(`\n\nstderr: \n${stderr}`);
    }
  }
);
// calling c8 report to show output on console

/* Back up Code

/*const replaceDataArr = rawdata.replace(/}}{/g, '}}\n{').split('\n');
for (let i = 0; i < replaceDataArr.length; i++) {
  // console.log(`replaceDataArr[${i}]`, replaceDataArr[i]);
  const trcObj = JSON.parse(replaceDataArr[i]);
  // console.log('trcObj:', trcObj);
  const trcObjCC = trcObj.result;
  // Getting the Result object from the v8 trc
  // console.log('trcObjCC:', trcObjCC);

  // Creating the code coverage file as per c8 reuirement.
  writeFile(
    `${__dirname}/coverage/tmp/${jsFileNameWithoutExtn}-${i}.json`,
    JSON.stringify(trcObjCC)
  );
}
*/
/*
//Different Reported options are available at
//https://github.com/istanbuljs/istanbuljs/tree/master/packages/istanbul-reports/lib
var combine = require('istanbul-combine');

var opts = {
  dir: 'coverage/',                       // output directory for combined report(s)
  pattern: 'coverage/tmp/' + jsFileNameWithoutExtn + '*.json',   // json reports to be combined
  print: 'none',                      // print to the console (summary, detail, both, none)
  base:'/',
  reporters: {
    //html: {  },
    json: {  }
  }
};

combine(opts, function(err) { });         // async with node style completion callback
combine(opts).then();           // async with promise return value
combine.sync(opts);

try {
  items = file.readdirSync("./screenshotsForMail");
  for (var f = 0; f < items.length; f++) {
    randomNum = Math.random().toString(36).substr(4, 6).toUpperCase()
    fileName = items[f];
    fileDesc = fileName.split(".png")[0];

    path = "screenshotsForMail/" + fileName;

    //console.log(randomNum, fileName, fileDesc, path);

    dynamicHtmlContent += '<p class=MsoNormal> <span style="font-size:11.5pt;font-family:Rockwell;  ">         <o:p>&nbsp;</o:p>        </span> </p>';
    dynamicHtmlContent += '<p class=MsoNormal> <span style="font-size:11.5pt;font-family:Rockwell;  ">         <o:p><b>Failed Test Case :- ' + fileDesc + '</b></o:p>        </span> </p>';
    dynamicHtmlContent += '<p class=MsoNormal> <span style="font-size:11.5pt;font-family:Rockwell;  ">         <o:p>&nbsp;</o:p>        </span> </p>';

    dynamicHtmlContent += '<img src="cid:' + randomNum + '"        style="border: 1px solid black" sizing="contain" width="955" alt="Smiley face">'

    dynamicHtmlContent += '<p class=MsoNormal> <span style="font-size:11.5pt;font-family:Rockwell;  ">         <o:p>&nbsp;</o:p>        </span> </p>';

    attachObj.push({
      filename: fileName,
      path: path,
      cid: randomNum
    });

  }
} catch (err) {
  console.log(err);
}


*/
