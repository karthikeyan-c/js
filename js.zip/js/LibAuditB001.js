import { FUME } from 'FUME.js';
import { LibCommonB001 } from 'LibCommonB001.js';
import { LibCommonB002 } from 'LibCommonB002.js';

export var LibAuditB001 = (function () {
    // STARTFUNCTION versionLibAuditB001
    /**
   * @returns {String} version dummy
   * @summary Dummy function to get the function of the file.
   *
   */
    function versionLibAuditB001() {
        FUME.print('Begin Function versionLibAuditB001');
        // javascript-obfuscator:disable
        const version = '20200130095100';
        // javascript-obfuscator:enable

        FUME.print('End Function versionLibAuditB001');
        return version;
    }
    // ENDFUNCTION versionLibAuditB001

    // STARTFUNCTION getAuditRefNumForMaker
    /**
   *
   *
   * @param {string} [useSameRefNum=""] Flag to initialize Audit or not
   * @returns {boolean} true/false
   * @summary Function to initialize Audit
   * @example
   * 		getAuditRefNumForMaker('Y/N')
   */
    function getAuditRefNumForMaker(useSameRefNum = '') {
        FUME.print('Begin Function getAuditRefNumForMaker');
        if (useSameRefNum === 'Y') {
            FUME.USRHK('InitAudit', '');
        }
        FUME.print('End Function getAuditRefNumForMaker');
        return true;
    }
    // ENDFUNCTION getAuditRefNumForMaker

    /**
   *
   *
   * @param {*} functionObj function Object
   * @returns {boolean} true/false
   * @summary Function to insert data into ADT
   * @example
   * 		insertAuditB(functionObj);
   */
    function insertAuditB(functionObj) {
        FUME.print('Begin Function insertAuditB');

        let mandFlds;
        mandFlds = ['funcCode', 'tableName', 'tableKey'];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB002.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        mandFlds = ['acctNum', 'glSubHeadCode', 'autoVerify', 'useSameRefNum'];
        LibCommonB002.chkNonMandatorySRVInputsB(functionObj, mandFlds);

        let funcCode = functionObj.funcCode;
        let tableName = functionObj.tableName;
        let tableKey = functionObj.tableKey;
        let acctNum = functionObj.acctNum;
        let glSubHeadCode = functionObj.glSubHeadCode;
        let autoVerify = functionObj.autoVerify;
        let useSameRefNum = functionObj.useSameRefNum;

        let refNum;

        let bankId = FUME.getrepValue('BANCS', 'STDIN', 'contextBankId');

        getAuditRefNumForMaker(useSameRefNum);
        refNum = '';
        FUME.print(tableName);
        FUME.print(tableKey);
        if ((funcCode === 'V' || funcCode === 'X') && autoVerify !== 'Y') {
            let localObj = {};
            localObj.outputFields = ['ref_Num'];
            localObj.columnNames = ['ref_Num'];
            localObj.tableName = 'ADT';
            localObj.whereFields = ['TABLE_NAME', 'AUTH_ID', 'BANK_ID'];
            localObj.whereValues = [tableName, '!', bankId];
            localObj.additionalQueryString = `AND (TABLE_KEY = '${tableKey}' OR TABLE_KEY = '${tableKey}') AND ROWNUM = 1`;
            localObj.ref_Num = '';
            if (LibCommonB001.selectFromTableB(localObj)) {
                FUME.print(localObj.ref_Num);
                refNum = localObj.ref_Num;
            }
        }
        FUME.print(refNum);
        // MAx 7 Chars
        FUME.setrepValue('BANCS', 'INPARAM', 'TABLENAME', tableName);
        FUME.setrepValue('AUDIT', 'KEY', 'TABLEKEY', tableKey);
        FUME.setrepValue('BANCS', 'INPARAM', 'ACCTNUM', acctNum);
        FUME.setrepValue('BANCS', 'INPARAM', 'GLSUBHEADCODE', glSubHeadCode);
        FUME.setrepValue('BANCS', 'INPARAM', 'AUTOVERifY', autoVerify);

        // Implicit Assignments
        // SOl id is used only if ACCTNUM is not specified
        FUME.setrepValue(
            'BANCS',
            'INPARAM',
            'AUDITSOLID',
            FUME.getrepValue('BANCS', 'STDIN', 'mySolId')
        );
        FUME.setrepValue('BANCS', 'INPARAM', 'excpnFlg', 'Y');
        FUME.setrepValue('BANCS', 'INPARAM', 'OPERCODE', funcCode);
        FUME.setrepValue('BANCS', 'INPARAM', 'REFNUM', refNum);
        let urhkOp = FUME.USRHK('Audit', '');

        FUME.print('End Function insertAuditB');
        return true;
    }
    // ENDFUNCTION insertAuditB

    /**
   *
   *
   * @returns {boolean} true/false
   * @summary Function to create the Audit repository and its classes.
   */
    function initAuditB() {
        FUME.print('Begin Function initAuditB');
        LibCommonB001.createRepClassB('AUDIT', 'OLD');
        LibCommonB001.createRepClassB('AUDIT', 'NEW');
        LibCommonB001.createRepClassB('AUDIT', 'KEY');
        FUME.print('End Function initAuditB');
        return true;
    }
    // ENDFUNCTION initAuditB

    /**
   *
   *
   * @param {*} fieldName fieldName
   * @param {*} oldValue oldValue
   * @param {*} newValue newValue
   * @returns {boolean} true
   * @summary Internal function to populate value in Old and New Classes
   * @example
   *     setAuditParamB(fieldName, oldValue, newValue)
   */
    function setAuditParamB(fieldName, oldValue, newValue) {
        FUME.print('Begin Function setAuditParamB');
        FUME.setrepValue('AUDIT', 'OLD', fieldName, oldValue);
        FUME.setrepValue('AUDIT', 'NEW', fieldName, newValue);
        FUME.print('End Function setAuditParamB');
        return true;
    }
    // ENDFUNCTION setAuditParamB

    // STARTFUNCTION setTableKeyB
    /**
   *
   *
   * @param {*} fieldNames field Names Array
   * @param {*} fieldValues field Values Array
   * @returns {string} Table key String
   * @summary Function to set Table Key and return the consolidated key
   * @example
   * 		setTableKeyB(fieldNames, fieldValues);
   */
    function setTableKeyB(fieldNames, fieldValues) {
        FUME.print('Begin Function setTableKeyB');
        let counter;
        let fieldName;
        let fieldValue;
        let tableKey;

        let fieldNamesArr = [];
        let fieldValuesArr = [];

        if (typeof fieldNames === 'string') {
            fieldNamesArr = fieldNames.split('|');
        } else {
            fieldNamesArr = fieldNames;
        }

        if (typeof fieldValues === 'string') {
            fieldValuesArr = fieldValues.split('|');
        } else {
            fieldValuesArr = fieldValues;
        }

        for (let i = 0; i < fieldNamesArr.length; i++) {
            fieldName = fieldNamesArr[i];
            fieldValue = fieldValuesArr[i];
            FUME.print(fieldName);
            FUME.print(fieldValue);
            FUME.setrepValue('AUDIT', 'KEY', fieldName, fieldValue);
        }

        tableKey = fieldValuesArr.join('/');
        FUME.print('End Function setTableKeyB');
        return tableKey;
    }
    // ENDFUNCTION setTableKeyB

    // STARTFUNCTION insertAuditAddB
    /**
   *
   *
   * @param {*} functionObj function object
   * @returns {boolean} true/false
   * @summary Function to do Audit in Add Mode.
   * @example
   * 		insertAuditAddB(functionObj);
   */
    function insertAuditAddB(functionObj) {
        FUME.print('Begin Function insertAuditAddB');
        functionObj.funcCode = 'A';
        FUME.print('CALLING Audit');
        insertAuditB(functionObj);
        FUME.print('end of audit');
        FUME.print('End Function insertAuditAddB');
        return true;
    }
    // ENDFUNCTION insertAuditAddB

    // STARTFUNCTION insertAuditModifyB
    /**
   *
   *
   * @param {*} functionObj function object
   * @returns {boolean} true/false
   * @summary Function to do Audit in Modify Mode.
   * @example
   * 		insertAuditModifyB(functionObj);
   */
    function insertAuditModifyB(functionObj) {
        FUME.print('Begin Function insertAuditModifyB');
        functionObj.funcCode = 'M';
        FUME.print('CALLING Audit');
        insertAuditB(functionObj);
        FUME.print('end of audit');
        FUME.print('End Function insertAuditModifyB');
        return true;
    }
    // ENDFUNCTION insertAuditModifyB

    // STARTFUNCTION insertAuditDeleteB
    /**
   *
   *
   * @param {*} functionObj function object
   * @returns {boolean} true/false
   * @summary Function to do Audit in Delete Mode.
   * @example
   * 		insertAuditDeleteB(functionObj);
   */
    function insertAuditDeleteB(functionObj) {
        FUME.print('Begin Function insertAuditDeleteB');
        functionObj.funcCode = 'D';
        FUME.print('CALLING Audit');
        insertAuditB(functionObj);
        FUME.print('end of audit');
        FUME.print('End Function insertAuditDeleteB');
        return true;
    }
    // ENDFUNCTION insertAuditDeleteB

    // STARTFUNCTION insertAuditCopyB
    /**
   *
   *
   * @param {*} functionObj function object
   * @returns {boolean} true/false
   * @summary Function to do Audit in Copy Mode.
   * @example
   * 		insertAuditCopyB(functionObj);
   */
    function insertAuditCopyB(functionObj) {
        FUME.print('Begin Function insertAuditCopyB');
        functionObj.funcCode = 'C';
        FUME.print('CALLING Audit');
        insertAuditB(functionObj);
        FUME.print('end of audit');
        FUME.print('End Function insertAuditCopyB');
        return true;
    }
    // ENDFUNCTION insertAuditCopyB

    // STARTFUNCTION getFldsForAuditPostInsertB
    /**
   *
   *
   * @param {*} functionObj Function Object
   * @returns {boolean} true/false
   * @summary Function to Select values from Main/Mod tables and set in Old/New Repository
   * @example
   * 		getFldsForAuditPostInsertB(functionObj);
   */
    function getFldsForAuditPostInsertB(functionObj) {
        FUME.print('Begin Function getFldsForAuditPostInsertB');
        let newDataExits;
        let oldDataExits;
        let dbLongField;

        let columnName;
        let oldValue;
        let newValue;

        let mandFlds;
        mandFlds = [
            'oldDataTableName',
            'newDataTableName',
            'keyFields',
            'bindVars',
            'columnsForAudit'
        ];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB002.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        let oldDataTableName = functionObj.oldDataTableName;
        let newDataTableName = functionObj.newDataTableName;
        let keyFields = functionObj.keyFields;
        let bindVars = functionObj.bindVars;
        let columnsForAudit = functionObj.columnsForAudit;

        let keyFieldsArr = [];
        let bindVarsArr = [];
        let columnsForAuditArr = [];

        if (typeof keyFields === 'string') {
            keyFieldsArr = keyFields.split('|');
        } else {
            keyFieldsArr = keyFields;
        }

        if (typeof bindVars === 'string') {
            bindVarsArr = bindVars.split('|');
        } else {
            bindVarsArr = bindVars;
        }

        if (typeof columnsForAudit === 'string') {
            columnsForAuditArr = columnsForAudit.split('|');
        } else {
            columnsForAuditArr = columnsForAudit;
        }

        let bankId = FUME.getrepValue('BANCS', 'STDIN', 'contextBankId');

        let oldDataObj = {};
        let newDataObj = {};

        newDataExits = 'N';
        oldDataExits = 'N';

        let localObj = {};

        if (functionObj.dbLongField && functionObj.dbLongField === 'Y') {
            localObj.dbLongField = true;
        } else {
            localObj.dbLongField = false;
        }

        localObj.outputFields = columnsForAuditArr;
        localObj.columnNames = columnsForAuditArr;
        localObj.tableName = oldDataTableName;
        localObj.whereFields = keyFieldsArr;
        localObj.whereValues = bindVarsArr;
        localObj.additionalQueryString = undefined;

        if (LibCommonB001.selectFromTableB(localObj)) {
            oldDataExits = 'Y';
            for (let i = 0; i < columnsForAuditArr; i++) {
                oldDataObj[columnsForAuditArr[i]] = localObj[columnsForAuditArr[i]];
            }
        }

        LibCommonB002.restoreBancsInparamFields(localObj);

        localObj = {};

        if (functionObj.dbLongField && functionObj.dbLongField === 'Y') {
            localObj.dbLongField = true;
        } else {
            localObj.dbLongField = false;
        }

        localObj.outputFields = columnsForAuditArr;
        localObj.columnNames = columnsForAuditArr;
        localObj.tableName = newDataTableName;
        localObj.whereFields = keyFieldsArr;
        localObj.whereValues = bindVarsArr;
        localObj.additionalQueryString = undefined;

        if (LibCommonB001.selectFromTableB(localObj)) {
            newDataExits = 'Y';
            for (let i = 0; i < columnsForAuditArr; i++) {
                newDataObj[columnsForAuditArr[i]] = localObj[columnsForAuditArr[i]];
            }
        }

        if (oldDataExits === 'Y' && newDataExits === 'Y') {
            for (let i = 0; i < columnsForAuditArr; i++) {
                columnName = [columnsForAuditArr[i]];
                FUME.print(columnName);
                oldValue = oldDataObj[columnName];
                newValue = newDataObj[columnName];
                FUME.print(oldValue);
                FUME.print(newValue);

                if (oldValue !== newValue) {
                    FUME.setrepValue('AUDIT', 'OLD', columnName, oldValue);
                    FUME.setrepValue('AUDIT', 'NEW', columnName, newValue);
                    FUME.print(oldValue);
                    FUME.print(newValue);
                } else {
                    FUME.setrepValue('AUDIT', 'OLD', columnName, '');
                    FUME.setrepValue('AUDIT', 'NEW', columnName, '');
                    FUME.print(oldValue);
                    FUME.print(newValue);
                }
            }
        }

        FUME.print('End Function getFldsForAuditPostInsertB');
        return true;
    }
    // ENDFUNCTION getFldsForAuditPostInsertB
    // START FUNCTIONLIST
    return {
        versionLibAuditB001,
        getAuditRefNumForMaker,
        insertAuditB,
        initAuditB,
        setAuditParamB,
        setTableKeyB,
        insertAuditAddB,
        insertAuditModifyB,
        insertAuditDeleteB,
        insertAuditCopyB,
        getFldsForAuditPostInsertB
    };
    // END FUNCTIONLIST
})();
