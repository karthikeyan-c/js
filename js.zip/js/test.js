var values = [
    { name: 'someName1', age:1 },
    { name: 'someName2' , age:2 },
    { name: 'someName4' },
    { name: 'someName1', age:1 },
    { name: 'someName2' , age:2  }
];

var valueArr = values.map(function(item) { item; });
var dupArr = [];
var isDuplicate = valueArr.some(function(item, idx){ 
    if(valueArr.indexOf(item) != idx) dupArr.push(item);
    return valueArr.indexOf(item) != idx ;
});
FUME.print(isDuplicate);
FUME.print(dupArr);


function chkDuplicates(arr,justCheck){
    var len = arr.length, tmp = {}, arrtmp = arr.slice(), dupes = [];
    arrtmp.sort();
    while(len--){
     var val = arrtmp[len];
     if (/nul|nan|infini/i.test(String(val))){
       val = String(val);
      }
      if (tmp[JSON.stringify(val)]){
         if (justCheck) {return true;}
         dupes.push(val);
      }
      tmp[JSON.stringify(val)] = true;
    }
    return justCheck ? false : dupes.length ? dupes : null;
  }

  FUME.print(chkDuplicates(values,true));