export var FN = (function () {
    // STARTFUNCTION getCountOfChar
    /**
   *
   *
   * @param {*} inpStr input string
   * @param {*} findChr character to be checked
   * @summary find the number of occurances of char in the input string
   * @return {number} count of character in input string
   */
    function getCountOfChar(inpStr, findChr) {
        const pattern = new RegExp(`\\${findChr}`, 'g');
        const count = (inpStr.match(pattern) || []).length;
        return count;
    }
    // ENDFUNCTION getCountOfChar

    return {getCountOfChar};
})();

FUME.print(FN.getCountOfChar('1.2.3.4', '.'));
FUME.print(FN.getCountOfChar('1.2.3.4', '_'));
