import {mymodule,print} from "./module.js"

mymodule();
var myvalue = 6;
print("my value is " + myvalue);

for(let key of Object.keys(FUME)){
    //export FUME[key];
    FUME.print("FUME key is "+ FUME[key]);
    FUME.print("key is "+ key);
}

//print("object copied !!!");
function slow(x,y) {
  // there can be a heavy CPU-intensive job here
  FUME.print(`Called with ${x}${y}`);
  return [x,y];
}

function cachingDecorator(func) {
  let cache = new Map();

  return function(...rest) {
    FUME.print("cache size ==> " + cache.size);
    FUME.print("rest is " + rest.join("|"));
    FUME.print("GET is " + cache.keys());
    FUME.print("GET1 is " + cache.get([1,3].toString()));
    if (cache.has(rest.toString())) {    // if there's such key in cache
      FUME.print("cache hit");
      return cache.get(rest.toString()); // read the result from it
    }

    FUME.print("cache miss");
    let result = func(...rest);  // otherwise call func

    FUME.print("cache put" + rest);
    cache.set(rest.toString(), result);  // and cache (remember) the result. Not using ARRAY. because if you store ARRAY, it is a memory which is Stored. when you compare next time, that will be different memory, So comparison will not work. 
    return result;
  };
}

slow = cachingDecorator(slow);

FUME.print( "1st try" + slow(1,3) ); // slow(1) is cached
FUME.print( "Again: " + slow(1,3) ); // the same
FUME.print( "FUME is : " + Object.keys(FUME)); // the sam
FUME.print( "FUME is : " + Object.values(FUME)); // the sam

var dbs = Object.create(FUME);
dbs.print("dfadfwdasd");
FUME.print( "dbs is : " + Object.keys(dbs)); // the sam
FUME.print( "dbs value is : " + Object.values(dbs)); // the sam
