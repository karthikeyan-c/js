export function mymodule(){
	FUME.print("yes inside");
}

export function print(value){
	FUME.print(value);
}

for(let key of Object.keys(FUME)){
    //export FUME[key];
    //let [key] = FUME[key];
    FUME.print("FUME key is "+ FUME[key]);
    FUME.print("key is "+ key);
}
