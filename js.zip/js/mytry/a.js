export var e1 = (function () {
    function d1() {
        return "kk";
    }
})();
