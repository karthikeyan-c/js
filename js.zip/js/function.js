export const function = (function () {
