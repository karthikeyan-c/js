//import { area, circumference } from './circle.mjs';

//const r = 3;

import('./circle.mjs')
  .then((module) => {
	console.log("dynamic loaded");
  });
//console.log(`Circle with radius ${r} has
//  area: ${area(r)};
//  circunference: ${circumference(r)}`);
