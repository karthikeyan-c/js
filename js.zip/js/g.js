async function demo() {
  	console.log('Taking a break...' + new Date());

	let promise = new Promise((resolve, reject) => {
             setTimeout(() => resolve("done!"), 10000)
        }); 

       	let result = promise.then(console.log);
   	console.log('After Promis...' + new Date());
       	return("return from async" + new Date());
}

console.log("before demo" + new Date());
demo().then(console.log);
console.log("after demo" + new Date());
