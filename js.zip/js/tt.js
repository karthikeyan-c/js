import { LibValidateB001 } from 'LibValidateB001.js';


function abcd() {
    LibValidateB001.isValidDateB(fnNameObj);

    
}

var preProcess = function (aa) {
    FUME.print(aa);
    return "bb";
}

var postProcess = function (aa) {
    FUME.print(aa);
    return "cc";
}

var fnNameObj = {
    "preProcessFnName": preProcess,
    "postProcessFnName": postProcess,
}





abcd();

