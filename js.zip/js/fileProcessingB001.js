import { LibCommonB001 } from './LibCommonB001.js';
import { LibCommonB002 } from './LibCommonB002.js';
import { LibDateB001 } from './LibDateB001.js';
import { FUME } from './FUME.js';
FUME.LIBNAME('CUSTOMSO');

export var fileProcessingB001 = (function () {
    var bankId = FUME.getrepValue('BANCS', 'STDIN', 'contextBankId');
    var userId = FUME.getrepValue('BANCS', 'STDIN', 'userId');
    // STARTFUNCTION versionfileProcessingB001
    /**
 *
 *@returns {string} version of the library
 */
    function versionfileProcessingB001() {
        FUME.print('Begin Function versionfileProcessingB001');
        // javascript-obfuscator:disable
        const version = '20200707220902';
        return version;
    }
    // ENDFUNCTION versionfileProcessingB001

    // STARTFUNCTION moveToArchiveB
    /**
 	*
 	*
 	* @param {*} upfileWithPath - file to be moved
 	* @param {*} archPath - path to which file has to be moved
 	* @param {*} processedFileName - file name in the moved path
 	* @returns {boolean} true/false based on command execution
 	*/
    function moveToArchiveB(upfileWithPath, archPath, processedFileName) {
        FUME.print('Begin Function moveToArchiveB');
        const cmd = 'mv ' + upfileWithPath + ' ' + archPath + '/' + processedFileName;
        FUME.print(cmd);
        const sysOp = FUME.system(cmd);
        FUME.print(sysOp);
        FUME.print('End Function moveToArchiveB');
        if (sysOp !== 0)  {
            return false;
        }
        return true;
    }
    // ENDFUNCTION moveToArchiveB
    // STARTFUNCTION copyToArchiveB
    /**
 	*
 	*
 	* @param {*} upfileWithPath - file to be copied
 	* @param {*} archPath - path to which file has to be copied
 	* @param {*} processedFileName - file name in the copied path
 	* @returns {boolean} true/false based on command execution
 	*/
    function copyToArchiveB(upfileWithPath, archPath, processedFileName) {
        FUME.print('Begin Function copyToArchiveB');
        const cmd = 'cp ' + upfileWithPath + ' ' + archPath + '/' + processedFileName;
        FUME.print(cmd);
        const sysOp = FUME.system(cmd);
        FUME.print(sysOp);
        FUME.print('End Function copyToArchiveB');
        if (sysOp !== 0)  {
            return false;
        }
        return true;
    }
    // ENDFUNCTION copyToArchiveB

    // STARTFUNCTION readDataFromFileWithOneRecB
    function readDataFromFileWithOneRecB(inpFile) {
        FUME.print('Begin Function readDataFromFileWithOneRecB');
        FUME.print('inpFile:' + inpFile);
        let fileIndex;
        let output = '';
        let urtnOp;
        urtnOp = FUME.URTN('fileOpen', inpFile + '|r');
        if (urtnOp === 0) {
            fileIndex = urtnOp;
            fileIndex = FUME.URTN('fileRead', fileIndex + '|output');
        }
        urtnOp = FUME.URTN('fileClose', fileIndex);
        FUME.print('output:' + output);
        FUME.print('End Function readDataFromFileWithOneRecB');
        return output;
    }
    // ENDFUNCTION readDataFromFileWithOneRecB

    // STARTFUNCTION getFileCountInFolderB
    /**
 *
 *
 * @param {*} upldPath upload path where file count has to be checked
 * @param {*} fileExtn file extension to be checked
 * @param {string} [fileName=''] file name pattern to be checked
 * @returns {string} number of files present in the path
 */
    function getFileCountInFolderB(upldPath, fileExtn, fileName = '') {
        FUME.print('Begin Function getFileCountInFolderB');
        let fileCount = '0';
        const countIntoFile = LibCommonB001.getUniqueFileNameB('TEMP_COUNT', 'LST');
        FUME.print(countIntoFile);
        let cmd  = `ls ${upldPath}/*${fileName}*.${fileExtn} 2>/dev/null|wc -l >> ${countIntoFile}`;
        FUME.print(cmd);
        let sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            return fileCount;
        }
        cmd = 'chmod 755 ' + countIntoFile;
        FUME.print(cmd);
        sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            return fileCount;
        }

        fileCount = readDataFromFileWithOneRecB(countIntoFile);
        FUME.print('fileCount:' + fileCount);
        FUME.print('End Function getFileCountInFolderB');
        return fileCount;
    }
    // ENDFUNCTION getFileCountInFolderB

    // STARTFUNCTION validateAlreadyProcessedFileB
    /**
     *
     *
     * @param {*} dataObj input obj
     * @returns {boolean} true/false
     */
    function validateAlreadyProcessedFileB(dataObj) {
        FUME.print('Begin Function validateAlreadyProcessedFileB');
        LibCommonB001.setErrorFieldsB(dataObj);
        let retVal = false;
        let urtnOp;
        let fileNames = [];
        let tableNames = [];
        let fileIndex;
        let index;
        let fName;

        let mandFlds = ['uploadPath', 'fileNames', 'tableNames'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dataObj, mandFlds)) {
            return retVal;
        }

        if (typeof (dataObj.fileNames) === 'string') {
            fileNames = dataObj.fileNames.split('|');
        }

        if (typeof (dataObj.tableNames) === 'string') {
            tableNames = dataObj.tableNames.split('|');
        }
        if (fileNames.length !== tableNames.length) {
            LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', 'Mismatch in number of fileNames and tableNames', '');
            return retVal;
        }
        const listFileIntoLst = LibCommonB001.getUniqueFileNameB('TEMP_LIST_FILE', 'LST');
        FUME.print(listFileIntoLst);
        let cmd  = `ls -1 ${dataObj.uploadPath}/ 2>/dev/null >> ${listFileIntoLst}`;
        FUME.print(cmd);
        let sysOp = FUME.system(cmd);
        cmd = 'chmod 755 ' + listFileIntoLst;
        FUME.print(cmd);
        sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            return retVal;
        }
        urtnOp = FUME.URTN('fileOpen', listFileIntoLst + '|r');
        if (urtnOp !== 0) {
            return retVal;
        }
        fileIndex = urtnOp;
        fileIndex = FUME.URTN('fileRead', fileIndex + '|fName');
        while (fileIndex > 0) {
            index = fileNames.indexOf(fName);
            if (index >= 0) {
                // get the corresponding table name from tableNames array
                let cntObj = {};
                cntObj.whereFields = ['UPLOAD_FILE_NAME', 'BANK_ID'];
                cntObj.whereValues = [fName, bankId];
                cntObj.tableName = tableNames[index];
                retVal = LibCommonB001.checkRecordCntB(cntObj);
                if (parseInt(cntObj.count) > 0) {
                    LibCommonB001.setErrorFieldsB(dataObj, true, '1', 'MSG', `File ${fName} already Processed`, '');
                }
            }
        }
        urtnOp = FUME.URTN('fileClose', fileIndex);
        FUME.print('End Function validateAlreadyProcessedFileB');
        return retVal;
    }
    // ENDFUNCTION validateAlreadyProcessedFileB
    // STARTFUNCTION convFixLengthFileToDelimitedB
    /**
     *
     *
     * @param {*} fileObj input object
     * @returns {boolean} true/false based on errors
    */
    function convFixLengthFileToDelimitedB(fileObj) {
        FUME.print('Begin Function convFixLengthFileToDelimitedB');
        let retVal = false;
        LibCommonB001.setErrorFieldsB(fileObj);
        let mandFlds = ['inpFileNameWithPath', 'delimiterPosition', 'outputFileDelimiter', 'outputFileName'];
        if (!LibCommonB002.chkMandatorySRVInputsB(fileObj, mandFlds)) {
            return retVal;
        }
        let trimSpaceFlg = fileObj.trimSpaceFlg || 'N';

        let tmpComFileName = LibCommonB001.getUniqueFileNameB('fileProcessTmp', 'com');
        let tmpOutFileName = LibCommonB001.getUniqueFileNameB('fileProcessTmpOut', 'txt');

        if (fileObj.delimiterPosition.indexOf(',') <= 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'delimiterPosition should be , separated', '');
            return retVal;
        }

        let sysOp = FUME.system('>' + tmpComFileName);
        if (sysOp !== 0) return retVal;

        let cmd = `awk {OFS="${fileObj.outputFileDelimiter}"};{print `;
        let delimiterPositions = [];
        if (typeof (fileObj.delimiterPosition) === 'string') {
            delimiterPositions = fileObj.delimiterPosition.split(',');
        }
        if (Array.isArray(fileObj.delimiterPosition)) {
            delimiterPositions = fileObj.delimiterPosition;
        }
        let configCounter = 1;
        let subStrList = [];
        for (let i = 0; i < delimiterPositions.length; i += 1) {
            subStrList.push(`substr($0,"${configCounter}","${delimiterPositions[i]}")`);
            configCounter += parseInt(delimiterPositions[i]);
        }
        cmd += subStrList.join(',');
        cmd += `} ${fileObj.inpFileNameWithPath}`;


        if (trimSpaceFlg === 'N') {
            cmd += ` > ${fileObj.outputFileName}`;
        } else {
            cmd += ` > ${tmpOutFileName}`;
        }

        retVal = LibCommonB001.addDataToFileB(tmpComFileName, cmd);
        if (!retVal) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'addDataToFileB failed for converion into delimited file', '');
            return false;
        }

        let urhkOp = FUME.USRHK('getFileLocation', 'COM|replaceInFile.com');
        if (urhkOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'replaceInFile.com not found', '');
            return false;
        }

        let comFileLocation = FUME.getrepValue('BANCS', 'OUTPARAM', 'fileLocation');
        cmd = comFileLocation + 'replaceInFile.com ' + ' CURRENT_PATH " ' + tmpComFileName + ' ' + tmpComFileName + '_TMP';
        sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'replaceInFile.com failed', '');
            return false;
        }
        cmd = 'mv ' + tmpComFileName + '_TMP ' + tmpComFileName;
        sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'moving TMP file failed', '');
            return false;
        }

        if (trimSpaceFlg !== 'N') {
            cmd = "sed -e 's/[[:space:]]*" + fileObj.outputFileDelimiter + '[[:space:]]*/' + fileObj.outputFileDelimiter + "/g' " + tmpOutFileName + '>' + fileObj.outputFileName;
            urhkOp = LibCommonB001.addDataToFileB(tmpComFileName, cmd);
            if (urhkOp !== 0) {
                LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'addDataToFileB failed for trim', '');
                return false;
            }
        }
        sysOp = FUME.system('chmod 755 ' + tmpComFileName);
        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'chmod command failed', '');
            return false;
        }

        cmd = tmpComFileName;
        sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'TRIM failed on output file', '');
            return false;
        }

        cmd = 'rm -f ' + tmpComFileName + ' ' + tmpOutFileName;
        sysOp = FUME.system(cmd);
        FUME.print('End Function convFixLengthFileToDelimitedB');
        return retVal;
    }
    // ENDFUNCTION convFixLengthFileToDelimitedB
    // STARTFUNCTION getFileCountAndFileListB
    /**
     *
     *
     * @param {*} fileObj input object
     * @returns {boolean} true/false based on errors
     */
    function getFileCountAndFileListB(fileObj) {
        FUME.print('Begin Function getFileCountAndFileListB');
        let retVal = false;
        LibCommonB001.setErrorFieldsB(fileObj);
        let fileNameArr = [];
        let inpFilePatternArr = [];

        let mandFlds = ['inpFilePattern'];
        if (!LibCommonB002.chkMandatorySRVInputsB(fileObj, mandFlds)) {
            return retVal;
        }
        let optFlds = ['inpFilePath', 'fileNamesListWithPath', 'fileNamesListWithoutPath', 'consDataFileName'];
        LibCommonB002.chkNonMandatorySRVInputsB(fileObj, optFlds);

        let inpFilePath = fileObj.inpFilePath || '';
        if (inpFilePath === '') {
            inpFilePath = FUME.getEnv('INPUT_PATH');
        }

        if (typeof (fileObj.inpFilePattern) === 'string') {
            inpFilePatternArr = fileObj.inpFilePattern.split(',');
        }
        if (Array.isArray(fileObj.inpFilePattern)) {
            inpFilePatternArr = fileObj.inpFilePattern;
        }
        for (let i = 0; i <= inpFilePatternArr.length; i += 1) {
            fileNameArr.push(inpFilePath + inpFilePatternArr[i]);
        }
        let tmpFileName = LibCommonB001.getUniqueFileNameB('TEMP_COUNT_FILES', 'LST');
        let cmd = `ls ${fileNameArr.join(' ')} 2>/dev/null|wc -l > ${tmpFileName}`;
        let sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'listing of inpFilePattern files failed', '');
            return retVal;
        }
        cmd = `chmod 755 ${tmpFileName}`;
        sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'chmod failed', '');
            return retVal;
        }

        let fileCount = readDataFromFileWithOneRecB(tmpFileName);
        if (!fileCount || fileCount === '') {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'Unable to fetch listing of inpFilePattern files', '');
            return retVal;
        }
        cmd = `rm -f ${tmpFileName}`;
        sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', `removal of ${tmpFileName} failed`, '');
            return retVal;
        }
        if (fileObj.fileNamesListWithPath !== '') {
            cmd = `ls ${fileNameArr.join(' ')} 2>/dev/null > ${fileObj.fileNamesListWithPath} `;
            sysOp = FUME.system(cmd);
            if (sysOp !== 0) {
                LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', `writing to ${fileObj.fileNamesListWithPath} failed`, '');
                return retVal;
            }
        }
        if (fileObj.fileNamesListWithoutPath !== '') {
            // eslint-disable-next-line no-useless-escape
            cmd = `ls ${fileNameArr.join(' ')} 2>dev/null | |sed 's/.*\///' > ${fileObj.fileNamesListWithoutPath}`;
            sysOp = FUME.system(cmd);
            if (sysOp !== 0) {
                LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', `writing to ${fileObj.fileNamesListWithoutPath} failed`, '');
                return retVal;
            }
        }
        if (fileObj.consDataFileName !== '') {
            cmd = `cat ${fileNameArr.join(' ')} 2>/dev/null > ${fileObj.consDataFileName} `;
            sysOp = FUME.system(cmd);
            if (sysOp !== 0) {
                LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', `writing to ${fileObj.consDataFileName} failed`, '');
                return retVal;
            }
        }

        FUME.print('End Function getFileCountAndFileListB');
        return retVal;
    }
    // ENDFUNCTION getFileCountAndFileListB
    // STARTFUNCTION getFilePropertiesB
    /**
     *
     *
     * @param {*} fileObj input object
     * @returns {boolean} true/false based on errors
     */
    function getFilePropertiesB(fileObj) {
        FUME.print('Begin Function getFilePropertiesB');
        let retVal = false;
        LibCommonB001.setErrorFieldsB(fileObj);

        let mandFlds = ['inpFileNameWithPath'];
        if (!LibCommonB002.chkMandatorySRVInputsB(fileObj, mandFlds)) {
            return retVal;
        }

        let fileName = fileObj.inpFileNameWithPath;

        let cmd  = 'test -f ' + fileName;
        let sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            fileObj.fileExists = false;
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', `File ${fileObj.inpFileNameWithPath} does not exist`, '');
            return retVal;
        }

        let tmpFileName1 = LibCommonB001.getUniqueFileNameB('FILE_PROPS', 'LST');
        let tmpFileName2 = LibCommonB001.getUniqueFileNameB('FILE_PROPS_DELIM', 'LST');

        cmd = 'cksum ' + fileName + "| cut -d ' ' -f1,2 | tr ' ' ',' > " + tmpFileName1;
        sysOp = FUME.system(cmd);
        cmd = 'wc -l ' + fileName + "| cut -d ' ' -f1 >> " + tmpFileName1;
        sysOp = FUME.system(cmd);
        cmd = 'find ' + fileName + " -printf '%Td-%Tm-%TY %TH:%TM\n' >>" + tmpFileName1;
        sysOp = FUME.system(cmd);
        cmd = "tr '\n' ',' < " + tmpFileName1 + ' > ' + tmpFileName2;
        sysOp = FUME.system(cmd);

        let fileRecord = readDataFromFileWithOneRecB(tmpFileName2);
        [fileObj.checkSum, fileObj.size, fileObj.lineCount, fileObj.lastModDateTime] = fileRecord.split(',');
        sysOp = FUME.system('rm -f ' + tmpFileName1 + ' ' + tmpFileName2);
        FUME.print('End Function getFilePropertiesB');
        return true;
    }
    // ENDFUNCTION getFilePropertiesB

    // STARTFUNCTION executeSqlFileB
    /**
     *
     *
     * @param {*} fileNameWithArgs file name to be executed
     * @returns {boolean} true if command execution is success
     */
    function executeSqlFileB(fileNameWithArgs) {
        FUME.print('Begin Function executeSqlFileB');
        let sysOp;

        sysOp = FUME.system('chmod 755 ' + fileNameWithArgs);
        sysOp = FUME.system('exebatch bauu9151 ' + fileNameWithArgs);
        return (sysOp === 0);
    }
    // ENDFUNCTION executeSqlFileB
    // STARTFUNCTION createInsertSqlB
    /**
     *
     *
     * @param {*} fileObj input object
     * @returns {boolean} true/false
     */
    function createInsertSqlB(fileObj) {
        FUME.print('Begin Function createInsertSqlB');
        let retVal = false;
        LibCommonB001.setErrorFieldsB(fileObj);

        let mandFlds = ['inpFileNameWithPath', 'inpFileDelimiter', 'tableName', 'columnNames'];
        if (!LibCommonB002.chkMandatorySRVInputsB(fileObj, mandFlds)) {
            return retVal;
        }

        let optFlds = ['primaryKeyCol', 'numberColumns', 'dateColWithFormat', 'fileColSize', 'sqlFileName'];
        LibCommonB002.chkNonMandatorySRVInputsB(fileObj, optFlds);

        let sqlFileNameWithPath = LibCommonB001.getUniqueFileNameB('TableInsert', 'sql');
        if (fileObj.sqlFileName.trim() !== '') {
            if (fileObj.sqlFileName.trim().slice(-3).toUpperCase() === 'SQL') {
                sqlFileNameWithPath = fileObj.sqlFileName.trim();
            }
        }

        let tmpComFileName = LibCommonB001.getUniqueFileNameB('fileProcessTmp', 'com');
        let sysOp = FUME.system('>' + tmpComFileName);

        let comFileData = `cat ${fileObj.inpFileNameWithPath} | `;
        comFileData += '\n' + 'sed "s/\'/\'\'/g" | ';
        comFileData += '\n' + 'sed "s/^/\'/g" | ';
        comFileData += '\n' + 'sed "s/$/\'/g" | ';
        comFileData += '\n' + `sed "s/${fileObj.inpFileDelimiter}/'${fileObj.inpFileDelimiter}'/g" | `;
        comFileData += '\n' + `awk 'BEGIN {FS="${fileObj.inpFileDelimiter}";OFS="${fileObj.inpFileDelimiter}";}`;

        let dateColWithFormat = [];
        if (typeof (fileObj.dateColWithFormat) === 'string') {
            dateColWithFormat = fileObj.dateColWithFormat.split(',');
        }
        if (Array.isArray(fileObj.dateColWithFormat)) {
            dateColWithFormat = fileObj.dateColWithFormat;
        }
        if (dateColWithFormat.length) {
            for (let i = 0; i < dateColWithFormat.length; i += 1) {
                let [fieldNo, dateFormat] = dateColWithFormat[i].split('|');
                comFileData += '\n' + `{$${fieldNo}="TO_DATE("$${fieldNo}",'${dateFormat}')";}`;
            }
        }

        let numberColumns = [];
        if (typeof (fileObj.numberColumns) === 'string') {
            numberColumns = fileObj.numberColumns.split(',');
        }
        if (Array.isArray(fileObj.numberColumns)) {
            numberColumns = fileObj.numberColumns;
        }
        if (numberColumns.length) {
            for (let i = 0; i < numberColumns.length; i += 1) {
                let fieldNo = numberColumns[i];
                comFileData += '\n' + `{$${fieldNo}="TO_NUMBER("$${fieldNo}")";}`;
            }
        }

        comFileData += '\n' + `INSERT INTO ${fileObj.tableName} INSERTNEWLINE (`;

        let columnNames = [];
        if (typeof (fileObj.columnNames) === 'string') {
            columnNames = fileObj.columnNames.split(',');
        }
        if (Array.isArray(fileObj.columnNames)) {
            columnNames = fileObj.columnNames;
        }

        let colNameList = [];
        for (let i = 0; i < columnNames.length; i += 1) {
            let fieldName = columnNames[i].split('|')[1];
            colNameList.push(fieldName);
        }
        comFileData += '\n' + `${colNameList.join(',')}`;
        comFileData += '\n' + ') INSERTNEWLINE VALUES INSERTNEWLINE (';
        comFileData += '\n' + '{$1="' + comFileData + '"$1;}';

        comFileData += '\n' + '{ print; }';
        comFileData += '\n' + 'END{}\'|';
        comFileData += '\n' + `sed "s/${fileObj.inpFileDelimiter}/,/g" | `;
        comFileData += '\n' + 'sed "s/$/);/g" | ';
        comFileData += '\n' + 'awk -F\'INSERTNEWLINE\' \'{for(i=1;i<=NF;i++) printf "%s\n", $i}\' > ' + sqlFileNameWithPath;

        let comFileDataArr = comFileData.split('\n');
        retVal = LibCommonB001.addDataToFileB(sqlFileNameWithPath, comFileDataArr);

        sysOp = FUME.system('chmod 755 ' + sqlFileNameWithPath);
        sysOp =  FUME.system(sqlFileNameWithPath);

        sysOp = FUME.system('rm -f ' + sqlFileNameWithPath);
        sysOp = FUME.system("sed -i '1s/^/SET DEFINE OFF;\n/'" + sqlFileNameWithPath);

        retVal = (sysOp === 0);
        FUME.print('End Function createInsertSqlB');
        return retVal;
    }
    // ENDFUNCTION createInsertSqlB
    // STARTFUNCTION insertIntoTableFromFileB
    /**
     *
     *
     * @param {*} fileObj input object
     * @returns {boolean} true/false
     */
    function insertIntoTableFromFileB(fileObj) {
        FUME.print('Begin Function insertIntoTableFromFileB');
        let retVal = false;
        retVal = createInsertSqlB(fileObj);
        if (retVal) {
            retVal = executeSqlFileB(fileObj.sqlFileNameWithPath);
        }
        FUME.print('End Function insertIntoTableFromFileB');
        return retVal;
    }
    // ENDFUNCTION insertIntoTableFromFileB
    // STARTFUNCTION modifyInpFileForStdUploadB
    /**
     *
     *
     * @param {*} fileObj input object
     * @returns {boolean} true/false
     */
    function modifyInpFileForStdUploadB(fileObj) {
        FUME.print('Begin Function modifyInpFileForStdUploadB');
        let retVal = false;
        let locDelimiter = '~~';
        LibCommonB001.setErrorFieldsB(fileObj);

        let mandFlds = ['inpFileNameWithPath', 'inpFileDelimiter', 'tableName', 'uploadBatchId'];
        if (!LibCommonB002.chkMandatorySRVInputsB(fileObj, mandFlds)) {
            return retVal;
        }

        fileObj.columnNames = ['1|UPLOAD_REC_SRL_NUM', '2|UPLOAD_STRING', '3|UPLOAD_FILE_NAME', '4|UPLOAD_BATCH_ID', '5|UPLOAD_STATUS', '6|ENTITY_CRE_FLG', '7|DEL_FLG', '8|LCHG_USER_ID', '9|LCHG_TIME', '10|RCRE_USER_ID', '11|RCRE_TIME', '12|BANK_ID'];
        let tmpComFileName = LibCommonB001.getUniqueFileNameB('fileProcessTmp', 'com');
        let sysOp = FUME.system('>' + tmpComFileName);

        // get fileName from full path
        let tmpString = fileObj.inpFileNameWithPath.split('/').pop();

        let cmd = `cat -n ${fileObj.inpFileNameWithPath} |`;
        cmd += '\n' + `sed "s/	/${locDelimiter}/" |`;
        cmd += '\n' + `sed "s/$/${locDelimiter}${tmpString}/g" |`;
        cmd += '\n' + `sed "s/$/${locDelimiter}${fileObj.uploadBatchId}/g" |`;

        tmpString = LibDateB001.getSysDateTimeWithFormatB('YYYYMMDDHH24MISS');

        cmd += '\n' +  `sed "s/$/${locDelimiter}S${locDelimiter}Y${locDelimiter}N${locDelimiter}${userId}${locDelimiter}`;
        cmd += `${tmpString}${locDelimiter}${userId}${locDelimiter}${tmpString}${locDelimiter}${bankId}/g" > ${tmpComFileName}`;


        let cmdArr = cmd.split('\n');

        retVal = LibCommonB001.addDataToFileB(tmpComFileName, cmdArr);
        if (!retVal) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'Writing to file failed', '');
        }
        sysOp = FUME.system('chmod 755 ' + tmpComFileName);
        sysOp =  FUME.system(tmpComFileName);

        sysOp = FUME.system('rm -f ' + tmpComFileName);

        fileObj.inpFileDelimiter = locDelimiter;
        fileObj.dateColWithFormat = ['9|YYYYMMDDHH24MISS', '11|YYYYMMDDHH24MISS'];
        fileObj.primaryKeyCol = '';
        fileObj.numberColumns = '';
        fileObj.fileColSize = '';
        fileObj.sqlFileName = '';

        FUME.print('End Function modifyInpFileForStdUploadB');
        return retVal;
    }
    // ENDFUNCTION modifyInpFileForStdUploadB

    // STARTFUNCTION modifyInpFileForDirectUploadB
    /**
     *
     *
     * @param {*} fileObj input object
     * @returns {boolean} true/false
     */
    function modifyInpFileForDirectUploadB(fileObj) {
        FUME.print('Begin Function modifyInpFileForDirectUploadB');
        let retVal = false;
        LibCommonB001.setErrorFieldsB(fileObj);

        let mandFlds = ['inpFileNameWithPath', 'inpFileDelimiter', 'tableName', 'uploadBatchId', 'columnNames'];
        if (!LibCommonB002.chkMandatorySRVInputsB(fileObj, mandFlds)) {
            return retVal;
        }

        let optFlds = ['primaryKeyCol', 'numberColumns', 'dateColWithFormat', 'fileColSize', 'sqlFileName', 'modifiedFileName'];
        LibCommonB002.chkNonMandatorySRVInputsB(fileObj, optFlds);

        let modifiedFileName = fileObj.modifiedFileName || LibCommonB001.getUniqueFileNameB('ModifiedInputFile', 'txt');

        let tmpComFileName = LibCommonB001.getUniqueFileNameB('fileProcessTmp', 'com');
        FUME.system('>' + tmpComFileName);
        let tmpTxtFileName = LibCommonB001.getUniqueFileNameB('TmpTxtFile1', 'com');
        FUME.system('>' + tmpTxtFileName);

        let cmd = `awk 'BEGIN {FS="${fileObj.inpFileDelimiter}";OFS=",";}`;
        cmd += '\n' + '';

        FUME.print('End Function modifyInpFileForDirectUploadB');
        return retVal;
    }
    // ENDFUNCTION modifyInpFileForDirectUploadB


    // STARTFUNCTION genListFilesB
    /**
     *
     *
     * @param {*} fileObj input object
     * @returns {boolean} true/false
     */
    function genListFilesB(fileObj) {
        FUME.print('Begin Function genListFilesB');
        let retVal = false;
        LibCommonB001.setErrorFieldsB(fileObj);

        let mandFlds = ['tableName', 'selColName', 'fileName', 'batchId', 'outputlst', 'status'];
        if (!LibCommonB002.chkMandatorySRVInputsB(fileObj, mandFlds)) {
            return retVal;
        }

        let sqlFileName = LibCommonB001.getUniqueFileNameB('GenList_' + fileObj.status, 'sql');
        FUME.print('sqlFileName:' + sqlFileName);

        let outTmpFile = LibCommonB001.getUniqueFileNameB('TMP_' + fileObj.status, 'lst');
        FUME.print('outTmpFile:' + outTmpFile);

        let spoolData = 'SET FEEDBACK OFF';
        spoolData += '\n' + 'SET PAGES 0';
        spoolData += '\n' + 'SET ECHO OFF';
        spoolData += '\n' + 'SET COLSEP \'|\'';
        spoolData += '\n' + 'SET LINESIZE 10000';
        spoolData += '\n' + 'SET TRIM ON';

        let selColNames = [];
        if (typeof (fileObj.selColName) === 'string') {
            selColNames = fileObj.selColName.split(',');
        }
        if (Array.isArray(fileObj.selColName)) {
            selColNames = fileObj.selColName;
        }

        spoolData += '\n' + '   SELECT ' + selColNames.join(',') + ' FROM ' + fileObj.tableName;
        spoolData += '\n' + '   WHERE UPLOAD_STATUS = \'' + fileObj.status + '\'';
        spoolData += '\n' + '   AND BANK_ID = \'' + bankId + '\'';
        spoolData += '\n' + '   AND UPLOAD_FILE_NAME = \'' + fileObj.fileName + '\'';
        spoolData += '\n' + '   AND UPLOAD_BATCH_ID = \'' + fileObj.batchId + '\'';
        spoolData += '\n' + '   ;';

        spoolData += '\n' + 'SPOOL OFF';
        spoolData += '\n' + 'EXIT';

        let spoolDataArr = spoolData.split('\n');
        retVal = LibCommonB001.addDataToFileB(sqlFileName, spoolDataArr);

        if (!retVal) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'Writing to file failed', '');
            return false;
        }

        let cmd = 'exebatch bauu9151 ' + sqlFileName;
        let sysOp = FUME.system(cmd);

        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'bauu9151 failed', '');
            return false;
        }

        cmd = `cat ${outTmpFile} >> ${fileObj.outputlst}`;
        sysOp = FUME.system(cmd);

        cmd = `sed 's/ //g' ${fileObj.outputlst} >> ${outTmpFile}`;
        sysOp = FUME.system(cmd);

        cmd = `cp  ${outTmpFile} ${fileObj.outputlst}`;
        sysOp = FUME.system(cmd);

        cmd = `rm -f ${sqlFileName} ${outTmpFile}`;
        sysOp = FUME.system(cmd);

        FUME.print('End Function genListFilesB');
        return true;
    }
    // ENDFUNCTION genListFilesB
    // STARTFUNCTION insertUsingSqlLdrB
    /**
     *
     *
     * @param {*} fileObj input object
     * @returns {boolean} true/false
     */
    function insertUsingSqlLdrB(fileObj) {
        FUME.print('Begin Function insertUsingSqlLdrB');
        let retVal = false;
        let ctlFileName = fileObj.ctlFileName || 'fileUplTmpl.ctl';
        LibCommonB001.setErrorFieldsB(fileObj);

        let mandFlds = ['sqlLoaderUploadType', 'inpFileNameWithPath', 'tableName', 'uploadBatchId'];
        if (!LibCommonB002.chkMandatorySRVInputsB(fileObj, mandFlds)) {
            return retVal;
        }

        let optFlds = ['ctlFilePath'];
        LibCommonB002.chkNonMandatorySRVInputsB(fileObj, optFlds);

        let ctlPath = FUME.getEnv('CUSTOM_CTL_PATH');
        if (ctlPath === '') {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'CUSTOM_CTL_PATH not set', '');
            return retVal;
        }

        if (ctlFileName === '') {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'ctlFileName is blank', '');
            return retVal;
        }

        let cmd = 'cp ' + ctlPath + '/' + ctlFileName + ' .';
        let sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'copying ctl file failed', '');
            return retVal;
        }

        retVal = FUME.USRHK('getFileLocation', 'COM|replaceInfileUplTmpl.com');
        retVal = (retVal === 0);
        if (!retVal) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'replaceInfileUplTmpl.com not found', '');
            return retVal;
        }

        let comFileLocation = FUME.getrepValue('BANCS', 'OUTPARAM', 'fileLocation');
        let tableName = fileObj.tableName.split('.').pop();

        //----------------------------------------------------------------------------
        // Inputs are
        // 1. UPLTBLNAME_VALUE - Table name when data has to be uploaded
        // 2. UPLFILENAME_VALUE - Data Filename which needs to be uploaded
        // 3. UPLBATCHID_VALUE - Unqiue Batch Id value
        // 4. UPLUSERID_VALUE - User Id invoking the upload
        // 5. UPLBANKID_VALUE - Bank Id
        // 6. CTLFILE_NAME - Control File Name
        // ----------------------------------------------------------------------------
        cmd = `${comFileLocation}/replaceInfileUplTmpl.com ${tableName} '${fileObj.inpFileNameWithPath}' ${fileObj.uploadBatchId} ${userId} ${bankId} ${ctlFileName}`;
        sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'replaceInfileUplTmpl.com failed', '');
            return retVal;
        }

        cmd = `finSQLLDR ${tableName}.ctl '${fileObj.inpFileNameWithPath}'`;
        sysOp = FUME.system(cmd);
        if (sysOp !== 0) {
            LibCommonB001.setErrorFieldsB(fileObj, true, '1', 'MSG', 'finSQLLDR execution failed', '');
            return retVal;
        }

        cmd = `rm -f ${tableName}.ctl ${ctlFileName}`;
        sysOp = FUME.system(cmd);
        FUME.print('End Function insertUsingSqlLdrB');
        return retVal;
    }
    // ENDFUNCTION insertUsingSqlLdrB
    // STARTFUNCTION insertUsingSqlLdrB
    /**
     *
     *
     * @param {*} fileObj input object
     * @returns {boolean} true/false
     */
    function insertFromFileToUpldTblB(fileObj) {
        FUME.print('Begin Function insertFromFileToUpldTblB');
        let retVal = false;

        retVal = modifyInpFileForDirectUploadB(fileObj);
        if (!retVal) {
            return retVal;
        }
        fileObj.inpFileNameWithPath = fileObj.modifiedFileName;
        retVal = insertIntoTableFromFileB(fileObj);
        FUME.print('End Function insertFromFileToUpldTblB');
        return retVal;
    }
    // ENDFUNCTION insertFromFileToUpldTblB
    // START FUNCTIONLIST
    return {
        versionfileProcessingB001,
        moveToArchiveB,
        readDataFromFileWithOneRecB,
        getFileCountInFolderB,
        validateAlreadyProcessedFileB,
        convFixLengthFileToDelimitedB,
        getFileCountAndFileListB,
        getFilePropertiesB,
        modifyInpFileForStdUploadB,
        createInsertSqlB,
        executeSqlFileB,
        insertIntoTableFromFileB,
        modifyInpFileForDirectUploadB,
        insertFromFileToUpldTblB,
        // //validateRecordDataB,
        readAndinsertFileDataB,
        genListFilesB,
        copyToArchiveB,
        massageFileB,
        insertUsingSqlLdrB
    };
    // END FUNCTIONLIST
})();
