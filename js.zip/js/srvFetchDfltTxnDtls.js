
export var FN = (function () {

    // STARTFUNCTION srvFetchDfltTxnDtls
    /**
   *
   *
   * @param {*}
   * @summary
   * @example
   * @returns {string}
   */

    function srvFetchDfltTxnDtls(functionInputs) {
	
		/*
		*--------------------------------------------------------------------------------------------------------------------------
		*       MANDATORY FIELDS
		*--------------------------------------------------------------------------------------------------------------------------
		*/
		
		let mandFlds;
		mandFlds = ['tranDate','tranType','tranSubType','initSolId','ignoreXcpnFlg','postFlg'];
		
		functionInputs.errorMsgs = ' ';
		functionInputs.errorFlg = 'N';
		functionInputs.errorCode = '';
		let errorMsg;
		let error;



		if (!LibCommonB002.chkMandatorySRVInputsB(functionInputs, mandFlds)) {
			// LibCommonB002.setErrorFieldsB(functionInputs, true, functionInputs.errorDetails[0].errorCode, 'MSG', functionInputs.errorDetails[0].errorMsg, '');
			return false;
		}
		
		FUME.print('tranDate :- ',functionInputs.tranDate);
        FUME.print('tranType :- ',functionInputs.tranType);
		FUME.print('tranSubType :- ',functionInputs.tranSubType);
        FUME.print('initSolId :- ',functionInputs.initSolId);
		FUME.print('ignoreXcpnFlg :- ',functionInputs.ignoreXcpnFlg);
        FUME.print('postFlg :- ',functionInputs.postFlg);
		
		/*
		*--------------------------------------------------------------------------------------------------------------------------
		*       NON-MANDATORY FIELDS CHECK
		*--------------------------------------------------------------------------------------------------------------------------
		*/
		mandFlds = ['tranHdrRmks','userTranCode','deliveryChannelId'];
		
		let chkNonMand;
		
		chkNonMand = LibCommonB002.chkNonMandatorySRVInputsB(functionInputs, mandFlds);
		
		FUME.print('chkNonMand :- ',chkNonMand);
		
		FUME.print('tranHdrRmks :- ',functionInputs.tranHdrRmks);
        FUME.print('userTranCode :- ',functionInputs.userTranCode);
		FUME.print('deliveryChannelId :- ',functionInputs.deliveryChannelId);
		
		
		FUME.USRHK("setUrhkInp","tranHdr.tranIdentifier.tranDate|"+functionInputs.tranDate.substring(0, 10) + " 00:00:00");
		FUME.USRHK("setUrhkInp","tranHdr.tranTypeSubType.tranType|"+functionInputs.tranType);
		FUME.USRHK("setUrhkInp","tranHdr.tranTypeSubType.tranSubType|"+functionInputs.tranSubType);
		FUME.USRHK("setUrhkInp","tranHdr.initSol.solId|"+functionInputs.initSolId);
		FUME.USRHK("setUrhkInp","tranDtl.ignoreXcpnFlg|"+functionInputs.ignoreXcpnFlg);
		FUME.USRHK("setUrhkInp","tranDtl.pstFlg|"+functionInputs.postFlg);
		FUME.USRHK("setUrhkInp","tranHdr.tranRmks|"+functionInputs.tranHdrRmks);
		FUME.USRHK("setUrhkInp","tranHdr.userTranCode.code|"+functionInputs.userTranCode);
		
		if(functionInputs.deliveryChannelId != ''){
			
			FUME.USRHK("setUrhkInp","tranDtl.deliveryChannelId|"+functionInputs.deliveryChannelId);
		}
		
		let exeSrv = "SRV_FetchDfltTranDtls|retain_all_output = Y" ;
		
		let srvOut;
		srvOut = FUME.USRHK('ExecSrvNoCommit', exeSrv);
		
		FUME.print('srvOut :- ',srvOut);
		
		if(srvOut !== 0){

			functionInputs.errorFlg = 'Y';
			errorMsg = LibCommonB001.handleSrvErrorB('Y', 'Y', 'Y', 'Y');
			FUME.print(errorMsg);
			error = LibCommonB001.replaceCharB(errorMsg,"|","");
			functionInputs.errorMsgs = error;
			return false;
		}
		
		let srvCpy;
		
		srvCpy = FUME.USRHK('CopyOutToIn', '');
        FUME.print(srvCpy);
		
		return true;
		
	}
    // ENDFUNCTION srvFetchDfltTxnDtls
	
    return {srvFetchDfltTxnDtls};
})();	
