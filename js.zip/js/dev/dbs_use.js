import dbs from "./dbs.js"

dbs.print("Inside dbs use");
