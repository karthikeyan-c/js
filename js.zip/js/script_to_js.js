const fs = require('fs');
const readline = require('readline');

const functionsInLib = [];
let libName = '';
let jsFileName = '';
const listOfVariables = new Set();
const funsList = [];
const nonfunList = [];
let tempstr = '';
let isExistfun = true;

function writeFile(fileName, dataToWrite) {
  fs.appendFile(fileName, dataToWrite, err => {
    if (err) throw err;
  });
}

// // we are checking is it start of function/Sub or not
function isStartofFunLine(currentLine) {
  const line = currentLine.trim();
  if (
    (line.startsWith('FUNCTION') || line.startsWith('SUB')) &&
    line.endsWith(')')
  ) {
    return true;
  }
  return false;
}

// we are checking is it end of function/Sub or not
function isEndofFunLine(currentLine) {
  const line = currentLine.trim();
  if (line.startsWith('ENDFUNCTION') || line.startsWith('ENDSUB')) {
    return true;
  }
  return false;
}

function isStartofIfWhile(currentLine) {
  const line = currentLine.trim();
  if (
    (line.startsWith('WHILE') && line.endsWith(')')) ||
    (line.startsWith('IF') && line.endsWith('THEN'))
  ) {
    return true;
  }
  return false;
}

function commonReplace(currentLine) {
  let processedLine = currentLine;
  processedLine = processedLine.replace('ENDSUB', '}');
  processedLine = processedLine.replace('ENDFUNCTION', '}');
  processedLine = processedLine.replace('SUB ', 'function ');
  processedLine = processedLine.replace('FUNCTION ', 'function ');
  processedLine = processedLine.replace('PRINT', 'FUME.print');
  processedLine = processedLine.replace('SYSTEM', 'FUME.system');

  processedLine = processedLine.replace('#{', '');
  processedLine = processedLine.replace('#}', '');
  processedLine = processedLine.replace('func_', '');
  processedLine = processedLine.replace('sub_', '');
  processedLine = processedLine.replace('BYREF', '');
  processedLine = processedLine.replace('<--START', '');
  processedLine = processedLine.replace('END-->', '');

  processedLine = processedLine.replace('ENDIF', '}');
  processedLine = processedLine.replace('IF', 'if');
  processedLine = processedLine.replace('THEN', '');
  processedLine = processedLine.replace('ELSE', '} else {');
  processedLine = processedLine.replace('RETURN', 'return');
  processedLine = processedLine.replace('WHILE', 'while');
  processedLine = processedLine.replace('DO', '}');
  processedLine = processedLine.replace('#', '//');
  return processedLine;
}

function findOperands(dataToProcess) {
  let modifyRHS = false;
  let modifyLHS = false;
  let finalLHS = '';
  let finalRHS = '';
  let repName = '';
  let className = '';
  let fieldName = '';
  /* check if line has 1 = operator, if yes split LHS and RHS
          if LHS/RHS is sv_/lv_/fv_ leave it as it is
          else check if LHS/RHS has 2 . characters (<REP>.<CLASS>.<field>)
          use FUME.setrepValue if LHS and FUME.getrepValue if RHS
          */
  if ((dataToProcess.match(/=/g) || []).length == 1) {
    if (dataToProcess.trim().substr(0, 2) != 'if') {
      const lhsPart = dataToProcess.split('=')[0].trim();
      let rhsPart = dataToProcess.split('=')[1].trim();
      finalRHS = rhsPart;
      if (
        rhsPart.trim().substring(0, 3) == 'sv_' ||
        rhsPart.trim().substring(0, 3) == 'lv_' ||
        rhsPart.trim().substring(0, 3) == 'fv_'
      ) {
        modifyRHS = false;
      } else if ((rhsPart.match(/\./g) || []).length == 2) {
        modifyRHS = true;
        if (rhsPart.substr(0, 1) == '(' && rhsPart.substr(-1) == ')') {
          rhsPart = rhsPart.substr(1, rhsPart.length - 2);
        }
        // [repName, className, fieldName] = rhsPart.split(".");
        repName = rhsPart.split('.')[0];
        className = rhsPart.split('.')[1];
        fieldName = rhsPart.split('.')[2];
        if (repName == 'BANCS') {
          repName = `"${repName}"`;
          className = `"${className}"`;
          fieldName = `"${fieldName}"`;
        }
        finalRHS = `FUME.getrepValue(${repName},${className},${fieldName})`;
      }
      finalLHS = lhsPart;
      modifyLHS = false;
      if (
        lhsPart.trim().substring(0, 3) == 'sv_' ||
        lhsPart.trim().substring(0, 3) == 'lv_' ||
        lhsPart.trim().substring(0, 3) == 'fv_'
      ) {
        modifyLHS = false;
        // initialize these variables at start of function
        listOfVariables.add(`let ${lhsPart.trim()}`);
      } else if ((lhsPart.match(/\./g) || []).length == 2) {
        modifyLHS = true;

        // [repName, className, fieldName] = lhsPart.split(".");
        repName = lhsPart.split('.')[0];
        className = lhsPart.split('.')[1];
        fieldName = lhsPart.split('.')[2];
        if (repName == 'BANCS') {
          repName = `"${repName}"`;
          className = `"${className}"`;
          fieldName = `"${fieldName}"`;
        }

        finalLHS = `            FUME.setrepValue(${repName},${className},${fieldName}`;
      }

      if (modifyLHS) {
        dataToProcess = `${finalLHS},${finalRHS})`;
      }
      if (!modifyLHS && modifyRHS) {
        dataToProcess = `${finalLHS} = ${finalRHS}`;
      }
    }
  }
  return dataToProcess;
}

function removeTrim(dataToProcess) {
  let repName = '';
  let className = '';
  let fieldName = '';
  // TRIM
  /*
  Check if TRIM is there in the line. if yes, find postion of = or != and use trim()  
  */
  if (dataToProcess.indexOf('TRIM') > 0) {
    const trimPos = dataToProcess.indexOf('TRIM');
    let endTrimPos = dataToProcess.indexOf('!=', trimPos);
    if (endTrimPos <= 0) {
      endTrimPos = dataToProcess.indexOf('=', trimPos);
    }
    if (endTrimPos) {
      const preTrim = dataToProcess.substr(0, trimPos);
      const postTrimFld = dataToProcess.substr(
        endTrimPos,
        dataToProcess.length
      );
      let trimFld = dataToProcess.substring(trimPos + 4, endTrimPos).trim();
      if ((trimFld.match(/\./g) || []).length == 2) {
        if (trimFld.substr(0, 1) == '(' && trimFld.substr(-1) == ')') {
          trimFld = trimFld.substr(1, trimFld.length - 2);
        }
        // [repName, className, fieldName] = trimFld.split(".");
        repName = trimFld.split('.')[0];
        className = trimFld.split('.')[1];
        fieldName = trimFld.split('.')[2];
        if (repName == 'BANCS') {
          repName = `"${repName}"`;
          className = `"${className}"`;
          fieldName = `"${fieldName}"`;
        }
        trimFld = `(FUME.getrepValue(${repName},${className},${fieldName}))`;
      }
      dataToProcess = `${preTrim + trimFld}.trim() ${postTrimFld}`;
    }
  }
  return dataToProcess;
}

function fileProcessing(currentline) {
  let repName;
  let className;
  let fieldName;
  let dataToProcess = currentline;

  if (dataToProcess.includes('IMPORT ')) {
    // libname = dataToProcess.substring(7, dataToProcess.length);
    // dataToProcess = `'import {${libname}} from "${libname}.js";`;
    dataToProcess = '';
  }

  if (isStartofFunLine(dataToProcess) || isStartofIfWhile(dataToProcess)) {
    dataToProcess += ' {';
  }
  // fv_u = urhk_dbSelect(fv_q)
  if (dataToProcess.includes('urhk_')) {
    let urhk = dataToProcess.split('=')[1].trim();
    urhk = urhk.replace('(', '",');
    urhk = urhk.replace('_', '"');
    dataToProcess = urhk.replace('urhk', 'FUME.USRHK(');
  }

  // fv_nextPosition = GETPOSITION(fv_inpStr,fv_strToBeRepl)
  if (dataToProcess.includes('GETPOSITION')) {
    let getpos = dataToProcess.split('GETPOSITION')[1].trim();
    getpos = getpos.replace('(', '');
    dataToProcess = getpos.replace(',', '.indexOf(');
    // console.log(dataToProcess)
  }

  dataToProcess = commonReplace(dataToProcess);

  dataToProcess = findOperands(dataToProcess);

  dataToProcess = removeTrim(dataToProcess);

  // dataToProcess = dataToProcess.replace('FIELDEXISTS', 'FUME.isFieldExists');
  if (dataToProcess.indexOf('FIELDEXISTS') > 0) {
    const fldExistsPos = dataToProcess.indexOf('FIELDEXISTS');
    const endFldExistsPos = dataToProcess.lastIndexOf(')');
    if (endFldExistsPos) {
      const prefldExistsFld = dataToProcess.substr(0, fldExistsPos);
      const postfldExistsFld = dataToProcess.substr(
        endFldExistsPos,
        dataToProcess.length
      );
      let fldExistsFld = dataToProcess
        .substring(fldExistsPos + 11, endFldExistsPos)
        .trim();
      if ((fldExistsFld.match(/\./g) || []).length == 2) {
        if (
          fldExistsFld.substr(0, 1) == '(' &&
          fldExistsFld.substr(-1) == ')'
        ) {
          fldExistsFld = fldExistsFld.substr(1, fldExistsFld.length - 2);
        }
        // [repName, className, fieldName] = fldExistsFld.split(".");
        repName = fldExistsFld.split('.')[0];
        className = fldExistsFld.split('.')[1];
        fieldName = fldExistsFld.split('.')[2];
        if (repName == 'BANCS') {
          repName = `"${repName}"`;
          className = `"${className}"`;
          fieldName = `"${fieldName}"`;
        }
        fldExistsFld = `(${repName},${className},${fieldName})`;
      }
      dataToProcess = `${prefldExistsFld}FUME.isFieldExists(${fldExistsFld})${postfldExistsFld}`;
    }
  }
  // dataToProcess = `${dataToProcess}`;
  return dataToProcess;
  // writeFile(jsFileName, dataToProcess);
}

function extractBlocks(line) {
  let currentLine = line;
  if (isStartofFunLine(currentLine)) {
    currentLine = fileProcessing(currentLine);
    const fnName = currentLine.trim().substring(9, currentLine.trim().indexOf('(')).trim();        
    if(fnName.startsWith('set_version_')){      
      currentLine = `${currentLine}
      FUME.print('Begin Function ${fnName}');
      // javascript-obfuscator:disable
      //initialize;`;
    }else{
      currentLine = `${currentLine}\n\tFUME.print('Begin Function ${fnName}');\n\t//initialize;`;
    }
    isExistfun = false;
  }
  if (!isExistfun) {
    const temp = fileProcessing(currentLine);
    tempstr = `${tempstr}\n${temp}`;
  }
  if (isEndofFunLine(currentLine)) {
    tempstr = `${tempstr.replace(
      '//initialize',
      [...listOfVariables].join(';\n\t')
    )}`;
    listOfVariables.clear();

    // add start and end tags for the function
    const fnName = tempstr.trim().substring(9, tempstr.trim().indexOf('(')).trim();
    functionsInLib.push(fnName);
    
    let endofFunctionTag = `\n\tFUME.print('End Function ${fnName}');\n}`
    if(fnName.startsWith('set_version_')){      
      endofFunctionTag = `\t// javascript-obfuscator:enable\n\tFUME.print('End Function ${fnName}');\n}`      
    }
    tempstr = tempstr.substring(0,tempstr.length-1) + endofFunctionTag;
    const startTag = `\n//STARTFUNCTION ${fnName}`;
    const endTag = `\n//ENDFUNCTION ${fnName}\n`;
    tempstr = startTag + tempstr + endTag;
    funsList.push(tempstr);
    tempstr = '';
    isExistfun = true;
  } else if (isExistfun) {
    nonfunList.push(currentLine);
  }
}

async function readFile(fileName) {
  libName = fileName.split('.')[0];
  jsFileName = `${libName}.js`;
  writeFile(jsFileName, `export var ${libName} = (function () {\n`);
  const readInterface = readline.createInterface({
    input: fs.createReadStream(fileName),
    console: false,
  });

  readInterface.on('line', async function(line) {
    // await fileProcessing(line);
    await extractBlocks(line);
  });
  readInterface.on('close', async function() {
    // console.log({ funsList, nonfunList });
    await writeFile(jsFileName, funsList.join(''));    
    await writeFile(jsFileName, '\n// START FUNCTIONLIST\n');
    await writeFile(jsFileName, '\nreturn {\n');
    await writeFile(jsFileName, functionsInLib.join(',\n'));    
    await writeFile(jsFileName, '};\n// END FUNCTIONLIST\n})();\n');
  });
}

//readFile('function.scl');
readFile(process.argv[2]);
