import { FUME } from 'FUME.js';
import { LibCommonB001 } from 'LibCommonB001.js';
import { LibCommonB002 } from 'LibCommonB002.js';
import { LibBusinessB001 } from 'LibBusinessB001.js';

export const LibTechnicalB001 = (function () {
    // STARTFUNCTION versionLibTechnicalB001
    /**
   *
   * @param {*} functionObj No inputs
   * @summary	Dummy function
   * @returns {String} Dummy
   */
    function versionLibTechnicalB001() {
    // javascript-obfuscator:disable
        const version = '20200515205859';
        // javascript-obfuscator:enable
        return version;
    }
    // ENDFUNCTION versionLibTechnicalB001

    // STARTFUNCTION getInputArgumentsB
    /**
   *
   * @param {Object} functionObj function object
   * @summary	Function to get the inputs from MTT.Input repository. If srlNum is passed it retruns for it else entire array as well
   * @returns {boolean} true/false
   * @example
   * 		getInputArgumentsB(functionObj);
   */
    function getInputArgumentsB(functionObj) {
        let inpVal;
        let recExsits;
        let counter;

        functionObj.noOfInputs = '0';
        functionObj.argumentValue = '';
        functionObj.argumentArray = [];

        inpVal = '';
        recExsits = 'Y';
        counter = 1;
        functionObj.srlNum = functionObj.srlNum || '1';
        FUME.print(`functionObj.srlNum : ${functionObj.srlNum}`);

        while (recExsits === 'Y') {
            FUME.USRHK('MTTS_PopulateInputDetails', '');
            if (FUME.isFieldExists(FUME.getrepValue('MTT', 'InputDetails', `Argument${counter.toString()}`)) && FUME.getrepValue('MTT', 'InputDetails', `Argument${counter.toString()}`) !== '') {
                FUME.print(`counter : ${counter}`);
                FUME.print(`Argument${FUME.getrepValue('MTT', 'InputDetails', `Argument${counter.toString()}`)}`);
                inpVal = FUME.getrepValue('MTT', 'InputDetails', `Argument${counter.toString()}`);
                if (inpVal === '<CS>') {
                    inpVal = FUME.getrepValue('BANCS', 'STDIN', 'mySolId');
                }

                if (functionObj.srlNum === counter) {
                    functionObj.argumentValue = inpVal;
                }
                functionObj.argumentArray.push(inpVal);
                counter++;
            } else {
                recExsits = 'N';
            }
        }

        functionObj.noOfInputs = counter - 1;
        return true;
    }
    // ENDFUNCTION getInputArgumentsB

    // STARTFUNCTION concatenateFilesB
    /**
   *
   * @param {Object} functionObj function object
   * @summary	This function is used to concatenate the contents of multiple files in single file. Mandatory Inputs - fileType, fileConcatInd and outPutFileName. Other co-mandatory inputs - filesNameFormat,filesName,filesPaths
   * @returns {boolean} true/false
   * @example
   * 		concatenateFilesB(functionObj);
   */
    function concatenateFilesB(functionObj) {
        let mandFlds;
        functionObj.errorMsgs = ' ';

        functionObj.finalName = '';
        LibCommonB001.setErrorFieldsB(functionObj);
        //------------------------------------------------------
        // MANDATORY FIELDS CHECK
        //------------------------------------------------------
        mandFlds = ['fileConcatInd', 'filesType', 'outPutFileName'];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        //------------------------------------------------------
        // Validation for fields
        //------------------------------------------------------
        if (functionObj.fileConcatInd !== 'FORMAT_BASED' && functionObj.fileConcatInd !== 'FIXED_NAME') {
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CCCTF00001', '', '');
            return false;
        }
        if (functionObj.filesType !== 'TEXT') {
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CCCTF00002', '', '');
            return false;
        }
        //------------------------------------------------------
        // CO-MANDATORY FIELDS CHECK
        //------------------------------------------------------
        if (functionObj.fileConcatInd === 'FORMAT_BASED') {
            mandFlds = ['filesNameFormat'];
            if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }
        }
        if (functionObj.fileConcatInd === 'FIXED_NAME') {
            mandFlds = ['filesName', 'filesCount'];
            if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }
        }
        //------------------------------------------------------
        // NON-MANDATORY FIELDS CHECK
        //------------------------------------------------------

        mandFlds = 'filesPaths';
        if (!LibCommonB002.chkNonMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }
        //------------------------------------------------------
        // For file type TEXT
        //------------------------------------------------------
        if (functionObj.filesType !== 'TEXT') {
            if (functionObj.fileConcatInd === 'FORMAT_BASED') {
                if (functionObj.filesPaths !== '') {
                    functionObj.finalName = functionObj.filesPaths + functionObj.filesNameFormat;
                } else {
                    functionObj.finalName = functionObj.filesNameFormat;
                }
            }

            if (functionObj.fileConcatInd === 'FIXED_NAME') {
                const fileTemp = ` ${functionObj.filesPaths}`;
                functionObj.filesName = LibCommonB001.replaceCharB(functionObj.filesName, ',', fileTemp);
                FUME.print(`functionObj.filesName :- ${functionObj.filesName}`);
                functionObj.finalName = functionObj.filesPaths + functionObj.filesName;
            }

            FUME.print(`functionObj.finalName :- ${functionObj.finalName}`);
            const sysOutPut = FUME.system(`cat ${functionObj.finalName} >> ${functionObj.outPutFileName}`);
            FUME.print(`sysOutPut : ${sysOutPut}`);
        }
        return true;
    }
    // ENDFUNCTION concatenateFilesB

    // STARTFUNCTION sendMailUsingMailxB
    /**
   *
   * @param {Object} functionObj Function Object
   * @summary	This function is used to send mail from script using mailx unix command with or without attachments. Picks files for attachment from any path which is passed as a co-mandatory field in case attachment flag is Y . This will be useful for mailing reports. Allowed attachment formats are txt , xlsx, csv, docx ,pptx ,pdf,rpt,zip
   * @returns {boolean} true/false
   * @example
   * 		sendMailUsingMailxB(functionObj);
   */
    function sendMailUsingMailxB(functionObj) {
        let mandFlds;
        LibCommonB001.setErrorFieldsB(functionObj);
        functionObj.noOfChars = '';
        functionObj.attCount = '';
        //-----------------------------------------------------------------------------
        // Check for Mandatory input fields
        //-----------------------------------------------------------------------------
        mandFlds = ['mailContent', 'mailSubject', 'mailSender', 'mailReceiver', 'attachFlg'];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        // ###Enclosing characters in quotes to preserve literal values of all characters passed####
        functionObj.mailContent = `"${functionObj.mailContent}"`;
        functionObj.mailSubject = `"${functionObj.mailSubject}"`;
        //-----------------------------------------------------------------------------
        // Check for Non-Mandatory input fields
        //-----------------------------------------------------------------------------
        mandFlds = ['noOfAttachments'];
        if (!LibCommonB002.chkNonMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        // ###Checking if there is an attachment ####

        if (functionObj.attachFlg === 'Y') {
            if (functionObj.noOfAttachments === 0 || functionObj.noOfAttachments === '') {
                LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDSMX00001', '', '');
                return false;
            }

            // ###Mailx command to send mail with body and attachment ####

            let aStr = `( echo ${functionObj.mailContent}`;
            while (parseInt(functionObj.noOfAttachments) > 0) {
                const d = functionObj.noOfAttachments;
                functionObj.attachmentFile[d] = '';

                // ### Check if attachment and path has been passed ####
                if (functionObj.attachFile[d]) {
                    if (functionObj.attachFile[d] === '') {
                        LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDSMX00003', '', '');
                        return false;
                    }

                    if (functionObj.attachPath[d]) {
                        // #check if fieldpath has been given
                        if (functionObj.attachPath[d] === '') {
                            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDSMX00004', '', '');
                            return false;
                        }
                        functionObj.attachFile[d] = `${functionObj.attachPath[d]}/${functionObj.attachFile[d]}`;
                    } else {
                        LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDSMX00004', '', '');
                        return false;
                    }

                    functionObj.attachmentFile[d] = functionObj.attachFile[d];

                    aStr = `${aStr}; uuencode ${functionObj.attachmentFile[d]} ${functionObj.attachmentFile[d]}`;
                    functionObj.noOfAttachments--;
                } else {
                    LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDSMX00003', '', '');
                    return false;
                }
            }
            aStr = `${aStr}) | mailx -s ${functionObj.mailSubject} -r ${functionObj.mailSender} ${functionObj.mailReceiver}`;
            const b = FUME.system(aStr);
            if (b !== 0) {
                LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDSMX00002', '', '');
                return false;
            }
        } else {
            // #### Using mailx to send mail without attachment #####
            const aStr = `echo ${functionObj.mailContent}|mailx -s ${functionObj.mailSubject} -r ${functionObj.mailSender} ${functionObj.mailReceiver}`;
            const b = FUME.system(aStr);
            if (b !== 0) {
                LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDSMX00002', '', '');
                return false;
            }

            return true;
        }
    }
    // ENDFUNCTION sendMailUsingMailxB

    // STARTFUNCTION throwExceptionB
    /**
   *
   * @param {Object} functionObj function object
   * @summary	Function to raise Exception(both financial transactions and non financial transactions) from product and custom menus. Inputs - excpType, excpCode
   * @returns {boolean} true/false
   * @example
   * 		getInputArgumentsB(functionObj);
   */
    function throwExceptionB(functionObj) {
    //= ========================================
    // Variable Initialization
    //= ========================================

        LibCommonB001.setErrorFieldsB(functionObj);
        functionObj.extCount = '';
        functionObj.additionalDetails = '';

        //= ========================================
        // Mandatory Field check
        //= ========================================
        let mandFlds = ['excpType', 'excpCode'];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }
        //= ========================================
        // Validating exception type
        //= ========================================
        if (functionObj.excpType !== 'FIN_TRAN_EXCP' && functionObj.excpType !== 'NON_FIN_TRAN_EXCP' && functionObj.excpType !== 'CUST_EXCP') {
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDEXCP0001', '', '');
            return false;
        }
        //= ========================================
        // Validating exception code
        //= ========================================
        functionObj.tableName = 'EXT';
        functionObj.keyFields = ['EXCP_CODE', 'BANK_ID'];
        functionObj.keyValues = [ functionObj.excpCode, FUME.getrepValue('BANCS', 'STDIN', 'contextBankId')];
        functionObj.extCount = LibCommonB001.checkRecordCntB(functionObj.tableName, functionObj.keyFields, functionObj.keyValues);
        FUME.print(`functionObj.extCount :- ${functionObj.extCount}`);
        if (functionObj.extCount === 0) {
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDEXCP0002', '', '');
            return false;
        }

        //= ========================================
        // Financial transactions: FIN_TRAN_EXCP
        //= ========================================

        if (functionObj.excpType === 'FIN_TRAN_EXCP') {
            mandFlds = ['ValMode', 'DrCrInd', 'ExceptionIgnoreFlg'];
            if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }

            FUME.setrepValue('BANCS', 'INPARAM', 'ValMode', functionObj.ValMode);
            FUME.setrepValue('BANCS', 'INPARAM', 'DrCrInd', functionObj.DrCrInd);
            FUME.setrepValue('BANCS', 'INPARAM', 'ExceptionIgnoreFlg', functionObj.ExceptionIgnoreFlg);
            const urhkOp = FUME.USRHK('FTS_RaiseException', functionObj.excpCode);
            if (urhkOp === 1) {
                LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDEXCP0004', '', '');
                return false;
            }
            return true;
        }

        //= ========================================
        // Financial transactions: NON_FIN_TRAN_EXCP
        //= ========================================
        if (functionObj.excpType === 'NON_FIN_TRAN_EXCP') {
            const urhkOp = FUME.USRHK('B2k_PutUserException', functionObj.excpCode);
            if (urhkOp === 1) {
                LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDEXCP0004', '', '');
                return false;
            }
            return true;
        }

        //= ========================================
        // Financial transactions: CE
        //= ========================================
        if (functionObj.excpType === 'CUST_EXCP') {
            //= ========================================
            // Mandatory fields check
            //= ========================================
            mandFlds = 'finTranFlg';
            if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }
            //= ========================================
            // Financial Transaction flag validation
            //= ========================================
            if (functionObj.finTranFlg !== 'Y' && functionObj.finTranFlg !== 'N') {
                LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDEXCP0003', '', '');
                return false;
            }
            //= ========================================
            // Non Mandatory fields check
            //= ========================================
            mandFlds = ['tranDetails', 'xcpnCondFileLineNumInd', 'contextInfo', 'tranKey'];
            if (!LibCommonB002.chkNonMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }

            functionObj.additionalDetails = `${functionObj.tranDetails}|${functionObj.xcpnCondFileLineNumInd}|${functionObj.contextInfo}|${functionObj.tranKey}`;
            FUME.print(`functionObj.additionalDetails :- ${functionObj.additionalDetails}`);
            if (functionObj.additionalDetails.trim() === '|||') {
                const urhkOp = FUME.USRHK('PutCustomException', `${functionObj.excpCode}|${functionObj.finTranFlg}`);
                if (urhkOp === 1) {
                    LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDEXCP0004', '', '');
                    return false;
                }
                return true;
            }
            const urhkOp = FUME.USRHK('PutCustomException', `${functionObj.excpCode}|${functionObj.finTranFlg}|${functionObj.additionalDetails}`);
            if (urhkOp === 1) {
                LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDEXCP0004', '', '');
                return false;
            }
            return true;
        }
    }
    // ENDFUNCTION throwExceptionB

    // STARTFUNCTION errorHandlerB
    /**
   *
   * @param {Object} functionObj function object
   * @summary	  This function handles error condition in scripting and displays/writes the error message on screen/file based on Error Type and Error Mode set by user. This can also be used to raise exception based on user inputs.
   * @returns {boolean} true/false
   * @example
   * 		errorHandlerB(functionObj);
   */
    function errorHandlerB(functionObj) {
        functionObj.errorFlg = 'Y';
        if (functionObj.errorType === undefined) {
            return false;
        }

        if (functionObj.errorBindVars === undefined) {
            functionObj.errorBindVars = '';
        }

        let errMsg;
        let op;

        if (functionObj.errorType === 'BATCH') {
            if (functionObj.errorMode === undefined) {
                functionObj.errorMode = 'WRITE_TO_FILE';
            }

            if (functionObj.errorMode === 'WRITE_TO_FILE') {
                errMsg = LibCommonB001.cmmsgerrdescWithInputsB(functionObj.errorCode, FUME.getrepValue('BANCS', 'STDIN', 'userId'), functionObj.errorBindVars);
                op = LibCommonB001.addDataToFileB(functionObj.errorFileName, errMsg);
            }

            if (functionObj.errorMode === 'WRITE_TO_FILE_PUSH_HPR') {
                errMsg = LibCommonB001.cmmsgerrdescWithInputsB(functionObj.errorCode, FUME.getrepValue('BANCS', 'STDIN', 'userId'), functionObj.errorBindVars);
                op = LibCommonB001.addDataToFileB(functionObj.errorFileName, errMsg);
                op = LibCommonB001.pushReportToHPRB(functionObj.errorFileName, 'FAILURE REPORT');
            }

            if (functionObj.errorMode === 'MARK_BATCH_EXEC_FAILED') {
                errMsg = LibCommonB001.cmmsgerrdescWithInputsB(functionObj.errorCode, FUME.getrepValue('BANCS', 'STDIN', 'userId'), functionObj.errorBindVars);
                FUME.setrepValue('BANCS', 'OUTPUT', 'fatalErrorMsg', errMsg);
                FUME.setrepValue('BANCS', 'OUTPUT', 'fatalErrorFlg', 'Y');
                FUME.setrepValue('BANCS', 'OUTPUT', 'successOrFailure', 'F');
            }
        }

        if (functionObj.errorType === 'PROD_MENU') {
            if (functionObj.errorMode === undefined) {
                functionObj.errorMode = 'SET_SRV_ERROR';
            }

            if (functionObj.errorMode === 'SET_SRV_ERROR') {
                errMsg = LibCommonB001.cmmsgerrdescWithInputsB(
                    functionObj.errorCode,
                    FUME.getrepValue('BANCS', 'STDIN', 'userId'),
                    functionObj.errorBindVars
                );
                FUME.USRHK('SRV_SetErr', errMsg);
            }

            if (functionObj.errorMode === 'DISPLAY_AS_EXCEPTION') {
                op = throwExceptionB(functionObj);
            }
        }
        return true;
    }
    // ENDFUNCTION errorHandlerB

    // STARTFUNCTION executeComFileB
    /**
   *
   * @param {Object} functionObj function object
   * @returns {boolean} true/false
   * @summary	  Function to execute a com file. Following inputs need to be passed to the function
   * 1 - inpFileName --name of com file to be executed
   * 2 - noOfInputs - number of inputs to the com file
   * 3 - inputSep - input separator. Required if more than 1 input to the com file
   * 4 - inputStr - input to the com file with separator mentioned as 3rd input
   * @example
   * 		executeComFileB(functionObj);
   */
    function executeComFileB(functionObj) {
        let inpString;
        let inpFileName;
        let fileLocation;
        let file;
        let noOfInputs;
        let inputSep;
        let inputStr;
        let str;
        let x;

        LibCommonB001.setErrorFieldsB(functionObj);
        let mandFlds;
        //= ========================================
        // Mandatory Field check
        //= ========================================
        mandFlds = ['inpFileName', 'noOfInputs'];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }
        inpString = '';

        inpFileName = functionObj.inpFileName;
        fileLocation = LibCommonB001.getFullPathB(inpFileName);
        if (fileLocation.trim() === '') {
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDECOF0001', '', '');
            return false;
        }
        FUME.print(`fileLocation :-${fileLocation}`);
        file = fileLocation + inpFileName;
        noOfInputs = parseInt(functionObj.noOfInputs);
        if (noOfInputs > 1) {
            mandFlds = ['inputSep', 'inputStr'];
            if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }
            inputSep = functionObj.inputSep;
            inputStr = functionObj.inputStr;
            inpString = `'${LibCommonB001.replaceCharB(inputStr, inputSep, "' '")}'`;
            FUME.print('inpString :- ', inpString);
            str = `${file} ${inpString}`;
        } else {
            mandFlds = ['inputStr'];
            if (!LibCommonB002.chkNonMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }
            inputStr = functionObj.inputStr;
            str = `${file} '${inputStr}'`;
        }
        x = FUME.system(str);
        if (x !== 0) {
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDECOF0002', '', '');
            return false;
        }
        return true;
    }
    // ENDFUNCTION executeComFileB

    // STARTFUNCTION validateToTimeGTFromTimeB
    /**
   *
   * @param {Object} functionObj function object
   * @returns {boolean} true/false
   * @summary	 This is a function to call the product user hook valToTimeGEFromTime, which validates Validates whether ToTime is GE fromTime.
   * @example
   * 		validateToTimeGTFromTimeB(functionObj);
   */
    function validateToTimeGTFromTimeB(functionObj) {
        functionObj.timeDiff = '';
        LibCommonB001.setErrorFieldsB(functionObj);
        let mandFlds;
        //= ========================================
        // Mandatory Field check
        //= ========================================
        mandFlds = ['fromTime', 'toTime'];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        let timeComponent;
        let timeCompArr;
        let hh;
        let mm;
        let ss;
        let mms;

        timeComponent = functionObj.fromTime;
        timeCompArr = timeComponent.split(':');
        hh = timeCompArr[0];
        mm = timeCompArr[1];
        ss = timeCompArr[2];
        mms = timeCompArr[3];

        if (parseInt(hh) > 23 || parseInt(mm) > 59 || parseInt(ss) > 59) {
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDTMVF0001', '', '');
            return false;
        }

        timeComponent = functionObj.toTime;
        timeCompArr = timeComponent.split(':');
        hh = timeCompArr[0];
        mm = timeCompArr[1];
        ss = timeCompArr[2];
        mms = timeCompArr[3];

        if (parseInt(hh) > 23 || parseInt(mm) > 59 || parseInt(ss) > 59) {
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDTMVF0002', '', '');
            return false;
        }

        FUME.setrepValue('BANCS', 'INPARAM', 'fromTime', functionObj.fromTime);
        FUME.setrepValue('BANCS', 'INPARAM', 'toTime', functionObj.toTime);
        const urhkOp = FUME.USRHK('valToTimeGEFromTime', '');
        functionObj.timeDiff = LibCommonB001.copyOutparamFieldB('timeDiff', '');
        return true;
    }
    // ENDFUNCTION validateToTimeGTFromTimeB

    // STARTFUNCTION convertAmtToMillionLacFmtB
    /**
   *
   * @param {Object} functionObj function object
   * @returns {boolean} true/false
   * @summary	 This function calls the user hook urhk_B2k_floatWithComma, which can be used to convert input amount to string with commas using the million/lakh format. inputs are
   * 1) inputAmount
   * 2) fromCurrency
   * 3) amountWidth
   * Output will be in outputAmount.
   * @example
   * 		convertAmtToMillionLacFmtB(functionObj);
   */
    function convertAmtToMillionLacFmtB(functionObj) {
        LibCommonB001.setErrorFieldsB(functionObj);
        let urhkOp;
        //= ========================================
        // Mandatory Field check
        //= ========================================
        const mandFlds = ['inputAmount', 'fromCurrency', 'amountWidth'];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        FUME.setrepValue('BANCS', 'INPARAM', 'InputAmount', functionObj.inputAmount);
        FUME.setrepValue('BANCS', 'INPARAM', 'FromCurrency', functionObj.fromCurrency);
        FUME.setrepValue('BANCS', 'INPARAM', 'AmountWidth', functionObj.amountWidth);
        urhkOp = FUME.USRHK('B2k_floatWithComma', '');
        functionObj.outputAmount = LibCommonB001.copyOutparamFieldB('OutputAmount', '');
        urhkOp = urhkOp === '0';
        return urhkOp;
    }
    // ENDFUNCTION convertAmtToMillionLacFmtB

    // STARTFUNCTION arithmeticOperationB
    /**
   *
   * @param {Object} functionObj function object
   * @returns {boolean} true/false
   * @summary	 To perform arithmetic operations like addition, subtraction, multiplication and Division.The number of fields will be given as input in field NoOfFields. For Addition, subtraction and multiplication NoOfFields should be equal to or greater than 2 and for Division this should be exactly 2.
   * @example
   * 		arithmeticOperationB(functionObj);
   */
    function arithmeticOperationB(functionObj) {
        LibCommonB001.setErrorFieldsB(functionObj);
        let mandFlds;
        //= ========================================
        // Mandatory Field check
        //= ========================================
        mandFlds = ['operationSymbol', 'noOfFields', 'dataType', 'variable'];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        //= ========================================
        // Non - Mandatory Field check
        //= ========================================
        mandFlds = ['roundoffReqd', 'roundOffDecimalPlaces'];
        if (!LibCommonB002.chkNonMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        //= ========================================
        // Field count check
        //= ========================================

        if (parseInt(functionObj.noOfFields) < 2) {
            const errMessage = 'Atleast two fields are required for an arithmetic operation.';
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'MSG', errMessage, '');
            return false;
        }

        if (functionObj.operationSymbol === '/') {
            if (parseInt(functionObj.noOfFields) > 2) {
                const errMessage = 'Max two fields are allowed for division operation.';
                LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'MSG', errMessage, '');
                return false;
            }

            if (parseInt(functionObj.variable[1]) === 0) {
                const errMessage = 'Denominator cannot be 0 for division operation.';
                LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'MSG', errMessage, '');
                return false;
            }
        }

        if (functionObj.dataType !== 'CINT' && functionObj.dataType !== 'CDOUBLE') {
            const errMessage = 'Only CINT and CDOUBLE data types are allowed for arithmetic operations.';
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'MSG', errMessage, '');
            return false;
        }

        //= ========================================
        // Arithmetic operation logic
        //= ========================================
        let sVal;
        if (
            functionObj.operationSymbol === '+' ||
      functionObj.operationSymbol === '-' ||
      functionObj.operationSymbol === '/'
        ) {
            sVal = '0';
        }

        if (functionObj.operationSymbol === '*') {
            sVal = '1';
        }

        if (functionObj.operationSymbol === '/') {
            if (functionObj.dataType === 'CDOUBLE') {
                sVal =
          parseFloat(functionObj.variable[0]) /
          parseFloat(functionObj.variable[1]);
            } else {
                sVal =
          parseInt(functionObj.variable[0]) / parseInt(functionObj.variable[1]);
            }
        } else {
            let recCount = 0;
            while (recCount < functionObj.variable.length) {
                if (functionObj.operationSymbol === '+') {
                    if (functionObj.dataType === 'CDOUBLE') {
                        sVal =
              parseFloat(sVal) + parseFloat(functionObj.variable[recCount]);
                    } else {
                        sVal = parseInt(sVal) + parseInt(functionObj.variable[recCount]);
                    }
                }

                if (functionObj.operationSymbol === '-') {
                    if (recCount === 0) {
                        sVal = parseFloat(functionObj.variable[recCount]);
                    } else if (functionObj.dataType === 'CDOUBLE') {
                        sVal =
              parseFloat(sVal) - parseFloat(functionObj.variable[recCount]);
                    } else {
                        sVal = parseInt(sVal) - parseInt(functionObj.variable[recCount]);
                    }
                }

                if (functionObj.operationSymbol === '*') {
                    if (functionObj.dataType === 'CDOUBLE') {
                        sVal =
              parseFloat(sVal) * parseFloat(functionObj.variable[recCount]);
                    } else {
                        sVal = parseInt(sVal) * parseInt(functionObj.variable[recCount]);
                    }
                }
            }

            /* if ((r).(c).("dataType") == "C}UBLE") {
			s = FORMAT$(s, "%f")
		} else {
			s = FORMAT$(s, "%d")
		} */

            FUME.print(`sVal :- ${sVal}`);
            recCount++;
        }
        //= ========================================
        // Round Off for Data Type CDOUBLE
        //= ========================================
        if (
            functionObj.dataType === 'CDOUBLE' &&
      functionObj.roundoffReqd === 'Y'
        ) {
            sVal = sVal.toFixed(functionObj.roundOffDecimalPlaces);
        }

        functionObj.result = sVal;
        return true;
    }
    // ENDFUNCTION arithmeticOperationB

    // STARTFUNCTION checkSpecialCharactersB
    /**
   *
   * @param {Object} functionObj function object
   * @returns {boolean} true/false
   * @summary	 This function will be used to check if any special character is present in a given string other than what is mentioned in validCharSet. Multiple strings can be passed as input with the delimiter specified. Inputs to the function are
   * 1)  noOfFields - number of fields in the input string
   * 2)  inpString - Input string. if more than one value to be passed, it should be seperated by a delimiter.
   * 3)  fldInpDelimiter - delimiter
   * 4)  validCharSet - Valid character set to be mentioned.
   * @example
   * 		checkSpecialCharactersB(functionObj);
   */
    function checkSpecialCharactersB(functionObj) {
        let mandFlds;
        let noOfFields;
        let inpStr;
        let mismatchCharCnt;
        let inpField;
        LibCommonB001.setErrorFieldsB(functionObj);

        mandFlds = ['noOfFields', 'inpString', 'validCharSet'];
        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        noOfFields = functionObj.noOfFields;
        if (parseInt(noOfFields) > 1) {
            mandFlds = ['fldInpDelimiter'];
            if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
                // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
                return false;
            }
        }

        // #################################
        // Delimiter Check
        // #################################
        if (functionObj.fldInpDelimiter.trim() !== '') {
            if (functionObj.validCharSet.includes(functionObj.fldInpDelimiter)) {
                LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'CDCKSC0001', '', '');
                return false;
            }
        }

        inpStr = functionObj.inpString;

        // #############################
        // check valid string
        // ###############################
        if (functionObj.validCharSet !== '') {
            const pattern = new RegExp(`\\[${functionObj.validCharSet}]\\`, 'g');
            const replacedString = inpStr.replace(pattern, '');
            mismatchCharCnt = replacedString.length;

            if (mismatchCharCnt < parseInt(noOfFields)) {
                return true;
            }
            let y = 0;
            functionObj.errorFld = '';
            while (y < parseInt(noOfFields)) {
                if (parseInt(noOfFields) > 1) {
                    inpField = LibCommonB001.getNthFieldFromStringB(
                        replacedString,
                        functionObj.fldInpDelimiter,
                        y + 1
                    );
                    FUME.print('inpField :-', inpField);
                } else {
                    inpField = replacedString;
                }
                if (inpField !== '') {
                    functionObj.fldNum = y + 1;

                    functionObj.errorFld = `${functionObj.errorFld} Field ${
                        functionObj.fldNum
                    },`;
                    FUME.print('functionObj.errorFld :-', functionObj.errorFld);
                }
                y += 1;
            }

            functionObj.errorFld = functionObj.errorFld.substring(
                1,
                functionObj.errorFld.length
            );
            FUME.print(`functionObj.errorFld After LEFT :- ${functionObj.errorFld}`);
            const errMessage = `Invalid Character:${functionObj.errorFld}`;
            LibCommonB001.setErrorFieldsB(functionObj, true, '1', 'MSG', errMessage, '');
            return false;
        }
        return true;
    }
    // ENDFUNCTION checkSpecialCharactersB

    // STARTFUNCTION setVariablesToNullB
    /**
   *
   * @param {Object} functionObj function object
   * @returns {boolean} true/false
   * @summary	 This function will be used to initialize all the variables passed in inputStr to null
   * @example
   * 		setVariablesToNullB(functionObj);
   */
    function setVariablesToNullB(functionObj) {
        const mandFlds = ['inpStr'];
        LibCommonB001.setErrorFieldsB(functionObj);

        if (!LibCommonB002.chkMandatorySRVInputsB(functionObj, mandFlds)) {
            // LibCommonB001.setErrorFieldsB(functionObj, true, functionObj.errorDetails[0].errorCode, 'MSG', functionObj.errorDetails[0].errorMsg, '');
            return false;
        }

        const inpStrArr = functionObj.inpStr.split('|');
        for (let i = 0; i < inpStrArr.length; i += 1) {
            functionObj[inpStrArr[i]] = '';
        }

        return true;
    }
    // ENDFUNCTION setVariablesToNullB
    // START FUNCTIONLIST
    return {
        versionLibTechnicalB001,
        getInputArgumentsB,
        concatenateFilesB,
        sendMailUsingMailxB,
        throwExceptionB,
        errorHandlerB,
        executeComFileB,
        validateToTimeGTFromTimeB,
        convertAmtToMillionLacFmtB,
        arithmeticOperationB,
        checkSpecialCharactersB,
        setVariablesToNullB
    };
    // END FUNCTIONLIST
})();
