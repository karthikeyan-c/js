import { FUME } from 'FUME.js';
import { LibCommonB001 } from 'LibCommonB001.js';
import { LibCommonB002 } from 'LibCommonB002.js';
export var LibDateB001 = (function () {
    // STARTFUNCTION versionLibDateB001
    /**
   *
   * @param {*} No inputs
   * @summary	Dummy function
   * @returns {String} Dummy
   */
    function versionLibDateB001() {
        // javascript-obfuscator:disable
        const version = '20200616090805';
        // javascript-obfuscator:enable
        return version;
    }
    // ENDFUNCTION versionLibDateB001
    // STARTFUNCTION getSysDateTimeWithFormatB
    /**
   * @description This function will return systemdate in request date formate
   * @param    {string} format Format of date (like YYYY-DD-MM)
   * @returns  {string} system date
   */
    function getSysDateTimeWithFormatB(format) {
        let dtObj = {};
        let sysDate = '';
        dtObj.systemDate = 0;
        dtObj.outputFields = 'systemDate';
        dtObj.columnNames = `TO_CHAR(SYSTIMESTAMP,'${format}')`;
        dtObj.tableName = 'DUAL';
        dtObj.whereFields = [];
        dtObj.whereValues = [];
        const retVal = LibCommonB001.selectFromTableB(dtObj);
        if (retVal) {
            sysDate = dtObj.systemDate;
        }
        return sysDate;
    }
    // ENDFUNCTION getSysDateTimeWithFormatB
    // STARTFUNCTION isYearLeapB
    /**
   *
   *
   * @param {*} year input year
   * @returns {boolean} true if year is leap year else false
   */
    function isYearLeapB(year) {
        return year % 100 === 0 ? year % 400 === 0 : year % 4 === 0;
    }
    // ENDFUNCTION getYearB
    // STARTFUNCTION getDateInFIFormat
    /**
   *
   * @description this returns date back in FI Format
   * @param {*} date input date. format should be in DD-MM-YYYY
   * @returns {string} YYYY-MM-DDT00:00:00.000 formated date
   */
    function getDateInFIFormat(date) {
        FUME.print('Input Date:' + date);
        let dd = date.substr(0, 2).padStart(2, '0');
        let mm = date.substr(3, 2).padStart(2, '0');
        let yyyy = date.substr(6, 4);
        FUME.print('Output Date:' + `${yyyy}-${mm}-${dd}T00:00:00.000`);
        return `${yyyy}-${mm}-${dd}T00:00:00.000`;
    }
    // ENDFUNCTION getDateInFIFormat
    // STARTFUNCTION getDateDiffB
    /**
     *
     *
     * @param {*} dateObj function object
     *  @param {*} dateObj.startDate : input date 1 with date format dd-mm-yyyy
     * @param {*}dateObj.endDate : input date 2 with date format dd-mm-yyyy
     * @param {*}dateObj.diffType	 : type of date difference i.e for date difference in days value:"D"
                             : date difference in Months value:"M" date difference in days Year:"Y"
                             : date difference in Quarters value:"Q"
     * @param {*} dateObj.leapFlg    : Optional
     * @description              :This method will take object with attributes inputDate1, inputDate2, diffType and leapFlg and output will be available in same object with keys
     * numOfMonths or  numOfDays or numOfQuaters or numOfYears based on your dffType
     * @returns {boolean} true/false
     * @example                  : getDateDiffB({inputDate1:'01-02-2020', inputDate2:'08-12-2020', diffType:'D'})
     */
    function getDateDiffB(dateObj) {
        let startDate = dateObj.startDate;
        let endDate = dateObj.endDate;
        let diffType = dateObj.diffType;
        let leapFlg = dateObj.leapFlg || 'NO';
        let urhkOp;
        let mandFlds = ['startDate', 'endDate', 'diffType'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dateObj, mandFlds)) {
            return false;
        }
        if (['M', 'MD', 'Y'].includes(diffType)) {
            let fields = `${startDate}|${endDate}|${leapFlg}`;
            FUME.print('inputs to B2k_getMonthDayDiff:' + fields);
            urhkOp = FUME.USRHK('B2k_getMonthDayDiff', fields);
            FUME.print('urhkOp of B2k_getMonthDayDiff : ' + urhkOp);
            if (!urhkOp) {
                let numOfMonths = FUME.getrepValue('BANCS', 'OUTPARAM', 'NumOfMonths');
                if (diffType === 'Y') {
                    dateObj.numOfYears = Math.floor(numOfMonths / 12).toString();
                } else if (diffType === 'M') {
                    dateObj.numOfMonths = numOfMonths;
                } else if (diffType === 'MD') {
                    dateObj.numOfDays = FUME.getrepValue(
                        'BANCS',
                        'OUTPARAM',
                        'NumOfDays'
                    );
                    dateObj.numOfMonths = numOfMonths;
                }
                return true;
            }
            let err = FUME.getrepValue('BANCS', 'OUTPARAM', 'errorMesg');
            FUME.print('err of B2k_getMonthDayDiff' + err);
            LibCommonB002.setErrorFieldsB(dateObj, true, '', err);
            return false;
        } else if (['D', 'Q'].includes(diffType)) {
            FUME.setrepValue('BANCS', 'INPARAM', 'date1', endDate);
            FUME.setrepValue('BANCS', 'INPARAM', 'date2', startDate);
            urhkOp = FUME.USRHK('B2k_dateDiff', '');
            FUME.print('urhkOp of B2k_dateDiff' + urhkOp);
            if (!urhkOp) {
                let dateDiff = FUME.getrepValue('BANCS', 'OUTPARAM', 'dateDiff');
                FUME.print('dateDiff from B2k_dateDiff' + dateDiff);
                if (diffType === 'D') {
                    dateObj.numOfDays = dateDiff;
                } else {
                    dateObj.numOfQuaters = Math.ceil(dateDiff / 90).toString();
                }
                return true;
            }
            LibCommonB002.setErrorFieldsB(
                dateObj,
                true,
                'CDGDD001',
                'CDGDD001 - Error during date diff calculation'
            );
            return false;
        }
        LibCommonB002.setErrorFieldsB(
            dateObj,
            true,
            'CDGDD001',
            'CDGDD001 - Error during date diff calculation'
        );
        return false;
    }
    // ENDFUNCTION getDateDiffB
    // STARTFUNCTION withinDateRangeB
    /**
   * @description check if input date is within the range of start date and end date Expected date format: dd-mm-yyyy
   * @param {*} startDate start date
   * @param {*}endDate end date
   * @param {*} inputDate input date
   * @returns   {boolean} true if in range otherwise false
   * @example   withinDateRangeB(startDate:'DD-MM-YYYY', endDate:'DD-MM-YYYY', inputDate:'DD-MM-YYYY')
   */
    function withinDateRangeB(startDate, endDate, inputDate) {
        FUME.setrepValue('BANCS', 'INPARAM', 'date1', startDate);
        FUME.setrepValue('BANCS', 'INPARAM', 'date2', endDate);
        FUME.USRHK('B2k_dateDiff', '');
        let dateDiff = FUME.getrepValue('BANCS', 'OUTPARAM', 'dateDiff');
        FUME.print('dateDiff of startDate and endDate:' + dateDiff);
        if (dateDiff > 0) {
            return false;
        }
        FUME.setrepValue('BANCS', 'INPARAM', 'date1', inputDate);
        FUME.setrepValue('BANCS', 'INPARAM', 'date2', startDate);
        if (!FUME.USRHK('B2k_dateDiff', '')) {
            dateDiff = FUME.getrepValue('BANCS', 'OUTPARAM', 'dateDiff');
            FUME.print('dateDiff of inputDate and startDate:' + dateDiff);
            if (dateDiff < 0) {
                return false;
            }
        } else {
            return false;
        }

        FUME.setrepValue('BANCS', 'INPARAM', 'date1', endDate);
        FUME.setrepValue('BANCS', 'INPARAM', 'date2', inputDate);
        if (!FUME.USRHK('B2k_dateDiff', '')) {
            dateDiff = FUME.getrepValue('BANCS', 'OUTPARAM', 'dateDiff');
            FUME.print('dateDiff of endDate and inputDate:' + dateDiff);
            if (dateDiff < 0) {
                return false;
            }
        } else {
            return false;
        }

        return true;
    }
    // ENDFUNCTION withinDateRangeB
    // STARTFUNCTION addMnthsDaysToDateB
    /**
   * @description his method will add number of days and month to a given date and result will be in same dateObj with key named addedDate
   * @param {object} dateObj input data object
   * @param {*} dateObj.date Date in which operation will be perform. will be in DD-MM-YYYY format
   * @param {*} dateObj.noOfDays Number of days to add
   * @param {*} dateObj.noOfMonths Number of months to add
   * @param {*} dateObj.addedDate OUTPUT of the function if success
   * @returns {boolean} true on success and false on failure
   */
    function addMnthsDaysToDateB(dateObj) {
        let mandFlds = ['date', 'noOfDays', 'noOfMonths'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dateObj, mandFlds)) {
            return false;
        }
        let date = dateObj.date.substr(0, 10);
        let noOfDays = dateObj.noOfDays;
        let noOfMonths = dateObj.noOfMonths;
        FUME.setrepValue('BANCS', 'INPARAM', 'date', date);
        FUME.setrepValue('BANCS', 'INPARAM', 'no_of_days', noOfDays);
        FUME.setrepValue('BANCS', 'INPARAM', 'no_of_months', noOfMonths);
        let fields = `${date}|${noOfMonths}|${noOfDays}`;
        FUME.print('inputs to B2k_Add_MonthsDays_To_Date:' + fields);
        if (!FUME.USRHK('B2k_Add_MonthsDays_To_Date', fields)) {
            FUME.print(FUME.getrepValue('BANCS', 'OUTPARAM', 'MODIFIED_DATE'));
            let addedDate = FUME.getrepValue('BANCS', 'OUTPARAM', 'MODIFIED_DATE');
            dateObj.addedDate = addedDate.substr(0, 10);
            return true;
        }
        LibCommonB002.setErrorFieldsB(
            dateObj,
            true,
            '1',
            'CDAMTD0001',
            'CDAMTD0001- ERROR IN ADDING MONTH/DAYS TO DATE'
        );
        return false;
    }
    // ENDFUNCTION addMnthsDaysToDateB
    // STARTFUNCTION getYearB
    /**
   *
   * @description Takes a one or 2 digit year being queried and returns 4 digit year.
   * The reference year is the 4 digit yearof LGI BOD Date and the window width is 30.
   * uses product userhook B2k_getYear for the same
   * @param {*} inputYear 2 digit year (YY)
   * @returns {string} YEAR(YYYY)
   */
    function getYearB(inputYear) {
        let outputYear = '';
        let urhkOp = FUME.USRHK('B2k_getYear', inputYear);
        urhkOp = urhkOp === 0;
        if (urhkOp) {
            outputYear = FUME.getrepValue('BANCS', 'OUTPARAM', 'year');
        }
        return outputYear;
    }
    // ENDFUNCTION getYearB
    // START FUNCTIONLIST
    return {
        versionLibDateB001,
        getSysDateTimeWithFormatB,
        isYearLeapB,
        getDateInFIFormat,
        getDateDiffB,
        withinDateRangeB,
        addMnthsDaysToDateB,
        getYearB
    };
    // END FUNCTIONLIST
})();
