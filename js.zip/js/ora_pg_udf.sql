--  **************************************************************************
--
--  File        : PG_ORA_UDFS.sql
--
--  Description : This file has the User Defined Functions (UDF) to be 
--				  created in postgresql database.This is to be done to 
--				  achieve similar function in Postgresql as that of the Built
--				  in functions(BIF) of Oracle
--
--                1) months_between
--                2) subtract_days 
--                3) subtract_dates
--
--
--  **************************************************************************
--
--  sl.no   Date        Author            Modification
--  -----   ----------  ---------         ---------------------
--   1.0    27-08-2019  Nandan_Agarwal    Original Version.
--   2.0    15-10-2019  Arun Sharma       Modified ora.add_days to handle 
--                                        2nd argument independent of datatype
--   3.0    23-10-2019  Nandan Agarwal    Added UDF ora.nvl to handle oracle NVL.
--
--  **************************************************************************



create schema ora;
grant all on schema ora to tbaadm
grant usage on schema ora to tbaadm,tbagen;


CREATE VIEW dual AS SELECT 'X'::varchar AS dummy;
GRANT SELECT, REFERENCES ON dual TO tbaadm,tbagen;

--UDF Name:MONTHS_BETWEEN
--Description:To perform the MONTHS_BETWEEN operation between 2 date arguments.
--Parameters: [t_start]  - date
--            [t_end]    - date
--Output: 	  months_between = date1 - date2

CREATE FUNCTION ora.months_between (t_start timestamp with time zone, t_end timestamp with time zone)
RETURNS integer
AS $$
	SELECT EXTRACT(YEAR FROM AGE(t_start,t_end)) * 12 +
              EXTRACT(MONTH FROM AGE(t_start,t_end));
$$
LANGUAGE SQL
IMMUTABLE
RETURNS NULL ON NULL INPUT;

-- select ora.months_between('30-07-2019'::timestamp,'30-10-2019'::timestamp)

--UDF Name:ADD_MONTHS
--Description:To perform the ADD_MONTHS operation on a date 
--Parameters: [start]  - The string from which the substring must be taken.
--            [months]      - Length of the substring(Optional).
--Output: 	  add_months = start + months

CREATE FUNCTION ora.add_months(start timestamp with time zone, months INT) RETURNS timestamp AS
$$
  SELECT (start + (months || ' months')::INTERVAL)::timestamp
$$
LANGUAGE sql IMMUTABLE

--select ora.add_months(now()::timestamp,5)
--select ora.add_months(now()::date,5) 

--UDF Name:TRUNC
--Description:To perform the TRUNC operation for a date field(single arguement)
--Parameters: [input_date]  - The date field for which trunc needs to be done.
--Output: 	  trunc(input_date)

CREATE FUNCTION ora.trunc(input_date timestamp with time zone) RETURNS timestamp AS
$$
  SELECT date_trunc('DAY',input_date::timestamp)
$$
LANGUAGE sql IMMUTABLE

--select ora.trunc(BODATEMODIFIED) from test_all_datatype where BODATEMODIFIED is not null

--UDF Name:TRUNC
--Description:To perform the TRUNC operation for a number field(single arguement)
--Parameters: [input_number]  - The number field for which trunc needs to be done.
--Output: 	  trunc(input_number)

CREATE FUNCTION ora.trunc(input_number numeric) RETURNS numeric AS
$$
  SELECT trunc(input_number)
$$
LANGUAGE sql IMMUTABLE


--UDF Name:LAST_DAY
--Description:It will compute the last day of the month for the input date
--			  which is being passed as an argument.
--Parameters: [date]  - The input date for which the last day needs to be calculated.
-- Output     : datetime

CREATE  function ora.last_day(timestamp)
        RETURNS timestamp AS
        $$
        SELECT (date_trunc('MONTH', $1) + INTERVAL '1 MONTH - 1 day')::timestamp;
        $$ LANGUAGE 'sql'
        IMMUTABLE STRICT;
		
-- select ora.last_day(now()::timestamp) from dual

--UDF Name:SUBTRACT_DATES
--Description:To subtract two dates..
--Parameters: [t_start]  - The first input.
--            [t_end]      - The second input 
--Output    :  t_start - t_end

CREATE FUNCTION ora.SUBTRACT_DATES (t_start timestamp with time zone, t_end timestamp with time zone)
RETURNS integer
AS $$
select (t_start)::date - (t_end)::date
$$
LANGUAGE SQL
IMMUTABLE
RETURNS NULL ON NULL INPUT;

-- select ora.subtract_dates(now()::timestamp,to_date('30-06-2019','dd-mm-yyyy')) from dual;

--UDF Name:	SUBTRACT_DAYS
--Description: To subtract from a date when the no of days to be subtracted is given.
--Parameters: [t_start]  	- The date on which subtraction must be performed.
--            [no_of_days]  -  Number of days to be subtracted.
--Ouput		:	t_start - no_of_days

CREATE FUNCTION ora.SUBTRACT_DAYS (t_start timestamp with time zone, no_of_days int)
RETURNS timestamp
AS $$
select (t_start - (''''||no_of_days||' days''')::interval)::timestamp
$$
LANGUAGE SQL
IMMUTABLE
RETURNS NULL ON NULL INPUT;

--select ora.subtract_days(now()::timestamp,5)

--UDF Name:	ADD_DAYS
--Description: To add to a date when the no of days to be added is given
--Parameters: [date]  - The date on which addition must be performed.
--            [anyelement]  -Number of days to be added.
--Output 	:	date + numeric or integer value

CREATE OR REPLACE FUNCTION ora.add_days(timestamp with time zone,anyelement)
RETURNS timestamp AS $$
SELECT ($1 + interval '1 day' * $2)::timestamp;
$$ LANGUAGE SQL IMMUTABLE;

-- select ora.add_days(now()::timestamp,1)

--UDF Name:INSTR (3 parameters)
--Description:To perform the INSTR operation with 3 number of parameters.
--Parameters: [string]  - The string in which the string_to_search to be searched.
--			  [string_to_search] - The string to be searched in the input string.
--			  [beg_index] - The index from which the string to be searched for the string.
--Ouput : The position of the string_to_search in the string.

CREATE FUNCTION ora.instr(string varchar, string_to_search varchar, beg_index integer)
RETURNS integer AS $$
DECLARE
    pos integer NOT NULL DEFAULT 0;
    temp_str varchar;
    beg integer;
    length integer;
    ss_length integer;
BEGIN
    IF beg_index > 0 THEN
        temp_str := substring(string FROM beg_index);
        pos := position(string_to_search IN temp_str);

        IF pos = 0 THEN
            RETURN 0;
        ELSE
            RETURN pos + beg_index - 1;
        END IF;
    ELSE
        ss_length := char_length(string_to_search);
        length := char_length(string);
        beg := length + beg_index - ss_length + 2;

        WHILE beg > 0 LOOP
            temp_str := substring(string FROM beg FOR ss_length);
            pos := position(string_to_search IN temp_str);

            IF pos > 0 THEN
                RETURN beg;
            END IF;

            beg := beg - 1;
        END LOOP;

        RETURN 0;
    END IF;
END;
$$ LANGUAGE plpgsql STRICT IMMUTABLE;

--UDF Name:INSTR (2 parameters)
--Description:To perform the INSTR operation with 4 number of parameters.
--Parameters: [string]  - The string in which the string_to_search to be searched.
--			  [string_to_search] - The string to be searched in the input string.
--Ouput : The position of the string_to_search in the string.

CREATE FUNCTION ora.instr(varchar, varchar) RETURNS integer AS $$
DECLARE
    pos integer;
BEGIN
    pos:= ora.instr($1, $2, 1);
    RETURN pos;
END;
$$ LANGUAGE plpgsql STRICT IMMUTABLE;

--UDF Name:INSTR (4 parameters)
--Description:To perform the INSTR operation with 4 number of parameters.
--Parameters: [string]  - The string in which the string_to_search to be searched.
--			  [string_to_search] - The string to be searched in the input string.
--			  [beg_index] - The index from which the string to be searched for the string.
--			  [occur_index] - The occurence from which the string_to_search to be taken into consideration.
--Ouput : The position of the string_to_search in the string.

CREATE FUNCTION ora.instr(string varchar, string_to_search varchar,
                      beg_index integer, occur_index integer)
RETURNS integer AS $$
DECLARE
    pos integer NOT NULL DEFAULT 0;
    occur_number integer NOT NULL DEFAULT 0;
    temp_str varchar;
    beg integer;
    i integer;
    length integer;
    ss_length integer;
BEGIN
    IF beg_index > 0 THEN
        beg := beg_index;
        temp_str := substring(string FROM beg_index);

        FOR i IN 1..occur_index LOOP
            pos := position(string_to_search IN temp_str);

            IF i = 1 THEN
                beg := beg + pos - 1;
            ELSE
                beg := beg + pos;
            END IF;

            temp_str := substring(string FROM beg + 1);
        END LOOP;

        IF pos = 0 THEN
            RETURN 0;
        ELSE
            RETURN beg;
        END IF;
    ELSE
        ss_length := char_length(string_to_search);
        length := char_length(string);
        beg := length + beg_index - ss_length + 2;

        WHILE beg > 0 LOOP
            temp_str := substring(string FROM beg FOR ss_length);
            pos := position(string_to_search IN temp_str);

            IF pos > 0 THEN
                occur_number := occur_number + 1;

                IF occur_number = occur_index THEN
                    RETURN beg;
                END IF;
            END IF;

            beg := beg - 1;
        END LOOP;

        RETURN 0;
    END IF;
END;
$$ LANGUAGE plpgsql STRICT IMMUTABLE;

--UDF Name: TO_NCHAR
--Description: Dummy UDF to handle the to_nchar ,internally it just returns the input string.
--Parameters: [varchar]  - The string for which the to_nchar operation needs to be done.
--Output :	The input string

CREATE OR REPLACE FUNCTION ora.to_nchar(varchar)
RETURNS varchar  AS $$
SELECT $1 ;
$$ LANGUAGE SQL IMMUTABLE;

--select ora.to_nchar('nandan')

--UDF Name: ora.nvl(argument 1, argument 2)
--Description: Overloaded UDF to handle oracle version of nvl.
--Parameters: [expression 1, expression 2] : Overloaded argument types are:
--                                       Case 1 (integer, integer)
--                                       Case 2 (numeric, numeric)
--                                       Case 3 (text,text)
--                                       Case 4 (timestamp with time zone,timestamp with time zone)
--                                       Case 5 (text,integer)
--                                       Case 6 (integer, numeric)
--Output :Return the first not null argument of type expression 1. If both are null then null is returned. 

CREATE  FUNCTION ora.nvl(integer,integer)
RETURNS integer AS $$
SELECT case when $1 is not null then $1 when $2 is not null then $2 else null end
$$ LANGUAGE SQL IMMUTABLE;

CREATE  FUNCTION ora.nvl(numeric,numeric)
RETURNS numeric AS $$
SELECT case when $1 is not null then $1 when $2 is not null then $2 else null end
$$ LANGUAGE SQL IMMUTABLE;

CREATE  FUNCTION ora.nvl(text,text)
RETURNS text AS $$
SELECT case when nullif($1,'') is not null then $1 when nullif($2,'') is not null then $2 else null end
$$ LANGUAGE SQL IMMUTABLE;

CREATE  FUNCTION ora.nvl(timestamp with time zone,timestamp with time zone)
RETURNS timestamp AS $$
SELECT case when $1 is not null then $1::timestamp when $2 is not null then $2::timestamp else null end
$$ LANGUAGE SQL IMMUTABLE;

--this is old
CREATE or replace FUNCTION ora.nvl(text,integer)
RETURNS text AS $$
SELECT case when nullif($1,'') is not null then $1 when $2 is not null then $2::text else null end
$$ LANGUAGE SQL IMMUTABLE;

--this is new
CREATE or replace FUNCTION ora.nvl(text,integer)
RETURNS integer AS $$
SELECT case when nullif($1,'') is not null then $1::integer when $2 is not null then $2::integer else null end
$$ LANGUAGE SQL IMMUTABLE;

--this is old
CREATE  FUNCTION ora.nvl(text,numeric)
RETURNS text AS $$
SELECT case when nullif($1,'') is not null then $1 when $2 is not null then $2::text else null end
$$ LANGUAGE SQL IMMUTABLE;

--this is new
CREATE  FUNCTION ora.nvl(text,numeric)
RETURNS numeric AS $$
SELECT case when nullif($1,'') is not null then $1::numeric when $2 is not null then $2::numeric else null end
$$ LANGUAGE SQL IMMUTABLE;

CREATE  FUNCTION ora.nvl2(text,text,text)
RETURNS text AS $$
SELECT case when nullif($1,'') is not null then $2 else $3 end
$$ LANGUAGE SQL IMMUTABLE;

-------------------------  END OF SOURCE    ----------------------------
