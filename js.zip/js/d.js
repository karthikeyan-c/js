/*var sleep = require('system-sleep');

async function subdemo(){
   console.log("subdemo inside" + new Date()); 
   return("subdemo return" + new Date());
}

async function demo() {
  return new Promise((resolve, reject) => {
		  console.log('Taking a break...' + new Date());
		  /*
		     let promise = new Promise((resolve, reject) => {
		     setTimeout(() => resolve("done!"), 10000)
		     });

		     let result = await promise.then(console.log); 
		     let promise = new Promise((resolve, reject) => {
		     sleep(5000);
		     resolve("done!" + new Date());
		     });
		     let result = promise.then(console.log); // wait until the promise resolves (*)
		   */
		  //subdemo().then(console.log);
		  //console.log('Two seconds later, showing sleep in a loop...' + new Date());
		  sleep(5000);
   		  resolve("return from async" + new Date());
		  //return("return from async" + new Date());
  });
}
*/

async function demo() {
  	console.log('Taking a break...' + new Date());

	let promise = new Promise((resolve, reject) => {
             setTimeout(() => resolve("done!"), 10000)
        });

       let result = promise.then(console.log);
  	console.log('After Promis...' + new Date());
       return("return from async" + new Date());
}

console.log("before demo" + new Date());
demo().then(console.log);
console.log("after demo" + new Date());
