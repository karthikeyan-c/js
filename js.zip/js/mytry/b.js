import { e1 } from './a.js';

console.log(e1());
