function myfunc(){
	this.name = "myname";
}

var obj = {
	objname: "myobjname"
};

console.log(obj.objname);
myfunc.prototype = obj;
console.log(myfunc);
