export var FN = (function () {

	// STARTFUNCTION deleteTxn
	/**
 	*
 	*
 	* @param {*}
 	* @summary
 	* @example
 	* @returns {string} 
 	*/

	 	
	function deleteTxn(functionInputs) {

		//	DEFAULT FIELDS INITIALIZATION

		let mandFlds;
		functionInputs.errorMsgs = ' ';
		functionInputs.errorFlg = 'N';
        	functionInputs.errorCode = '';
        	let errorMsg;
        	let error; 	

		let bodDate = FUME.getrepValue("BANCS","STDIN","BODDate");
		
		LibCommonB002.setErrorFieldsB(functionInputs);

		//	MANDATORY FIELDS CHECK

		mandFlds = ['tranDate','tranId'];
		if (!LibCommonB002.chkMandatorySRVInputsB(functionInputs, mandFlds)) {
				// LibCommonB002.setErrorFieldsB(functionInputs, true, functionInputs.errorDetails[0].errorCode, 'MSG', functionInputs.errorDetails[0].errorMsg, '');
				return false;
		}
		
		FUME.print('tranDate :- ',functionInputs.tranDate);
		FUME.print('tranId :- ',functionInputs.tranId);

		//      NON-MANDATORY FIELDS CHECK
		mandFlds = ['ignoreXcpnFlg'];
		if (!LibCommonB002.chkNonMandatorySRVInputsB(functionInputs, mandFlds)) {
				// LibCommonB002.setErrorFieldsB(functionInputs, true, functionInputs.errorDetails[0].errorCode, 'MSG', functionInputs.errorDetails[0].errorMsg, '');
				return false;
        	}	


		FUME.print('ignoreXcpnFlg :- ',functionInputs.ignoreXcpnFlg);
		
		if(functionInputs.ignoreXcpnFlg != 'Y'){
				functionInputs.ignoreXcpnFlg = 'N';	
		
        	}
	
		//	Setting up the INPUT for the Fetch service

		let output;
		
		output=FUME.USRHK("setUrhkInp","tranHdr.tranIdentifier.tranDate|"+functionInputs.tranDate.substring(0, 10) + " 00:00:00");
		FUME.print(output);
		output=FUME.USRHK("setUrhkInp","tranHdr.tranIdentifier.tranId|"+functionInputs.tranId.padStart(9,''));
		FUME.print(output);

		//	Executing Fetch service
		

		let execCmd1 = "SRV_FetchTranDtlsForDelete|same_user_verify = Y|retain_all_output = Y|call_mode = E|ignore_xcpn_flg = " + functionInputs.ignoreXcpnFlg ;
		srvOp = FUME.USRHK('ExecSrvNoCommit', execCmd1);
		FUME.print('srvOp :- ',srvOp);

		//	Error handling

		if (srvOp !== 0) {
            
			if (functionInputs.ignoreXcpnFlg === 'Y') {
                		srvOp = FUME.USRHK('CopyOutToIn', '');
                		FUME.print(srvOp);

				//	Executing Fetch service in overriding mode

				let execCmd2 = "SRV_FetchTranDtlsForDelete|same_user_verify = Y|retain_all_output = Y|call_mode = N|ignore_xcpn_flg = " + functionInputs.ignoreXcpnFlg;
                		srvOp = FUME.USRHK('ExecSrv', execCmd2);
                		FUME.print(srvOp);
			}


			if(srvOp !== 0){
				
				functionInputs.errorFlg = 'Y';
            		 	errorMsg = LibCommonB001.handleSrvErrorB('Y', 'Y', 'Y', 'Y');
                		FUME.print(errorMsg);                
                		error = LibCommonB001.replaceCharB(errorMsg,"|","");
                		functionInputs.errorMsgs = error;
				return false;
			}
		
		}

		if (srvOp == 0) {
			srvOp = FUME.USRHK('CopyOutToIn', '');
                	FUME.print(srvOp);
			
			//	Executing Submit Service
			
			let execCmd3 = "SRV_DeleteTran|same_user_verify = Y|retain_all_output = Y|call_mode = E|ignore_xcpn_flg = " + functionInputs.ignoreXcpnFlg ;
			srvOp = FUME.USRHK('ExecSrv', execCmd3);
                	FUME.print(srvOp);
				
			if (srvOp !== 0) {
				
				if (functionInputs.ignoreXcpnFlg === 'Y') {
                       			srvOp = FUME.USRHK('CopyOutToIn', '');
                        		FUME.print(srvOp);
					
					//	Executing Submit Service in overriding mode

					let execCmd4 = "SRV_DeleteTran|same_user_verify = Y|retain_all_output = Y|call_mode = N|ignore_xcpn_flg = " + functionInputs.ignoreXcpnFlg ;
					srvOp = FUME.USRHK('ExecSrv', execCmd4);
					FUME.print(srvOp);			
				}

				if(srvOp !== 0){
					functionInputs.errorFlg = 'Y';
                        		errorMsg = LibCommonB001.handleSrvErrorB('Y', 'Y', 'Y', 'Y');
                        		FUME.print(errorMsg);                
                        		error = LibCommonB001.replaceCharB(errorMsg,"|","");
                        		functionInputs.errorMsgs = error ;
                        		return false;
				}
				else{
					return true;
				}	
			}
		}
		else{
			return true;
		}


		
	}
	// ENDFUNCTION deleteTxn
	
	return {deleteTxn};

})();


FUME.print(FN.deleteTxn('Nikhil'));
