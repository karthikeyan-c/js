import { FUME } from 'FUME.js';
import { mmsg } from 'MMSG.js';
import { LibDateB001 } from 'LibDateB001.js';
import { LibCommonB002 } from 'LibCommonB002.js';

export var LibCommonB001 = (function () {
    var globalBankId = FUME.getrepValue('BANCS', 'STDIN', 'contextBankId');
    function RIGHT$(str, chr) {
        return str.slice(-chr);
    }

    function LEFT$(str, chr) {
        return str.slice(0, chr);
    }

    function MID$(str, start, end) {
        return str.substring(start, end);
    }

    // STARTFUNCTION versionLibCommonB001
    /**
     *
     *@returns {string} version of the library
     */
    function versionLibCommonB001() {
        // javascript-obfuscator:disable
        const version = '20200730123309';
        // javascript-obfuscator:enable
        return version;
    }
    // ENDFUNCTION versionLibCommonB001

    // STARTFUNCTION createRepClassB
    /**
   * @param {string} repName repository name
   * @param {string} className class name
   * @summary	Crreate Repository and Class if doesnt exist
   * @example
   * 		createRepClassB("CUST","DATA");
   *
   */
    function createRepClassB(repName, className) {
        if (FUME.isRepExists(repName) === 0) {
            FUME.createRep(repName);
        }
        if (FUME.isClassExists(repName, className) === 0) {
            FUME.createClass(repName, className);
        }
    }
    // ENDFUNCTION createRepClassB

    // STARTFUNCTION deleteRepClassB
    /**
   * @param {string} repName repository name
   * @param {string} className class name
   * @summary	Delete Repository and Class
   * @example
   * 		deleteRepClassB("CUST","DATA");
   *
   */
    function deleteRepClassB(repName, className) {
        if (FUME.isClassExists(repName, className) === 1) {
            FUME.deleteClass(repName, className);
        }
        if (FUME.isRepExists(repName) === 1) {
            FUME.deleteRep(repName);
        }
    }
    // ENDFUNCTION deleteRepClassB

    // STARTFUNCTION deleteRepB
    /**
   *
   *
   * @param {*} repName Repository name
   * @summary	Delete Repository
   * @example
   * 		deleteRepB("CUST");
   */
    function deleteRepB(repName) {
        if (FUME.isRepExists(repName) === 1) {
            FUME.deleteRep(repName);
        }
    }
    // ENDFUNCTION deleteRepB

    // STARTFUNCTION deleteClassB
    /**
   *
   *
   * @param {*} repName Repository name
   * @param {*} className Class name
   * @summary	Delete Class
   * @example
   * 		deleteClassB("DATA");
   */
    function deleteClassB(repName, className) {
        if (FUME.isClassExists(repName, className) === 1) {
            FUME.deleteClass(repName, className);
        }
    }
    // ENDFUNCTION deleteClassB

    // STARTFUNCTION copyRepositoryVariableB
    /**
   *
   *
   * @param {*} fromRep From Repository
   * @param {*} fromClass From Class
   * @param {*} fromVar From Variable
   * @param {*} toRep To Repository
   * @param {*} toClass To Class
   * @param {*} toVar To Variable
   * @summary	Copy Variable from one repository to other
   * @example
   * 		copyRepositoryVariableB("LIBCOMM","DBSELECT","count","BANCS","OUTPARAM","count")
   */
    function copyRepositoryVariableB(
        fromRep,
        fromClass,
        fromVar,
        toRep,
        toClass,
        toVar
    ) {
        if (FUME.isFieldExists(fromRep, fromClass, fromVar)) {
            FUME.setrepValue(
                toRep,
                toClass,
                toVar,
                FUME.getrepValue(fromRep),
                fromClass,
                fromVar
            );
        } else {
            FUME.setrepValue(toRep, toClass, toVar, ' ');
        }
    }
    // ENDFUNCTION copyRepositoryVariableB

    // STARTFUNCTION getTbaadmSchemaNameB
    /**
   *
   *@summary	gets TBAADM schema name from env variable TBAADM_SCHEMA_NAME
   *@return {string} tbaadmSchema
   */
    function getTbaadmSchemaNameB() {
        let tbaadmSchema = 'TBAADM';
        tbaadmSchema = FUME.getEnv('TBAADM_SCHEMA_NAME');
        if (tbaadmSchema.trim() === '') {
            tbaadmSchema = 'TBAADM';
        }
        return tbaadmSchema;
    }
    // ENDFUNCTION getTbaadmSchemaNameB

    // STARTFUNCTION getCustomSchemaNameB
    /**
   *
   *@summary	gets CUSTOM schema name from env variable CUSTOM_SCHEMA_NAME
   *@return {string} customSchema
   */
    function getCustomSchemaNameB() {
        let customSchema = 'CUSTOM';
        customSchema = FUME.getEnv('CUSTOM_SCHEMA_NAME');
        if (customSchema.trim() === '') {
            customSchema = 'CUSTOM';
        }

        return customSchema;
    }
    // ENDFUNCTION getCustomSchemaNameB
    // STARTFUNCTION setEnvVariableB
    /**
   *
   *
   * @param {*} name env. variable name
   * @param {*} value value to be set
   * @summary sets env variable
   * @example setEnvVariableB("URHK_WITH_BINDVAL_FLG","N");
   */
    function setEnvVariableB(name, value) {
        FUME.USRHK('putEnv', `${name}|${value}`);
    }
    // ENDFUNCTION setEnvVariableB

    // STARTFUNCTION getEnvVariableB
    /**
   *
   *
   * @param {*} envVarName env. variable name
   * @summary gets env variable
   * @example getEnvVariableB("URHK_WITH_BINDVAL_FLG");
   * @returns {string} value of env variable
   */
    function getEnvVariableB(envVarName) {
        let valuePlhr = '';
        const urhkOp = FUME.USRHK('getEnv', envVarName);
        if (urhkOp === 0) {valuePlhr = FUME.getrepValue('BANCS', 'OUTPARAM', 'envValue');}
        return valuePlhr.trim();
    }
    // ENDFUNCTION getEnvVariableB
    // STARTFUNCTION getUniqueFileNameB
    /**
*
*
* @param {*} fileName filename
* @param {*} extn extension
* @summary returns a unique filename by appending timestamp
* @example
* getUniqueFileNameB("samplefile","txt")
* @returns {string} unique file name
*/
    function getUniqueFileNameB(fileName, extn) {
        const timeStamp = LibDateB001.getSysDateTimeWithFormatB(
            'DDMMYYYYHH24MISSFF6'
        );
        let newFileName = `${fileName}_${timeStamp}`;
        if (extn !== '') {
            newFileName = `${newFileName}.${extn}`;
        }
        return newFileName;
    }
    // ENDFUNCTION getUniqueFileNameB

    // STARTFUNCTION copyOutparamFieldB
    /**
*
*
* @param {string} srcFieldId src Field id which needs to be copied from BANCS.OUTPARAM
* @param {*} defaultValue default value to be used, if not passed then blank
* @summary returns value of BANCS.OUTPARAM.srcFieldId present, else returns defaultValue
* @example copyOutparamFieldB("count","")
* @returns {string} returns value of  BANCS.OUTPARAM.srcFieldId present, else returns defaultValue
*/
    function copyOutparamFieldB(srcFieldId,
        defaultValue = ''
    ) {
        let outputVal = defaultValue;
        if (FUME.isFieldExists('BANCS', 'OUTPARAM', srcFieldId)) {
            if (FUME.getrepValue('BANCS', 'OUTPARAM', srcFieldId) !== '') {
                outputVal = FUME.getrepValue('BANCS', 'OUTPARAM', srcFieldId);
            } else {
                outputVal = defaultValue;
            }
        }
        return outputVal;
    }
    // ENDFUNCTION copyOutparamFieldB
    // STARTFUNCTION copyOptionalFieldB
    /**
*
*
* @param {string} srcFieldId src Field id which needs to be copied from BANCS.INPUT
* @param {*} defaultValue default value to be used, if not passed then blank
* @summary returns value of BANCS.INPUT.srcFieldId present, else returns defaultValue
* @example copyOptionalFieldB("count","")
* @returns {string} returns value of BANCS.INPUT.srcFieldId present, else returns defaultValue
*/
    function copyOptionalFieldB(srcFieldId,
        defaultValue = ''
    ) {
        let outputVal = defaultValue;
        if (FUME.isFieldExists('BANCS', 'INPUT', srcFieldId)) {
            if (FUME.getrepValue('BANCS', 'INPUT', srcFieldId) !== '') {
                outputVal = FUME.getrepValue('BANCS', 'INPUT', srcFieldId);
            } else {
                outputVal = defaultValue;
            }
        }
        return outputVal;
    }
    // ENDFUNCTION copyOptionalFieldB
    // STARTFUNCTION getCountOfCharB
    /**
   *
   *
   * @param {*} inpStr input string
   * @param {*} findChr character to be checked
   * @summary find the number of occurances of char in the input string
   * @return {number} count of character in input string
   */
    function getCountOfCharB(inpStr, findChr) {
        const pattern = new RegExp(`\\${findChr}`, 'g');
        const count = (inpStr.match(pattern) || []).length;
        return count;
    }
    // ENDFUNCTION getCountOfCharB

    // STARTFUNCTION getNthFieldFromStringB
    /**
   * @param {string} inpStr input string
   * @param {string} seperator separator
   * @param {string} fieldNo required field no
   * @summary	get Nth field from input string based on separator (starts from 1)
   * @returns {string} nth field
   * @example
   * 		getNthFieldFromStringB("A|B|C|D", "|", "3"); //will return C
   */
    function getNthFieldFromStringB(inpStr, seperator, fieldNo) {
        let outputStr = inpStr;
        const inpStrArr = inpStr.split(seperator);
        if (fieldNo - 1 <= inpStrArr.length) {
            outputStr = inpStrArr[fieldNo - 1];
        }
        return outputStr;
    }
    // ENDFUNCTION getNthFieldFromStringB
    // STARTFUNCTION cmmsgerrdescWithInputsB
    /**
   *
   *
   * @param {*} errcode error code for which description needs to be fecthed
   * @param {*} userId dummy
   * @param {*} inputs if message has %s, pass the input values to replace %s. it can be array or | separated
   * @param {*} languageCode LANG_CODE in case of USE_CUSTOM_CMMSG_VIEW = Y
   * @summary gets message description based on input errorcode from CMMSG, if not check MMSG
   * @returns {string} errdesc
   * @example
   * errormsg = cmmsgerrdescWithInputsB("MSG0357673");
   */
    function cmmsgerrdescWithInputsB(errcode, userId, inputs = [], languageCode = '') {
        let errdesc = cmmsgerrdescB(errcode, userId, languageCode);
        let inputArr = inputs;
        if (typeof (inputs) === 'string') {
            inputArr = inputs.split('|');
        }
        if (Array.isArray(inputArr) && (inputArr.length)) {
            for (let i = 0; i < inputArr.length; i += 1) {
                errdesc = errdesc.replace('%s', inputArr[i]);
            }
        }
        return errdesc;
    }
    // ENDFUNCTION cmmsgerrdescWithInputsB
    // STARTFUNCTION mmsgErrDescWithInputsB
    /**
   *
   *
   * @param {*} errcode error code for which description needs to be fecthed
   * @param {*} userId dummy
   * @param {*} inputs if message has %s, pass the input values to replace %s. it can be array or | separated
   * @summary gets message description based on input errorcode from CMMSG, if not check MMSG
   * @returns {string} errdesc
   * @example
   * errormsg = mmsgErrDescWithInputsB("MSG0357673");
   */
    function mmsgErrDescWithInputsB(errcode, userId, inputs = []) {
        let errdesc = mmsgErrDescB(errcode, userId);
        let inputArr = inputs;
        if (typeof (inputs) === 'string') {
            inputArr = inputs.split('|');
        }
        if (Array.isArray(inputArr) && (inputArr.length)) {
            for (let i = 0; i < inputArr.length; i += 1) {
                errdesc = errdesc.replace('%s', inputArr[i]);
            }
        }
        return errdesc;
    }
    // ENDFUNCTION mmsgErrDescWithInputsB
    // STARTFUNCTION cmmsgerrdescB
    /**
   *
   *
   * @param {*} errcode error code for which description needs to be fecthed
   * @param {*} userId dummy value
   * @param {*} languageCode LANG_CODE in case of USE_CUSTOM_CMMSG_VIEW = Y
   * @summary gets message description based on input errorcode from CMMSG, if not check MMSG
   * @returns {string} errdesc
   * @example
   * errormsg = cmmsgerrdescB("MSG0357673");
   */
    function cmmsgerrdescB(errcode, userId = '', languageCode = '') {
        let errdesc = '';
        const msgObj = mmsg.mmsgCodes();
        const valueObj = msgObj.filter(m => m.code === errcode);
        if (valueObj.length) {
            errdesc =  valueObj[0].desc;
        } else {
            let multiLingualFlg;
            let langCode = languageCode || FUME.getrepValue('BANCS', 'STDIN', 'languageCode');
            let mObj = {};
            mObj.outputFields = 'errdesc';
            mObj.columnNames = 'MSG_LITERAL';
            mObj.tableName = 'C_MMSG';
            mObj.whereFields = ['MSG_ID', 'DEL_FLG'];
            mObj.whereValues = [errcode, 'N'];
            const customCMMSGFlg = getEnvVariableB('USE_CUSTOM_CMMSG_VIEW');
            FUME.print(customCMMSGFlg);
            if (customCMMSGFlg === 'Y') {
                mObj.columnNames = 'MSG_LITERAL';
                mObj.tableName = 'CUSTOM_CMMSG_VIEW';
                mObj.whereFields = ['MSG_ID', 'DEL_FLG', 'COALESCE(LANG_CODE,\'INFENG\')'];
                mObj.whereValues = [errcode, 'N', langCode];
                FUME.print('CMMSG FETCH FROM VIEW');
            } else {
                FUME.print('CMMSG FETCH FROM TABLE');
                multiLingualFlg = '';
                getEnvVariableB('CMMSG_MULTI_LINGUAL_FLG', multiLingualFlg);
                FUME.print(multiLingualFlg);
                if (multiLingualFlg === 'Y') {
                    mObj.columnNames = 'MSG_LITERAL';
                    mObj.tableName = 'CUSTOM_CMMSG_VIEW';
                    mObj.whereFields = ['MSG_ID', 'DEL_FLG', 'COALESCE(LANG_CODE,\'INFENG\')'];
                    mObj.whereValues = [errcode, 'N', langCode];
                }
            }
            if (selectFromTableB(mObj)) {
                errdesc = mObj.errdesc;
            } else {
                errdesc = mmsgErrDescB(errcode, userId);
            }
        }
        return errdesc;
    }
    // ENDFUNCTION cmmsgerrdescB
    // STARTFUNCTION cmmsgerrdescB
    /**
   *
   *
   * @param {*} errcode error code for which description needs to be fecthed
   * @param {*} userId dummy
   * @summary gets message description based on input errorcode from MMSG
   * @returns {string} errdesc
   * @example
   * errormsg = mmsgerrdescB("MSG0357673");
   */
    function mmsgErrDescB(errcode, userId = '') {
        let errdesc = '';
        const msgObj = mmsg.mmsgCodes(errcode);
        const valueObj = msgObj.filter(m => m.code === errcode);
        if (valueObj.length) {
            errdesc = valueObj[0].desc;
        } else {
            let mObj = {};
            mObj.outputFields = 'errdesc';
            mObj.columnNames = 'MSG_LITERAL';
            mObj.tableName = 'MMSG';
            mObj.whereFields = ['MSG_ID', 'DEL_FLG'];
            mObj.whereValues = [errcode, 'N'];
            let languageCode = FUME.getrepValue('BANCS', 'STDIN', 'languageCode');
            if (languageCode !== 'INFENG') {
                mObj.columnNames = 'TRANSLATED_MSG_LITERAL';
                mObj.tableName = 'TMSG';
                mObj.whereFields = ['MSG_ID', 'DEL_FLG', 'LANG_CODE'];
                mObj.whereValues = [errcode, 'N', languageCode];
            }
            if (selectFromTableB(mObj)) {
                errdesc = mObj.errdesc;
            }
        }
        return errdesc;
    }
    // ENDFUNCTION mmsgerrdescB

    // STARTFUNCTION setErrorFieldsB
    /**
   *
   *
   * @param {object} dataObj data object
   * @param {boolean} errorFlg whether error to be set or not
   * @param {string} errorCode error code
   * @param {string} errorMMMSGCode error mmsg code
   * @param {string} errorMsg error description
   * @param {string} errorMMMSGCodeBindVar if msg has %s, value for it
   * @returns {boolean} true
   * @summary creates errorDetails object inside dataObj
   * dataObj.errorDetails = [
   * {
   * 	"errorCode" : "XXXXXX",
   *  "errorMsg" : "Error Message Literal",
   * }
   * ]
   */
    function setErrorFieldsB(
        dataObj,
        errorFlg = false,
        errorCode = '',
        errorMMMSGCode = '',
        errorMsg = '',
        errorMMMSGCodeBindVar = ''
    ) {
    // check if data object already has errorDetails attribute, if not create empty array
        if (!dataObj.errorDetails) {
            dataObj.errorDetails = [];
        }
        // if errorFlg is true, then push errorCode and Msg into errorDetails
        if (errorFlg) {
            const errorObj = {};
            let errormsg = errorMsg;
            errorObj.errorCode = errorCode;
            // if errorMsg already present use it
            if (errorMMMSGCode !== '') {
                // get description by calling MMSG function
                errormsg = cmmsgerrdescB(errorMMMSGCode);
            }
            // if message has %s then replace it with values in errorMMMSGCodeBindVar
            let errorMMMSGCodeBindVarArr = [];
            if (typeof (errorMMMSGCodeBindVar) === 'string') {
                errorMMMSGCodeBindVarArr = errorMMMSGCodeBindVar.split('|');
            }
            if (errorMMMSGCodeBindVarArr.length) {
                for (let i = 0; i < errorMMMSGCodeBindVarArr.length; i += 1) {
                    errormsg = errormsg.replace('%s', errorMMMSGCodeBindVarArr[i]);
                }
            }
            // set errorMsg
            errorObj.errorMsg = errormsg;
            // push errorObj
            dataObj.errorDetails.push(errorObj);
        }
        return true;
    }
    // ENDFUNCTION setErrorFieldsB
    // STARTFUNCTION replaceStrB
    /**
   *
   *
   * @param {*} inpStr input string
   * @param {*} toBeRepl character/string to be replaced
   * @param {*} replacedWith charcter/string to be replaced with
   * @param {*} reFlag regular expression flag g-global, i-case insensitive etc.
   * @summary takes input string and replaces charToBeRepl with replcmntChar.
   * Replacement is done globally i.e. all occurances by default if reFlag is not passed
   * @example replaceStrB("ABCD","A","X");
   * @returns {string} replaced string
   */
    function replaceStrB(inpStr, toBeRepl, replacedWith, reFlag = 'g') {
    // const escapedInpStr = inpStr.replace(/[.*+\-?^${}()|[\]\\]/g, '\\$&');
        const replacedStr = inpStr.replace(
            new RegExp(toBeRepl, reFlag),
            replacedWith
        );
        return replacedStr;
    }
    // ENDFUNCTION replaceStrB
    // STARTFUNCTION getFullPathB
    /**
   *
   *
   * @param {*} fileName filename
   * @summary takes filename as input and returns  file path using getFileLocation userhook
   * @example getFullPathB("replaceInFile.com")
   * @returns {string}  file path using getFileLocation userhook
   */
    function getFullPathB(fileName) {
        let filePath;
        let fileType;
        fileType = fileName
            .substring(fileName.indexOf('.') + 1, fileName.length)
            .toUpperCase();
        if (fileType === 'SCR') {
            fileType = 'SCRIPT';
        }
        const urhkOp = FUME.USRHK('getFileLocation', `${fileType}|${fileName}`);
        if (urhkOp === 0) {
            filePath = FUME.getrepValue('BANCS', 'OUTPARAM', 'fileLocation');
        }
        FUME.print(filePath);
        return filePath;
    }
    // ENDFUNCTION getFullPathB
    // STARTFUNCTION setOrbOutWithDefValueB
    /**
     *
     *
     * @param {*} multiRecNum UI field num in case of multirec
     * @param {*} functionObj dataObj
     * @param {*} inputfield field from which value neeeds to be set
     * @param {*} outputfield UI field id where value needs to be set
     * @param {*} defaultvalue default value to be used
     * @summary sets the value to frontend using setOrbOut user hook
     * @example setOrbOutWithDefValueB("",dataObj,"acctName","acctName","")
     * @returns {boolean} true
     */
    function setOrbOutWithDefValueB(multiRecNum, functionObj, inputfield, outputfield, defaultvalue) {
        let fieldNo;
        if (multiRecNum !== '')   fieldNo = parseInt(multiRecNum);
        const value = functionObj[inputfield] || defaultvalue;
        let urhkOp = FUME.USRHK('setOrbOut', outputfield + fieldNo + '|' + value);
        urhkOp = urhkOp === 0;
        return urhkOp;
    }
    // ENDFUNCTION setOrbOutWithDefValueB
    // STARTFUNCTION setOrbOutWithDefValueB
    /**
     *
     *
     * @param {*} multiRecNum UI field num in case of multirec
     * @param {*} functionObj dataObj
     * @param {*} inputfields , separated fields from which value neeeds to be set
     * @param {*} outputfields , separated UI fields id where value needs to be set
     * @param {*} defaultvalue default value to be used
     * @summary sets the value to frontend using setOrbOut user hook
     * @example setOrbOutWithDefValueNFieldsB("",dataObj,"acctName,acctBal","acctName,acctBal","")
     * @returns {boolean} true
     */
    function setOrbOutWithDefValueNFieldsB(multiRecNum, functionObj, inputfields, outputfields, defaultvalue) {
        const inputfieldsArr = inputfields.split(',');
        const outputfieldsArr = outputfields.split(',');
        let urhkOp = true;
        for (let i = 0; i < inputfieldsArr.length; i += 1) {
            urhkOp = setOrbOutWithDefValueB(multiRecNum, functionObj, inputfieldsArr[i], outputfieldsArr[i], defaultvalue);
        }
        return urhkOp;
    }
    // ENDFUNCTION setOrbOutWithDefValueNFieldsB
    // STARTFUNCTION convertAmountB
    /**
  *
  *
  * @param {*} dataObj object
  * @param {*} dataObj.inputAmount input amount
  * @param {*} dataObj.fromCurrency from currency
  * @param {*} dataObj.toCurrency to currency
  * @param {*} dataObj.rateCode rate code to be used
  * @param {*} dataObj.rate rate to be used
  * @returns {boolean} output will be in <input object>.convertedAmt
  */
    function convertAmountB(dataObj) {
        FUME.print('Begin Function convertAmountB');
        let convertedAmt = 0;
        const mandFlds = ['inputAmount', 'fromCurrency', 'toCurrency', 'rateCode', 'rate'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dataObj, mandFlds)) {
            return false;
        }
        FUME.setrepValue('BANCS', 'INPARAM', 'InputAmount', dataObj.inputAmount);
        FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'InputAmount'));
        FUME.setrepValue('BANCS', 'INPARAM', 'FromCurrency', dataObj.fromCurrency);
        FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'FromCurrency'));
        FUME.setrepValue('BANCS', 'INPARAM', 'ToCurrency', dataObj.toCurrency);
        FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'ToCurrency'));
        FUME.setrepValue('BANCS', 'INPARAM', 'RateCode', dataObj.rateCode);
        FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'RateCode'));
        FUME.setrepValue('BANCS', 'INPARAM', 'Rate', dataObj.rate);
        FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'Rate'));
        let urhkOp = FUME.USRHK('B2k_ConvertAmount', '');
        if (urhkOp === 0)  {
            convertedAmt = FUME.getrepValue('BANCS', 'OUTPARAM', 'OutputAmount');
        }
        dataObj.convertedAmt = convertedAmt;
        urhkOp = urhkOp === 0;
        FUME.print('End Function convertAmountB');
        return urhkOp;
    }
    // ENDFUNCTION convertAmountB

    // STARTFUNCTION handleSrvErrorB
    /**
     *
     *
     * @param {*} errNumFlg Y/N to indicate if error to be checked
     * @param {*} xcpnNumFlg Y/N to indicate if exception to be checked
     * @param {*} wrngNumFlg Y/N to indicate if warning to be checked
     * @param {*} usrInfFlg Y/N to indicate if userInfo to be checked
     * @returns {Array} error message array
     * @example handleSrvErrorB("Y","Y","Y","Y")
     */
    function handleSrvErrorB(errNumFlg, xcpnNumFlg, wrngNumFlg, usrInfFlg) {
        let errStr;
        let errMsgStr;
        let errMsgArr = [];
        let errObjArr = [];
        let d = 0;
        let code;
        let message;
        let tag;
        if (errNumFlg === 'Y')  {
            if (FUME.isFieldExists('BANCS', 'OUTPARAM', 'Error_num') !== 0)  {
                if (parseInt(FUME.getrepValue('BANCS', 'OUTPARAM', 'Error_num')) > 0)  {
                    while (d <= parseInt(FUME.getrepValue('BANCS', 'OUTPARAM', 'Error_num'))) {
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('ErrorCode_' + d.toString()))) {
                            code = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('ErrorCode_' + d.toString()));
                        }
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('ErrorMesg_' + d.toString()))) {
                            message = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('ErrorMesg_' + d.toString()));
                        }
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('Tag_' + d.toString()))) {
                            tag = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('Tag_' + d.toString()));
                        }
                        d = d + 1;
                        errStr = errStr + '|' + code + '|' + message + '|' + tag;
                        errMsgStr = errMsgStr + '|' + message;
                        errMsgArr.push(message);
                        errObjArr.push({'code': code, 'message': message, 'tag': tag});
                        FUME.print('ERROR : ' + code + '|' + message + '|' + tag);
                    }
                }
            }
        }
        d = 0;
        if (xcpnNumFlg === 'Y')  {
            if (FUME.isFieldExists('BANCS', 'OUTPARAM', 'Xcpn_num') !== 0)  {
                if (parseInt(FUME.getrepValue('BANCS', 'OUTPARAM', 'Xcpn_num')) > 0)  {
                    while (d <= parseInt(FUME.getrepValue('BANCS', 'OUTPARAM', 'Xcpn_num'))) {
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('XcpnCode_' + d.toString()))) {
                            code = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('XcpnCode_' + d.toString()));
                        }
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('XcpnDesc_' + d.toString()))) {
                            message = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('XcpnDesc_' + d.toString()));
                        }
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('Tag_' + d.toString()))) {
                            tag = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('Tag_' + d.toString()));
                        }
                        d = d + 1;
                        errStr = errStr + '|' + code + '|' + message + '|' + tag;
                        errMsgStr = errMsgStr + '|' + message;
                        errMsgArr.push(message);
                        errObjArr.push({'code': code, 'message': message, 'tag': tag});
                        FUME.print('EXCEPTION : ' + code + '|' + message + '|' + tag);
                    }
                }
            }
        }
        d = 0;
        if (wrngNumFlg === 'Y')  {
            if (FUME.isFieldExists('BANCS', 'OUTPARAM', 'Warning_num') !== 0)  {
                if (parseInt(FUME.getrepValue('BANCS', 'OUTPARAM', 'Warning_num')) > 0)  {
                    while (d <= parseInt(FUME.getrepValue('BANCS', 'OUTPARAM', 'Warning_num'))) {
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('WarningCode_' + d.toString()))) {
                            code = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('WarningCode_' + d.toString()));
                        }
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('WarningMesg_' + d.toString()))) {
                            message = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('WarningMesg_' + d.toString()));
                        }
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('Tag_' + d.toString()))) {
                            tag = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('Tag_' + d.toString()));
                        }
                        d = d + 1;
                        errStr = errStr + '|' + code + '|' + message + '|' + tag;
                        errMsgStr = errMsgStr + '|' + message;
                        errMsgArr.push(message);
                        errObjArr.push({'code': code, 'message': message, 'tag': tag});
                        FUME.print('WARNING : ' + code + '|' + message + '|' + tag);
                    }
                }
            }
        }
        d = 0;
        if (usrInfFlg === 'Y')  {
            if (FUME.isFieldExists('BANCS', 'OUTPARAM', 'UserInfo_num') !== 0)  {
                if (parseInt(FUME.getrepValue('BANCS', 'OUTPARAM', 'UserInfo_num')) > 0)  {
                    while (d <= parseInt(FUME.getrepValue('BANCS', 'OUTPARAM', 'UserInfo_num'))) {
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('UserInfoCode_' + d.toString()))) {
                            code = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('UserInfoCode_' + d.toString()));
                        }
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('UserInfoMesg_' + d.toString()))) {
                            message = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('UserInfoMesg_' + d.toString()));
                        }
                        if (FUME.isFieldExists(('BANCS'), ('OUTPARAM'), ('Tag_' + d.toString()))) {
                            tag = FUME.getrepValue(('BANCS'), ('OUTPARAM'), ('Tag_' + d.toString()));
                        }
                        d = d + 1;
                        errStr = errStr + '|' + code + '|' + message + '|' + tag;
                        errMsgStr = errMsgStr + '|' + message;
                        errMsgArr.push(message);
                        errObjArr.push({'code': code, 'message': message, 'tag': tag});
                        FUME.print('USER INFO : ' + code + '|' + message + '|' + tag);
                    }
                }
            }
        }
        return errMsgArr;
    }
    // ENDFUNCTION handleSrvErrorB
    // STARTFUNCTION addDataToFileB
    /**
     *
     *
     * @param {*} fileName filename where data has to be wrritten
     * @param {*} fileInput data to be written , if fileInput is array then write it in loop
     * @summary write fileInput to fileName using urtn
     * @returns {boolean} true/false based on file operation
     */
    function addDataToFileB(fileName, fileInput) {
        let fileIndex;
        let urtnOp = FUME.URTN('fileAccess', fileName);
        FUME.print(urtnOp);
        if (urtnOp === 1)  {
            fileIndex = FUME.URTN('fileOpen', fileName + '|w');
            FUME.print(fileIndex);
            if (Array.isArray(fileInput)) {
                const dataArray = fileInput;
                dataArray.forEach(function (d) {
                    urtnOp = FUME.URTN('fileWrite', fileIndex + '|' + d);
                });
            } else {
                urtnOp = FUME.URTN('fileWrite', fileIndex + '|' + fileInput);
            }
            FUME.print(urtnOp);
        } else {
            fileIndex = FUME.URTN('fileOpen', fileName + '|a');
            FUME.print(fileIndex);
            if (Array.isArray(fileInput)) {
                const dataArray = fileInput;
                dataArray.forEach(function (d) {
                    urtnOp = FUME.URTN('fileWrite', fileIndex + '|' + d);
                });
            } else {
                urtnOp = FUME.URTN('fileWrite', fileIndex + '|' + fileInput);
            }
            FUME.print(urtnOp);
        }
        urtnOp = FUME.URTN('fileClose', fileIndex);
        FUME.print(urtnOp);
        return fileIndex;
    }
    // ENDFUNCTION addDataToFileB

    // STARTFUNCTION addDataToFileWithNoSplCharB
    /**
     *
     *
     * @param {*} fileName filename where data has to be wrritten
     * @param {*} fileInput data to be written, if fileInput is array then write it in loop
     * @summary write fileInput to fileName using unix echo command
     * @returns {boolean} true/false based on file operation
     */
    function addDataToFileWithNoSplCharB(fileName, fileInput) {
        let urhkOp;
        if (Array.isArray(fileInput)) {
            const dataArray = Array.from(fileInput);
            dataArray.forEach(function (d) {
                const cmd = `echo '${d}' >> ${fileName}`;
                urhkOp = FUME.system(cmd);
            });
        } else {
            const cmd = `echo '${fileInput}' >> ${fileName}`;
            urhkOp = FUME.system(cmd);
        }
        urhkOp = urhkOp === 0;
        return urhkOp;
    }
    // ENDFUNCTION addDataToFileWithNoSplCharB
    // STARTFUNCTION pushReportToHPRB
    /**
     *
     *
     * @param {*} fileName file name to be pushed to PQT
     * @param {*} repName reporting to
     * @returns {boolean} true
     */
    function pushReportToHPRB(fileName, repName) {
        const str = `${fileName}|${repName}|` + FUME.getrepValue('BANCS', 'STDIN', 'userId') + '|1';
        let urhkOp = FUME.USRHK('B2k_Insert_PQT', str);
        urhkOp = urhkOp === 0;
        return urhkOp;
    }
    // ENDFUNCTION pushReportToHPRB
    // STARTFUNCTION execDbSelect
    /**
     *
     * @description not being used. commenting the code
     * @param {*} query query to be executed
     * @param {*} bindValue bind variables for the query
     * @returns {boolean} true/false

    function execDbSelect(query, bindValue) {
        let qry;
        let retVal = false;
        qry = query;
        FUME.print('Begin Function execDbSelect');
        if (Array.isArray(bindValue)) {
            bindValue = bindValue.join('|');
        }
        FUME.setrepValue('BANCS', 'INPARAM', 'BINDVARS', bindValue);
        FUME.print('[QUERY STRING]');
        FUME.print(qry);
        FUME.print('[BIND VALUES]');
        FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS'));
        if (FUME.isFieldExists('BANCS', 'INPARAM', 'dbLongField')) {
            if (FUME.getrepValue('BANCS', 'INPARAM', 'dbLongField') === 'Y') {
                FUME.print('[DBSELECTLONG]');
                retVal = executeDbSelectLongQuery(qry, bindValue);
            } else {
                FUME.print('[DBSELECT]');
                retVal = executeDbSelectQuery(qry, bindValue);
            }
        } else {
            FUME.print('[DBSELECT]');
            retVal = executeDbSelectQuery(qry, bindValue);
        }

        (retVal) ? FUME.print('[SUCCESS]') : FUME.print('[NO RECORDS FOUND]');
        resetDbVariables();
        FUME.print('End Function execDbSelect');
        return retVal;
    }
    */
    // ENDFUNCTION execDbSelect
    // STARTFUNCTION getCifIdB
    /**
     *
     *
     * @param {*} foracid account number
     * @param {*} bankId bank id
     * @returns {string} cif_id from GAM table for the account
     */
    function getCifIdB(foracid, bankId ) {
        let cifId = '';
        let dObj = {};
        dObj.outputFields = 'cifId';
        dObj.columnNames = 'CIF_ID';
        dObj.tableName = 'GAM';
        dObj.whereFields = ['FORACID', 'BANK_ID', 'ENTITY_CRE_FLG', 'DEL_FLG'];
        dObj.whereValues = [foracid, bankId, 'Y', 'N'];
        const retVal = selectFromTableB(dObj);
        if (retVal) {
            cifId = dObj.cifId;
        }
        return cifId;
    }
    // ENDFUNCTION getCifIdB
    // STARTFUNCTION refCodeDescB
    /**
     *
     *
     * @param {*} refCode reference code
     * @param {*} bankId bank id
     * @param {*} recRecType reference code type
     * @returns {string} reference code description from RCT table for the reference code
     */
    function refCodeDescB(refCode, bankId, recRecType) {
        let refDesc = '';
        let dObj = {};
        dObj.outputFields = 'refDesc';
        dObj.columnNames = 'REF_DESC';
        dObj.tableName = 'RCT';
        dObj.whereFields = ['REF_CODE', 'BANK_ID', 'REF_REF_TYPE', 'DEL_FLG'];
        dObj.whereValues = [refCode, bankId, recRecType, 'N'];
        const retVal = selectFromTableB(dObj);
        if (retVal) {
            refDesc = dObj.refDesc;
        }
        return refDesc;
    }
    // ENDFUNCTION refCodeDescB
    // STARTFUNCTION genReportAndPushToHPRB
    /**
     *
     *
     * @param {object} reportObj object with required details
     * @returns {boolean} true
     */
    function genReportAndPushToHPRB(reportObj) {
        let retVal = false;
        let mandFlds = ['fileName', 'lstFileName', 'repName', 'dispName', 'reportFrmt'];
        if (!LibCommonB002.chkMandatorySRVInputsB(reportObj, mandFlds)) {
            return retVal;
        }
        let rName = reportObj.lstFileName;
        let rptInp = reportObj.fileName + '|' + reportObj.lstFileName + '|' + reportObj.repName;
        let urhkOp = FUME.USRHK('B2k_GenRpt4004', rptInp);
        if (urhkOp) {
            rName = reportObj.repName + '.' + reportObj.reportFrmt;
        }
        retVal = pushReportToHPRB(rName, reportObj.dispName);
        return retVal;
    }
    // ENDFUNCTION genReportAndPushToHPRB
    // STARTFUNCTION genReportAndPushToHPRB
    /**
     *
     *
     * @param {object} reportObj object with required details
     * @returns {boolean} true
     */
    function generateReportB(reportObj) {
        let retVal = false;
        let mandFlds = ['fileName', 'lstFileName', 'repName', 'reposName', 'finrptParam'];
        if (!LibCommonB002.chkMandatorySRVInputsB(reportObj, mandFlds)) {
            return retVal;
        }
        let rptInp = reportObj.fileName + '|' + reportObj.lstFileName + '|' + reportObj.repName + '|' + reportObj.reposName + '|' + reportObj.finrptParam;
        let urhkOp = FUME.USRHK('B2k_GenRpt4004', rptInp);
        retVal = urhkOp === 0;
        return retVal;
    }
    // ENDFUNCTION generateReportB
    // STARTFUNCTION generateAndPushReportToHPRB
    /**
     *
     *
     * @param {object} reportObj object with required details
     * @returns {boolean} true
     */
    function generateAndPushReportToHPRB(reportObj) {
        FUME.print('Begin Function generateAndPushReportToHPRB');
        let retVal = false;
        let mandFlds = ['mrtOrJasperName', 'lstFileName', 'rptFileName', 'reposName', 'finRptProperties', 'rptName', 'ifRptErrPushLstFlg'];
        if (!LibCommonB002.chkMandatorySRVInputsB(reportObj, mandFlds)) {
            return retVal;
        }
        let rName = reportObj.rptFileName;
        let rptExtn = '.rpt';
        let rptWithoutExtn = reportObj.rptFileName.split('.')[0];
        if ((reportObj.rptFileName.split('.').length) > 1) {
            rptExtn = reportObj.rptFileName.split('.')[1];
        }
        let rptObj = {};
        rptObj.fileName = reportObj.mrtOrJasperName;
        rptObj.lstFileName = reportObj.lstFileName;
        rptObj.repName = rptWithoutExtn;
        rptObj.reposName = reportObj.reposName;
        rptObj.finrptParam = reportObj.finRptProperties;
        retVal = generateReportB(rptObj);
        if (!retVal) {
            FUME.print('generateReportB failed');
            FUME.print('reportObj.ifRptErrPushLstFlg is :' + reportObj.ifRptErrPushLstFlg);
            if (!reportObj.ifRptErrPushLstFlg) {return retVal;}
            rName = reportObj.lstFileName;
        } else {
            rName = rptWithoutExtn + rptExtn;
        }
        retVal = pushReportToHPRB(rName, reportObj.rptName);
        FUME.print('End Function generateAndPushReportToHPRB');
        return retVal;
    }
    // ENDFUNCTION generateAndPushReportToHPRB
    // STARTFUNCTION checkRecordCntB
    /**
     *
     *
     * @param {*} dbObj data object
     * @param {string} dbObj.tableName table name where count has to be performed
     * @param {Array} dbObj.whereFields key fields of the table
     * @param {Array} dbObj.whereValues key values for the table
     * @returns {boolean} db sql return value true/false. output will in <input object>.count
     */
    function checkRecordCntB(dbObj) {
        FUME.print('Begin Function checkRecordCntB');
        let retVal = false;
        let mandFlds = ['tableName', 'whereFields', 'whereValues'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dbObj, mandFlds)) {
            return retVal;
        }

        let cntObj = {};
        cntObj.count = 0;
        cntObj.outputFields = 'count';
        cntObj.columnNames = 'COUNT(1)';
        cntObj.tableName = dbObj.tableName;
        cntObj.whereFields = dbObj.whereFields;
        cntObj.whereValues = dbObj.whereValues;
        cntObj.whereClauseOperator = dbObj.whereClauseOperator || [];
        cntObj.whereFieldsColumnDataType = dbObj.whereFieldsColumnDataType || [];
        cntObj.whereFieldsColumnFormat = dbObj.whereFieldsColumnFormat || [];
        retVal = selectFromTableB(cntObj);
        if (retVal) {
            dbObj.count = cntObj.count;
        }
        FUME.print('End Function checkRecordCntB');
        return retVal;
    }
    // ENDFUNCTION checkRecordCntB
    // STARTFUNCTION getRateDetailsB
    /**
     *
     *
     * @param {*} rateObj object with required details
     * @param {*} rateObj.fromCcy from currency
     * @param {*} rateObj.toCcy to currency
     * @param {*} rateObj.rateCode rate code to be used
     * @returns {boolean} return value of SRV_TieredConvCrncy SRV
     * output will be in <input object>.rate <input object>.treaRate
     */
    function getRateDetailsB(rateObj) {
        let retVal = false;
        let errMsgArr = [];
        let mandFlds = ['fromCcy', 'toCcy', 'rateCode'];
        if (!LibCommonB002.chkMandatorySRVInputsB(rateObj, mandFlds)) {
            return retVal;
        }
        FUME.USRHK('SetUrhkInp', 'fromCrncy.crncyCode|' + rateObj.fromCcy);
        FUME.USRHK('SetUrhkInp', 'toCrncy.crncyCode|' + rateObj.toCcy);
        FUME.USRHK('SetUrhkInp', 'rateCode.refCode|' + rateObj.rateCode);
        FUME.USRHK('SetUrhkOut', 'rate|rate');
        FUME.USRHK('SetUrhkOut', 'treaRate|treaRate');

        let urhkOp = FUME.USRHK('ExecSrvNoCommit', 'SRV_TieredConvCrncy|retain_all_output = Y');
        if (!urhkOp) {
            errMsgArr = handleSrvErrorB('Y', 'Y', 'Y', 'Y');
            rateObj.errorMsg = errMsgArr;
        }
        rateObj.rate = FUME.getrepValue('BANCS', 'OUTPARAM', 'rate');
        rateObj.treaRate = FUME.getrepValue('BANCS', 'OUTPARAM', 'treaRate');
        return retVal;
    }
    // ENDFUNCTION getRateDetailsB
    // STARTFUNCTION getBankBranchCodeB
    /**
     *
     *
     * @param {*} solId sol id
     * @param {*} bankId bank id
     * @returns {object} bankObj.bankCode and bankObj.branchCode
     */
    function getBankBranchCodeB(solId, bankId) {
        let bankObj = {};
        let dObj = {};
        dObj.outputFields = ['bankCode', 'branchCode'];
        dObj.columnNames = ['BR_CODE', 'BANK_CODE'];
        dObj.tableName = 'SOL';
        dObj.whereFields = ['SOL_ID', 'BANK_ID', 'ENTITY_CRE_FLG', 'DEL_FLG'];
        dObj.whereValues = [solId, bankId, 'Y', 'N'];
        const retVal = selectFromTableB(dObj);
        if (retVal) {
            bankObj.bankCode = dObj.bankCode;
            bankObj.branchCode = dObj.branchCode;
        }
        return bankObj;
    }
    // ENDFUNCTION getBankBranchCodeB
    // STARTFUNCTION getBranchDetailsB
    /**
     *
     *
     * @param {*} bankObj object with input and output details
     * @param {*} bankObj.brCode branch code
     * @param {*} bankObj.bankCode bank code
     * @param {*} bankObj.bankId bank id
     * @summary bankObj.branchName,bankObj.add1,bankObj.add3,bankObj.cityCode,bankObj.stateCode,bankObj.countryCode,bankObj.pinCode,bankObj.BIC will have outputs
     * @returns {boolean} true if valid bank-branch else false
     */
    function getBranchDetailsB(bankObj) {
        FUME.print('Begin Function getBranchDetailsB');
        let retVal = false;
        let mandFlds = ['brCode', 'bankCode', 'bankId'];
        if (!LibCommonB002.chkMandatorySRVInputsB(bankObj, mandFlds)) {
            return retVal;
        }
        let dbObj = {};
        dbObj.count = 0;
        dbObj.outputFields = ['BR_NAME', 'BR_ADDR_1', 'BR_ADDR_2', 'BR_ADDR_3', 'BR_CITY_CODE', 'BR_STATE_CODE', 'CNTRY_CODE', 'BR_PIN_CODE', 'BIC'];
        dbObj.columnNames =  ['BR_NAME', 'BR_ADDR_1', 'BR_ADDR_2', 'BR_ADDR_3', 'BR_CITY_CODE', 'BR_STATE_CODE', 'CNTRY_CODE', 'BR_PIN_CODE', 'BIC'];
        dbObj.tableName = bankObj.tableName;
        dbObj.whereFields = ['BR_CODE', 'BANK_CODE', 'BANK_ID', 'DEL_FLG'];
        dbObj.whereValues = [bankObj.brCode, bankObj.bankCode, bankObj.bankId, 'N'];
        retVal = selectFromTableB(dbObj);
        if (retVal) {
            bankObj.branchName = dbObj.BR_NAME;
            bankObj.add1 = dbObj.BR_ADDR_1;
            bankObj.add2 = dbObj.BR_ADDR_2;
            bankObj.add3 = dbObj.BR_ADDR_3;
            bankObj.cityCode = dbObj.BR_CITY_CODE;
            bankObj.stateCode = dbObj.BR_STATE_CODE;
            bankObj.countryCode = dbObj.CNTRY_CODE;
            bankObj.pinCode = dbObj.BR_PIN_CODE;
            bankObj.BIC = dbObj.BIC;
        }
        FUME.print('End Function getBranchDetailsB');
        return retVal;
    }
    // ENDFUNCTION getBranchDetailsB
    // STARTFUNCTION makerCheckerValidationsB
    /**
     *
     *
     * @param {object} dataObj object
     * @returns {boolean} true/false
     * @summary
     * FUNCTION MODES FOR MODIFY MODE
	 * -----------------------------------------------------------------------------------------------------------------
	 * ONLY_SAME_USER_MODIFY	: RECORD MODIFICATION IS ALLOWED BEFORE VERIFICATION (ALLOWED ONLY FOR SAME USER)
	 * ONLY_DIFF_USER_MODIFY	: RECORD MODIFICATION IS ALLOWED BEFORE VERIFICATION (ALLOWED ONLY FOR DIFFERENT USER)
	 * ALL_USER_MODIFY		: RECORD MODIFICATION IS ALLOWED BEFORE VERIFICATION (ALLOWED FOR ALL USERS)
	 * NOT_ALLOWED			: RECORD MODIFICATION NOT ALLOWED AT ALL
	 * NOT_ALLOWED_BEFORE_VERIFY: RECORD MODIFICATION NOT ALLOWED BEFORE VERIFICATION
	 *
	 * FUNCTION MODES FOR CANCEL MODE
	 * -----------------------------------------------------------------------------------------------------------------
	 * ONLY_SAME_USER_CANCEL	: RECORD CANCELLATION IS ALLOWED BEFORE VERIFICATION (ALLOWED ONLY FOR SAME USER)
	 * ONLY_DIFF_USER_CANCEL	: RECORD CANCELLATION IS ALLOWED BEFORE VERIFICATION (ALLOWED ONLY FOR DIFFERENT USER)
	 * ALL_USER_CANCEL		: RECORD CANCELLATION IS ALLOWED BEFORE VERIFICATION (ALLOWED FOR ALL USERS)
	 * NOT_ALLOWED			: RECORD CANCELLATION NOT ALLOWED AT ALL
	 *
	 * FUNCTION MODES FOR VERIFY MODE
	 * -----------------------------------------------------------------------------------------------------------------
	 * ONLY_SAME_USER_VERIFY : RECORD VERIFICATION IS ALLOWED ONLY FOR SAME USER
	 * ONLY_DIFF_USER_VERIFY : RECORD VERIFICATION IS ALLOWED ONLY FOR DIFFERENT USER
	 * ALL_USER_VERIFY		: RECORD VERIFICATION IS ALLOWED FOR ALL USERS
     */
    function makerCheckerValidationsB(dataObj) {
        FUME.print('Begin Function makerCheckerValidationsB');
        let retVal = false;
        let mandFlds = ['funcCode', 'funcMode', 'mainTable', 'modTable', 'keyFields', 'bindVars'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dataObj, mandFlds)) {
            return retVal;
        }
        let optFlds = ['errorCodes'];
        LibCommonB002.chkNonMandatorySRVInputsB(dataObj, optFlds);
        let mainTblCnt = 0;
        let modTblCnt = 0;
        let keyFields;
        let bindVars;
        let cntObj = {};
        if (typeof (dataObj.keyFields) === 'string') {
            keyFields = dataObj.keyFields.split('|');
        } else {
            keyFields = dataObj.keyFields;
        }
        if (typeof (dataObj.bindVars) === 'string') {
            bindVars = dataObj.bindVars.split('|');
        } else {
            bindVars = dataObj.bindVars;
        }
        cntObj.whereFields = keyFields;
        cntObj.whereValues = bindVars;
        cntObj.tableName = dataObj.mainTable;
        retVal = checkRecordCntB(cntObj);
        if (retVal) {
            mainTblCnt = parseInt(cntObj.count);
        }
        cntObj.whereFields = keyFields;
        cntObj.whereValues = bindVars;
        cntObj.tableName = dataObj.modTable;
        retVal = checkRecordCntB(cntObj);
        if (retVal) {
            modTblCnt = parseInt(cntObj.count);
        }
        let rcreUserId = '';
        let lchgUserId = '';
        let errorCode = '';
        let dbObj = {};
        if (modTblCnt > 0) {
            dbObj.count = 0;
            dbObj.outputFields = ['rcreUserId', 'lchgUserId'];
            dbObj.columnNames = ['RCRE_USER_ID', 'LCHG_USER_ID'];
            dbObj.tableName = dbObj.modTable;
            dbObj.whereFields = keyFields;
            dbObj.whereValues = bindVars;
            retVal = selectFromTableB(dbObj);
            if (retVal) {
                rcreUserId = dbObj.rcreUserId;
                lchgUserId = dbObj.lchgUserId;
            }
        }

        if (dataObj.funcCode === 'A') {
            if (mainTblCnt > 0 ) {
                errorCode = 'MSG0011844';
                populateErrorForMakerChecker(dataObj, errorCode);
                return false;
            }
            if (modTblCnt > 0 ) {
                errorCode = 'MSG0320273';
                populateErrorForMakerChecker(dataObj, errorCode);
                return false;
            }
        }
        if ((dataObj.funcCode === 'M') || (dataObj.funcCode === 'D') || (dataObj.funcCode === 'U')) {
            if (mainTblCnt === 0 && modTblCnt === 0) {
                errorCode = 'MSG0357673';
                populateErrorForMakerChecker(dataObj, errorCode);
                return false;
            }
            if (dataObj.funcMode === 'NOT_ALLOWED' ) {
                errorCode = 'MSG0009398';
                populateErrorForMakerChecker(dataObj, errorCode);
                return false;
            }
            if (dataObj.funcMode === 'NOT_ALLOWED_BEFORE_VERIFY' ) {
                if (modTblCnt > 0) {
                    errorCode = 'MSG0320273';
                    populateErrorForMakerChecker(dataObj, errorCode);
                    return false;
                }
            }
            if (dataObj.funcMode === 'ONLY_SAME_USER_MODIFY' ) {
                if (modTblCnt > 0) {
                    if (lchgUserId !== '' && (lchgUserId !== FUME.getrepValue('BANCS', 'STDIN', 'userId'))) {
                        errorCode = 'MSG0015400';
                        populateErrorForMakerChecker(dataObj, errorCode);
                        return false;
                    }
                }
            }
            if (dataObj.funcMode === 'ONLY_DIFF_USER_MODIFY' ) {
                if (modTblCnt > 0) {
                    if (lchgUserId !== '' && (lchgUserId === FUME.getrepValue('BANCS', 'STDIN', 'userId'))) {
                        errorCode = 'MSG0012726';
                        populateErrorForMakerChecker(dataObj, errorCode);
                        return false;
                    }
                }
            }
            if (dataObj.funcMode === 'ALL_USER_MODIFY' ) {
                if (modTblCnt > 0) {
                    return true;
                }
            }
        }
        if (dataObj.funcCode === 'X') {
            if ( modTblCnt === 0) {
                errorCode = 'MSG0010164';
                populateErrorForMakerChecker(dataObj, errorCode);
                return false;
            }
            if (dataObj.funcMode === 'NOT_ALLOWED' ) {
                errorCode = 'CMSGMA0001';
                populateErrorForMakerChecker(dataObj, errorCode);
                return false;
            }
            if (dataObj.funcMode === 'ONLY_SAME_USER_CANCEL' ) {
                if (modTblCnt > 0) {
                    if (lchgUserId !== '' && (lchgUserId !== FUME.getrepValue('BANCS', 'STDIN', 'userId'))) {
                        errorCode = 'CMSGMA0002';
                        populateErrorForMakerChecker(dataObj, errorCode);
                        return false;
                    }
                }
            }
            if (dataObj.funcMode === 'ONLY_DIFF_USER_CANCEL' ) {
                if (modTblCnt > 0) {
                    if (lchgUserId !== '' && (lchgUserId === FUME.getrepValue('BANCS', 'STDIN', 'userId'))) {
                        errorCode = 'CMSGMA0003';
                        populateErrorForMakerChecker(dataObj, errorCode);
                        return false;
                    }
                }
            }
            if (dataObj.funcMode === 'ALL_USER_CANCEL' ) {
                if (modTblCnt > 0) {
                    return true;
                }
            }
        }
        if (dataObj.funcCode === 'V') {
            if ( modTblCnt === 0) {
                errorCode = 'MSG0357675';
                populateErrorForMakerChecker(dataObj, errorCode);
                return false;
            }
            if (dataObj.funcMode === 'NOT_ALLOWED' ) {
                errorCode = 'CMSGMA0001';
                populateErrorForMakerChecker(dataObj, errorCode);
                return false;
            }
            if (dataObj.funcMode === 'ONLY_SAME_USER_VERIFY' ) {
                if (modTblCnt > 0) {
                    if (lchgUserId !== '' && (lchgUserId !== FUME.getrepValue('BANCS', 'STDIN', 'userId'))) {
                        errorCode = 'CMSGMA0004';
                        populateErrorForMakerChecker(dataObj, errorCode);
                        return false;
                    }
                }
            }
            if (dataObj.funcMode === 'ONLY_DIFF_USER_VERIFY' ) {
                if (modTblCnt > 0) {
                    if (lchgUserId !== '' && (lchgUserId === FUME.getrepValue('BANCS', 'STDIN', 'userId'))) {
                        errorCode = 'MSG0303771';
                        populateErrorForMakerChecker(dataObj, errorCode);
                        return false;
                    }
                }
            }
            if (dataObj.funcMode === 'ALL_USER_VERIFY' ) {
                if (modTblCnt > 0) {
                    return true;
                }
            }
        }
        if (dataObj.funcCode === 'I') {
            if ( mainTblCnt === 0) {
                errorCode = 'MSG0357673';
                populateErrorForMakerChecker(dataObj, errorCode);
                return false;
            }
        }
    }
    // ENDFUNCTION makerCheckerValidationsB

    function populateErrorForMakerChecker(obj, errorCode) {
        let errorMsg = '';
        let errorCodes = [];
        if (typeof (obj.errorCodes) === 'string') {
            errorCodes = obj.errorCodes.split('|');
        } else {
            errorCodes = obj.errorCodes;
        }
        if (errorCodes.length) {
            let customErrCode = errorCodes.filter(m => (m.funcCode === obj.funcCode && m.funcMode === obj.funcMode));
            if (customErrCode.length) errorCode = customErrCode.errorCode;
        }
        errorMsg = cmmsgerrdescB(errorCode);
        obj.errorCode = errorCode;
        obj.errorMsg = errorMsg;
        return;
    }

    // STARTFUNCTION resetDbVariables
    /**
     *@summary to reset BANCS.INPARAM fields
     *
     */
    function resetDbVariables() {
        FUME.setrepValue('BANCS', 'INPARAM', 'keyFieldsColumnDataType', '');
        FUME.setrepValue('BANCS', 'INPARAM', 'keyFieldsColumnFormat', '');
        FUME.setrepValue('BANCS', 'INPARAM', 'whereClauseOperator', '');
        FUME.setrepValue('BANCS', 'INPARAM', 'whereFieldsColumnDataType', '');
        FUME.setrepValue('BANCS', 'INPARAM', 'whereFieldsColumnFormat', '');
        FUME.setrepValue('BANCS', 'INPARAM', 'additionalQueryString', '');
        FUME.setrepValue('BANCS', 'INPARAM', 'selectFieldsDelimiter', '');
    }
    // ENDFUNCTION resetDbVariables
    // STARTFUNCTION executeDbSelectQuery
    /**
   *
   *
   * @param {*} query query to be executed
   * @param {*} bindvars bindvars for the function
   * @returns {boolean} true/false based on userhook output
   */
    function executeDbSelectQuery(query, bindvars = '') {
        let urhkOp;
        if (Array.isArray(bindvars)) {
            bindvars = bindvars.join('|');
        }
        FUME.setrepValue('BANCS', 'INPARAM', 'BINDVARS', bindvars);
        let q = query;
        // commenting as dbSelectWithBind to be used in 11x always
        /*
    let bindValFlg = 'Y';
    bindValFlg = FUME.getEnv('URHK_WITH_BINDVAL_FLG');
    FUME.print(bindValFlg);
    if (bindValFlg === 'N') {
        const p = q.indexOf('?SVAR');
        if (p > 0) {
            FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS'));
            const bindVars = FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS');
            const bindVarsArr = bindVars.split('|');
            for (let i = 0; i < bindVarsArr.length; i += 1) {
                q = q.replace('?SVAR', bindVarsArr[i]);
            }
        }
        FUME.print('FINAL QUERY WITHOUT BIND');
        FUME.print(q);
        urhkOp = FUME.USRHK('dbSelect', q);
    }
    */
        FUME.print('FINAL QUERY WITH BIND');
        FUME.print(q);
        FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS'));
        urhkOp = FUME.USRHK('dbSelectWithBind', q);
        urhkOp = urhkOp === 0;
        return urhkOp;
    }
    // ENDFUNCTION executeDbSelectQuery

    // STARTFUNCTION executeDbSelectLongQuery
    /**
*
*
* @param {*} query query to be executed
* @param {*} bindvars bindvars for the function
* @returns {boolean} true/false based on userhook output
*/
    function executeDbSelectLongQuery(query, bindvars = '') {
        let urhkOp;
        if (Array.isArray(bindvars)) {
            bindvars = bindvars.join('|');
        }
        FUME.setrepValue('BANCS', 'INPARAM', 'BINDVARS', bindvars);
        let q = query;
        let bindValFlg = '';
        bindValFlg = FUME.getEnv('URHK_WITH_BINDVAL_FLG');
        FUME.print(bindValFlg);
        if (bindValFlg === 'N') {
            const p = q.indexOf('?SVAR');
            if (p > 0) {
                FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS'));
                const bindVars = FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS');
                const bindVarsArr = bindVars.split('|');
                for (let i = 0; i < bindVarsArr.length; i += 1) {
                    q = q.replace('?SVAR', bindVarsArr[i]);
                }
            }
            FUME.print('FINAL QUERY WITHOUT BIND');
            FUME.print(q);
            urhkOp = FUME.USRHK('dbSelectLong', q);
        } else {
            FUME.print('FINAL QUERY WITH BIND');
            FUME.print(q);
            FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS'));
            urhkOp = FUME.USRHK('dbSelectLongWithBind', q);
        }
        urhkOp = urhkOp === 0;
        return urhkOp;
    }
    // ENDFUNCTION executeDbSelectLongQuery

    // STARTFUNCTION executeDbCursorQuery
    /**
*
*
* @param {*} query query to be executed
* @param {*} bindVal bindval for query
* @returns {boolean} true/false based on userhook output
*/
    function executeDbCursorQuery(query, bindVal = '') {
        let urhkOp;
        if (Array.isArray(bindVal)) {
            bindVal = bindVal.join('|');
        }
        FUME.setrepValue('BANCS', 'INPARAM', 'BINDVARS', bindVal);
        let q = query;
        let bindValFlg = '';
        bindValFlg = FUME.getEnv('URHK_WITH_BINDVAL_FLG');
        FUME.print(bindValFlg);
        if (bindValFlg === 'N') {
            const p = q.indexOf('?SVAR');
            if (p > 0) {
                const bindVars = bindVal;
                const bindVarsArr = bindVars.split('|');
                for (let i = 0; i < bindVarsArr.length; i += 1) {
                    q = q.replace('?SVAR', bindVarsArr[i]);
                }
            }
            FUME.print('FINAL QUERY WITHOUT BIND');
            FUME.print(q);
            urhkOp = FUME.USRHK('dbCursorOpen', q);
        } else {
            FUME.print('FINAL QUERY WITH BIND');
            FUME.print(q);
            FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS'));
            urhkOp = FUME.USRHK('dbCursorOpenWithBind', q);
        }
        urhkOp = urhkOp === 0;
        return urhkOp;
    }
    // ENDFUNCTION executeDbCursorQuery
    // STARTFUNCTION executeDbSqlQuery
    /**
*
*
* @param {*} query query to be executed
* @param {*} bindValue bind value for query
* @returns {boolean} true/false based on userhook output
*/
    function executeDbSqlQuery(query, bindValue = '') {
        let urhkOp;
        if (Array.isArray(bindValue)) {
            bindValue = bindValue.join('|');
        }
        FUME.setrepValue('BANCS', 'INPARAM', 'BINDVARS', bindValue);
        let q = query;
        let bindValFlg = '';
        bindValFlg = FUME.getEnv('URHK_WITH_BINDVAL_FLG');
        FUME.print(bindValFlg);
        if (bindValFlg === 'N') {
            const p = q.indexOf('?SVAR');
            if (p > 0) {
                const bindVars = FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS');
                const bindVarsArr = bindVars.split('|');
                for (let i = 0; i < bindVarsArr.length; i += 1) {
                    q = q.replace('?SVAR', bindVarsArr[i]);
                }
            }
            FUME.print('FINAL QUERY WITHOUT BIND');
            FUME.print(q);
            urhkOp = FUME.USRHK('dbSql', q);
        } else {
            FUME.print('FINAL QUERY WITH BIND');
            FUME.print(q);
            FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS'));
            urhkOp = FUME.USRHK('dbSqlWithBind', q);
        }
        urhkOp = urhkOp === 0;
        return urhkOp;
    }
    // ENDFUNCTION executeDbSqlQuery
    // STARTFUNCTION execDbSql
    /**
     *
     *
     * @param {*} query query to be executed
     * @param {*} bindValue bind variables for the query
     * @returns {boolean} true/false
     */
    function execDbSql(query, bindValue) {
        let qry;
        let retVal = false;
        qry = query;
        FUME.print('Begin Function execDbSql');
        if (Array.isArray(bindValue)) {
            bindValue = bindValue.join('|');
        }
        FUME.setrepValue('BANCS', 'INPARAM', 'BINDVARS', bindValue);
        FUME.print('[QUERY STRING]');
        FUME.print(qry);
        FUME.print('[BIND VALUES]');
        FUME.print(FUME.getrepValue('BANCS', 'INPARAM', 'BINDVARS'));
        FUME.print('[DBSELECT]');
        retVal = executeDbSqlQuery(qry, bindValue);
        (retVal) ? FUME.print('[SUCCESS]') : FUME.print('[NO RECORDS IMPACTED]');
        resetDbVariables();
        FUME.print('End Function execDbSql');
        return retVal;
    }
    // ENDFUNCTION execDbSql
    // STARTFUNCTION clearDbOject
    function clearDbObject(dbObj) {
        if (dbObj.clearFields) {
            dbObj.outputFields = undefined;
            dbObj.columnNames = undefined;
            dbObj.columnValues = undefined;
            dbObj.columnDataType = undefined;
            dbObj.columnFormat = undefined;
            dbObj.tableName = undefined;
            dbObj.whereFields = undefined;
            dbObj.whereValues = undefined;
            dbObj.dbLongField = undefined;
            dbObj.whereClauseOperator = undefined;
            dbObj.whereFieldsColumnDataType = undefined;
            dbObj.whereFieldsColumnFormat = undefined;
            dbObj.additionalQueryString = undefined;
            dbObj.sqlQuery = undefined;
            dbObj.bindVal = undefined;
            dbObj.userDefinedQuery = undefined;
            dbObj.clearFields = undefined;
        }
    }
    // ENDFUNCTION clearDbObject
    // STARTFUNCTION formWhereClauseQuery
    function formWhereClauseQuery(dbObj) {
        let query = '';
        let bindval = '';
        let dataType = 'STRING';
        let format = 'DD-MM-YYYY';
        let operator = '=';
        let whereFields = [];
        let whereValues = [];
        let whereClauseOperators = [];
        let whereFieldsColumnDataTypes = [];
        let whereFieldsColumnFormats = [];
        if (typeof (dbObj.whereFields) === 'string') {
            whereFields = dbObj.whereFields.split('|');
        } else {
            whereFields = dbObj.whereFields;
        }
        if (typeof (dbObj.whereValues) === 'string') {
            whereValues = dbObj.whereValues.split('|');
        } else {
            whereValues = dbObj.whereValues;
        }
        if (typeof (dbObj.whereClauseOperator) === 'string') {
            whereClauseOperators = dbObj.whereClauseOperator.split('|');
        } else {
            whereClauseOperators = dbObj.whereClauseOperator;
        }
        if (typeof (dbObj.whereFieldsColumnDataType) === 'string') {
            whereFieldsColumnDataTypes = dbObj.whereFieldsColumnDataType.split('|');
        } else {
            whereFieldsColumnDataTypes = dbObj.whereFieldsColumnDataType;
        }
        if (typeof (dbObj.whereFieldsColumnFormat) === 'string') {
            whereFieldsColumnFormats = dbObj.whereFieldsColumnFormat.split('|');
        } else {
            whereFieldsColumnFormats = dbObj.whereFieldsColumnFormat;
        }
        for (let i = 0; i < whereFields.length; i += 1) {
            if (((whereFieldsColumnDataTypes.length > 0) && (i <= whereFieldsColumnDataTypes.length) && (whereFieldsColumnDataTypes[i].trim() === ''))) {
                dataType = 'STRING';
            }
            if (((whereClauseOperators.length > 0) && (i <= whereClauseOperators.length) && (whereClauseOperators[i].trim() === ''))) {
                operator = '=';
            }
            if (((whereFieldsColumnFormats.length > 0) && (i <= whereFieldsColumnFormats.length) && (whereFieldsColumnFormats[i].trim() === ''))) {
                format = 'DD-MM-YYYY';
            }
            switch (dataType) {
                case 'DATE':
                    query += ` AND TO_DATE(?SVAR,'${format}')`;
                    bindval += whereValues[i] + '|';
                    break;
                case 'SYSDATE':
                    query += ` AND ${whereFields[i]} = SYSDATE `;
                    break;
                case 'STRING':
                case 'NUMBER':
                default:
                    query += ` AND ${whereFields[i]} ${operator} ?SVAR `;
                    bindval += `${whereValues[i]}|`;
            }
        }
        if (dbObj.additionalQueryString !== '') {
            query += dbObj.additionalQueryString;
        }
        query = query.substring(0, query.length - 1);
        bindval = bindval.substring(0, bindval.length - 1);
        let whereClauseObj = {};
        whereClauseObj.query = query;
        whereClauseObj.bindval = bindval;
        return whereClauseObj;
    }
    // ENDFUNCTION formWhereClauseQuery
    // STARTFUNCTION insertIntoTableB
    /**
     *
     *
     * @param {*} dbObj data object with fields for insertion
     * @returns {boolean} db sql return value true/false
     */
    function insertIntoTableB(dbObj) {
        let retVal = false;
        let query = '';
        let bindval = '';
        let dataType = 'STRING';
        let format = 'DD-MM-YYYY';
        let columnNames = [];
        let columnValues = [];
        let columnDataTypes = [];
        let columnFormats = [];
        let mandFlds = ['tableName', 'columnNames', 'columnValues'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dbObj, mandFlds)) {
            return retVal;
        }
        let optFlds = [];
        LibCommonB002.chkNonMandatorySRVInputsB(dbObj, optFlds);
        dbObj.clearFields = true;
        if (dbObj.sqlQuery !== '') {
            retVal = execDbSql(dbObj.sqlQuery, dbObj.bindVal);
        } else {
            if (typeof (dbObj.columnNames) === 'string') {
                columnNames = dbObj.columnNames.split('|');
            } else {
                columnNames = dbObj.columnNames;
            }
            if (typeof (dbObj.columnValues) === 'string') {
                columnValues = dbObj.columnValues.split('|');
            } else {
                columnValues = dbObj.columnValues;
            }
            if (typeof (dbObj.columnDataType) === 'string') {
                columnDataTypes = dbObj.columnDataType.split('|');
            } else {
                columnDataTypes = dbObj.columnDataType;
            }
            if (typeof (dbObj.columnFormat) === 'string') {
                columnFormats = dbObj.columnFormat.split('|');
            } else {
                columnFormats = dbObj.columnFormat;
            }
            query = `INSERT INTO ${dbObj.tableName} (${columnNames.join(',')}) VALUES (`;

            for (let i = 0; i < columnValues.length; i += 1) {
                if ((i <= columnDataTypes.length && columnDataTypes[i].trim() === '')) {
                    dataType = 'STRING';
                }
                if ((i <= columnFormats.length && columnFormats[i].trim() === '')) {
                    format = 'DD-MM-YYYY';
                }
                switch (dataType) {
                    case 'NUMBER':
                        query += 'TO_NUMBER(?SVAR),';
                        bindval += columnValues[i] + '|';
                        break;
                    case 'DATE':
                        query += `TO_DATE(?SVAR,'${format}'),`;
                        bindval += columnValues[i] + '|';
                        break;
                    case 'SYSDATE':
                        query += 'SYSDATE,';
                        break;
                    case 'STRING':
                    default:
                        query += '?SVAR,';
                        bindval += columnValues[i] + '|';
                }
            }
            query += query.substring(0, query.length - 1);
            bindval += bindval.substring(0, bindval.length - 1);
            retVal = execDbSql(query, bindval);
        }
        clearDbObject(dbObj);
        return retVal;
    }
    // ENDFUNCTION insertIntoTableB
    // STARTFUNCTION deleteFromTableB
    /**
     *
     *
     * @param {*} dbObj data object with fields for insertion
     * @returns {boolean} db sql return value true/false
     */
    function deleteFromTableB(dbObj) {
        let retVal = false;
        let query = '';
        let bindval = '';
        let mandFlds = ['tableName'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dbObj, mandFlds)) {
            return retVal;
        }
        let optFlds = 'whereFields|whereValues|whereClauseOperator|whereFieldsColumnDataType|whereFieldsColumnFormat|additionalQueryString|clearFields|sqlQuery|bindVal';
        LibCommonB002.chkNonMandatorySRVInputsB(dbObj, optFlds);
        dbObj.clearFields = true;
        if (dbObj.sqlQuery !== '') {
            retVal = execDbSql(dbObj.sqlQuery, dbObj.bindVal);
        } else {
            query = `DELETE FROM ${dbObj.tableName} WHERE 1=1 `;
            const whereClauseObj = formWhereClauseQuery(dbObj);
            if (whereClauseObj.query) {
                query += whereClauseObj.query;
            }
            if (whereClauseObj.bindval) {
                bindval += whereClauseObj.bindval;
            }
            if (dbObj.additionalQueryString !== '') {
                query += dbObj.additionalQueryString;
            }
            retVal = execDbSql(query, bindval);
        }
        clearDbObject(dbObj);
        return retVal;
    }
    // ENDFUNCTOON deleteFromTableB
    // STARTFUNCTION updateTableB
    /**
     *
     *
     * @param {*} dbObj data object with fields for insertion
     * @returns {boolean} db sql return value true/false
     */
    function updateTableB(dbObj) {
        let retVal = false;
        let query = '';
        let bindval = '';
        let dataType = 'STRING';
        let format = 'DD-MM-YYYY';
        let columnNames = [];
        let columnValues = [];
        let columnDataTypes = [];
        let columnFormats = [];
        let mandFlds = ['tableName', 'columnNames', 'columnValues'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dbObj, mandFlds)) {
            return retVal;
        }
        let optFlds = ['columnDataType', 'columnFormat', 'whereFields', 'whereValues', 'whereClauseOperator', 'whereFieldsColumnDataType', 'whereFieldsColumnFormat', 'additionalQueryString', 'clearFields', 'sqlQuery', 'bindVal'];
        LibCommonB002.chkNonMandatorySRVInputsB(dbObj, optFlds);
        dbObj.clearFields = true;
        if (dbObj.sqlQuery !== '') {
            retVal = execDbSql(dbObj.sqlQuery, dbObj.bindVal);
        } else {
            query = `UPDATE ${dbObj.tableName} SET `;
            if (typeof (dbObj.columnNames) === 'string') {
                columnNames = dbObj.columnNames.split('|');
            } else {
                columnNames = dbObj.columnNames;
            }
            if (typeof (dbObj.columnValues) === 'string') {
                columnValues = dbObj.columnValues.split('|');
            } else {
                columnValues = dbObj.columnValues;
            }
            if (typeof (dbObj.columnDataType) === 'string') {
                columnDataTypes = dbObj.columnDataType.split('|');
            } else {
                columnDataTypes = dbObj.columnDataType;
            }
            if (typeof (dbObj.columnFormat) === 'string') {
                columnFormats = dbObj.columnFormat.split('|');
            } else {
                columnFormats = dbObj.columnFormat;
            }
            for (let i = 0; i < columnValues.length; i += 1) {
                if ((i <= columnDataTypes.length && columnDataTypes[i].trim() === '')) {
                    dataType = 'STRING';
                }
                if ((i <= columnFormats.length && columnFormats[i].trim() === '')) {
                    format = 'DD-MM-YYYY';
                }
                switch (dataType) {
                    case 'NUMBER':
                        query += ` ${columnNames[i]} = TO_NUMBER(?SVAR),`;
                        bindval += columnValues[i] + '|';
                        break;
                    case 'DATE':
                        query += ` ${columnNames[i]} = TO_DATE(?SVAR,'${format}'),`;
                        bindval += columnValues[i] + '|';
                        break;
                    case 'SYSDATE':
                        query += ` ${columnNames[i]} = SYSDATE,`;
                        break;
                    case 'STRING':
                    default:
                        query += `${columnNames[i]} = ?SVAR,`;
                        bindval += columnValues[i] + '|';
                }
            }
            query = query.substring(0, query.length - 1);
            bindval = bindval.substring(0, bindval.length - 1);
            query += ' WHERE 1=1 ';

            const whereClauseObj = formWhereClauseQuery(dbObj);
            if (whereClauseObj.query) {
                query += whereClauseObj.query;
            }
            if (whereClauseObj.bindval) {
                bindval += whereClauseObj.bindval;
            }
            if (dbObj.additionalQueryString !== '') {
                query += dbObj.additionalQueryString;
            }
            retVal = execDbSql(query, bindval);
        }
        clearDbObject(dbObj);
        return retVal;
    }
    // ENDFUNCTION updateTableB
    // STARTFUNCTION selectFromTableB
    /**
     *
     *
     * @param {*} dbObj data object with fields for insertion
     * @returns {boolean} db sql return value true/false
     */
    function selectFromTableB(dbObj) {
        let retVal = false;
        let query = '';
        let bindval = '';
        let outputFields = [];
        let columnNames = [];
        let mandFlds = ['outputFields', 'columnNames', 'tableName'];
        if (!LibCommonB002.chkMandatorySRVInputsB(dbObj, mandFlds)) {
            return retVal;
        }
        let optFlds = ['whereFields', 'whereValues', 'dbLongField', 'whereClauseOperator', 'whereFieldsColumnDataType', 'whereFieldsColumnFormat', 'additionalQueryString', 'clearFields', 'sqlQuery', 'bindVal', 'setOrbOutFlg', 'userDefinedQuery'];
        LibCommonB002.chkNonMandatorySRVInputsB(dbObj, optFlds);
        dbObj.clearFields = true;
        dbObj.dbLongField = dbObj.dbLongField || false;
        dbObj.userDefinedQuery = dbObj.userDefinedQuery || '';
        dbObj.additionalQueryString = dbObj.additionalQueryString || '';
        if (dbObj.userDefinedQuery !== '') {
            if (dbObj.dbLongField) {
                retVal = executeDbSelectLongQuery(dbObj.userDefinedQuery, dbObj.bindVal);
            } else {
                retVal = executeDbSelectQuery(dbObj.userDefinedQuery, dbObj.bindVal);
            }
        } else {
            if (typeof (dbObj.columnNames) === 'string') {
                columnNames = dbObj.columnNames.split('|');
            }
            if (Array.isArray(dbObj.columnNames)) {
                columnNames = dbObj.columnNames;
            }
            if (typeof (dbObj.outputFields) === 'string') {
                outputFields = dbObj.outputFields.split('|');
            }
            if (Array.isArray(dbObj.outputFields)) {
                outputFields = dbObj.outputFields;
            }

            query = `${outputFields}|SELECT ${columnNames.join(',')} FROM ${dbObj.tableName} WHERE 1=1 `;
            query = query.substring(0, query.length - 1);
            bindval = bindval.substring(0, bindval.length - 1);

            const whereClauseObj = formWhereClauseQuery(dbObj);
            if (whereClauseObj.query) {
                query += whereClauseObj.query;
            }
            if (whereClauseObj.bindval) {
                bindval += whereClauseObj.bindval;
            }
            if (dbObj.additionalQueryString !== '') {
                query += dbObj.additionalQueryString;
            }
            if (dbObj.dbLongField) {
                retVal = executeDbSelectLongQuery(query, bindval);
            } else {
                retVal = executeDbSelectQuery(query, bindval);
            }
            if (retVal) {
                dbObj.output = [];
                for (let i = 0; i < outputFields.length; i += 1) {
                    let value = FUME.getrepValue('BANCS', 'OUTPARAM', outputFields[i]);
                    dbObj[outputFields[i]] = value;
                    if (dbObj.setOrbOutFlg) {
                    	FUME.USRHK('setOrbOut', `${outputFields[i]}| ${value}`);
                    }
                }
            }
        }
        clearDbObject(dbObj);
        return retVal;
    }
    // ENDFUNCTION selectFromTableB
    // STARTFUNCTION valCifIdB
    /**
     *
     *
     * @param {*} cifId cif id
     * @param {string} [bankId=''] bank id
     * @returns {boolean} true if cif id is valid, else false
     */
    function valCifIdB(cifId, bankId = '') {
        bankId = bankId || globalBankId;
        let dObj = {};
        dObj.outputFields = 'validFlg';
        dObj.columnNames = '1';
        dObj.tableName = 'CMG';
        dObj.whereFields = ['CIF_ID', 'BANK_ID', 'ENTITY_CRE_FLG', 'DEL_FLG'];
        dObj.whereValues = [cifId, bankId, 'Y', 'N'];
        const retVal = selectFromTableB(dObj);
        return retVal;
    }
    // ENDFUNCTION valCifIdB
    // STARTFUNCTION valSetIdB
    /**
     *
     *
     * @param {*} setId set id
     * @param {string} [bankId=''] bank id
     * @returns {boolean} true if set id is valid, else false
     */
    function valSetIdB(setId, bankId = '') {
        bankId = bankId || globalBankId;
        let dObj = {};
        dObj.outputFields = 'validFlg';
        dObj.columnNames = '1';
        dObj.tableName = 'STID';
        dObj.whereFields = ['SET_ID', 'BANK_ID'];
        dObj.whereValues = [setId, bankId];
        const retVal = selectFromTableB(dObj);
        return retVal;
    }
    // ENDFUNCTION valSetIdB
    // STARTFUNCTION valSchmCodeB
    /**
     *
     *
     * @param {*} schmCode scheme code
     * @param {string} [bankId=''] bank id
     * @returns {boolean} true if scheme code is valid, else false
     */
    function valSchmCodeB(schmCode, bankId = '') {
        bankId = bankId || globalBankId;
        let dObj = {};
        dObj.outputFields = 'validFlg';
        dObj.columnNames = '1';
        dObj.tableName = 'GSP';
        dObj.whereFields = ['SCHM_CODE', 'BANK_ID', 'ENTITY_CRE_FLG', 'DEL_FLG'];
        dObj.whereValues = [schmCode, bankId, 'Y', 'N'];
        const retVal = selectFromTableB(dObj);
        return retVal;
    }
    // ENDFUNCTION valSchmCodeB
    // START FUNCTIONLIST
    return {
        versionLibCommonB001,
        createRepClassB,
        deleteRepClassB,
        deleteRepB,
        deleteClassB,
        copyRepositoryVariableB,
        getTbaadmSchemaNameB,
        getCustomSchemaNameB,
        getNthFieldFromStringB,
        // getSetVarValueB,
        getUniqueFileNameB,
        setEnvVariableB,
        getEnvVariableB,
        copyOptionalFieldB,
        copyOutparamFieldB,
        replaceStrB,
        getCountOfCharB,
        pushReportToHPRB,
        // Not used execDbSelect,

        // dbSelectB,
        // selectFromCustTableB,
        // dbInsertB,
        // dbUpdateB,
        // dbDeleteB,
        // insertIntoCustTableB,
        // updateCustTableB,
        // deleteFromCustTableB,
        // createReportsB,
        addDataToFileB,
        addDataToFileWithNoSplCharB,
        getCifIdB,
        refCodeDescB,
        genReportAndPushToHPRB,
        generateReportB,
        generateAndPushReportToHPRB,
        checkRecordCntB,
        convertAmountB,
        cmmsgerrdescWithInputsB,
        mmsgErrDescWithInputsB,
        getRateDetailsB,
        // /////moveDataFromModToMainB,
        // selectFromCustTableWithLikeB,
        // checkRecordCntWithLikeB,
        // parseONScustMRH1B,
        setOrbOutWithDefValueB,
        setOrbOutWithDefValueNFieldsB,
        // /////copyInputNFieldsB,
        // /////copyInputNFieldsUpperB,
        getBankBranchCodeB,
        getBranchDetailsB,
        getFullPathB,
        handleSrvErrorB,
        mmsgErrDescB,
        cmmsgerrdescB,
        setErrorFieldsB,
        RIGHT$,
        LEFT$,
        MID$,
        makerCheckerValidationsB,
        resetDbVariables,
        execDbSql,
        formWhereClauseQuery,
        executeDbSelectQuery,
        executeDbSelectLongQuery,
        executeDbCursorQuery,
        executeDbSqlQuery,
        selectFromTableB,
        updateTableB,
        deleteFromTableB,
        insertIntoTableB,
        valCifIdB,
        valSchmCodeB,
        valSetIdB
    };
    // END FUNCTIONLIST
})();
