function decorator(func) {
  let cache = new Map();

  return function(...rest) {
    var count = 0;
    if (cache.has(rest.toString())) {    // if there's such key in cache
      count = cache.get(rest.toString()); // read the result from it
    }

    FUME.print("Starting function" + func.name + ":" + count);
    let result = func(...rest);  // otherwise call func
    cache.set(rest.toString(), ++count); 
    FUME.print("Ending function" + func.name + ":" + count);

    return result;
  };
}

var dbs = {};
for(let key of Object.keys(FUME)){
	FUME.print(key);
       dbs[key] = decorator(FUME[key]); 
}
dbs.print("asfdfsd");
dbs.print("asfdfsd");
dbs.print("asfdfsd");
//export var dbs = { print: FUME.print};
export default dbs;
